package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_NUMBER", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'^'", "'>'", "'>='", "'int'", "'uint'", "'uint8'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'solidity'", "';'", "'is'", "'.'", "'import'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'enum'", "','", "'='", "'require'", "'function'", "'selfdesctruct'", "'//'", "'/*'", "'*/'", "'pragma'", "'contract'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=9;
    public static final int T__19=19;
    public static final int RULE_EOLINE=6;
    public static final int T__59=59;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=8;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=13;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int RULE_STRING=12;
    public static final int RULE_SL_COMMENT=14;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=7;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int RULE_CLOSEPARENTHESIS=10;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=15;
    public static final int RULE_ANY_OTHER=16;
    public static final int RULE_NUMBER=11;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:53:1: entryRuleSmartContract : ruleSmartContract EOF ;
    public final void entryRuleSmartContract() throws RecognitionException {
        try {
            // InternalSM2.g:54:1: ( ruleSmartContract EOF )
            // InternalSM2.g:55:1: ruleSmartContract EOF
            {
             before(grammarAccess.getSmartContractRule()); 
            pushFollow(FOLLOW_1);
            ruleSmartContract();

            state._fsp--;

             after(grammarAccess.getSmartContractRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:62:1: ruleSmartContract : ( ( rule__SmartContract__Group__0 ) ) ;
    public final void ruleSmartContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:66:2: ( ( ( rule__SmartContract__Group__0 ) ) )
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            {
            // InternalSM2.g:67:2: ( ( rule__SmartContract__Group__0 ) )
            // InternalSM2.g:68:3: ( rule__SmartContract__Group__0 )
            {
             before(grammarAccess.getSmartContractAccess().getGroup()); 
            // InternalSM2.g:69:3: ( rule__SmartContract__Group__0 )
            // InternalSM2.g:69:4: rule__SmartContract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:78:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:79:1: ( ruleVersion EOF )
            // InternalSM2.g:80:1: ruleVersion EOF
            {
             before(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getVersionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:87:1: ruleVersion : ( ( rule__Version__Group__0 ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:91:2: ( ( ( rule__Version__Group__0 ) ) )
            // InternalSM2.g:92:2: ( ( rule__Version__Group__0 ) )
            {
            // InternalSM2.g:92:2: ( ( rule__Version__Group__0 ) )
            // InternalSM2.g:93:3: ( rule__Version__Group__0 )
            {
             before(grammarAccess.getVersionAccess().getGroup()); 
            // InternalSM2.g:94:3: ( rule__Version__Group__0 )
            // InternalSM2.g:94:4: rule__Version__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:103:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:104:1: ( ruleImport EOF )
            // InternalSM2.g:105:1: ruleImport EOF
            {
             before(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getImportRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:112:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:116:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:117:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:118:3: ( rule__Import__Group__0 )
            {
             before(grammarAccess.getImportAccess().getGroup()); 
            // InternalSM2.g:119:3: ( rule__Import__Group__0 )
            // InternalSM2.g:119:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:128:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:129:1: ( ruleAttributes EOF )
            // InternalSM2.g:130:1: ruleAttributes EOF
            {
             before(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getAttributesRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:137:1: ruleAttributes : ( ( rule__Attributes__Alternatives ) ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:141:2: ( ( ( rule__Attributes__Alternatives ) ) )
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            {
            // InternalSM2.g:142:2: ( ( rule__Attributes__Alternatives ) )
            // InternalSM2.g:143:3: ( rule__Attributes__Alternatives )
            {
             before(grammarAccess.getAttributesAccess().getAlternatives()); 
            // InternalSM2.g:144:3: ( rule__Attributes__Alternatives )
            // InternalSM2.g:144:4: rule__Attributes__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Attributes__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAttributesAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:153:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:154:1: ( ruleModifier EOF )
            // InternalSM2.g:155:1: ruleModifier EOF
            {
             before(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getModifierRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:162:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:166:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:167:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:167:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:168:3: ( rule__Modifier__Group__0 )
            {
             before(grammarAccess.getModifierAccess().getGroup()); 
            // InternalSM2.g:169:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:169:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:178:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:179:1: ( ruleDataType EOF )
            // InternalSM2.g:180:1: ruleDataType EOF
            {
             before(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;

             after(grammarAccess.getDataTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:187:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:191:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:192:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:192:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:193:3: ( rule__DataType__Alternatives )
            {
             before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            // InternalSM2.g:194:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:194:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getDataTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:203:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:204:1: ( ruleCompositeType EOF )
            // InternalSM2.g:205:1: ruleCompositeType EOF
            {
             before(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;

             after(grammarAccess.getCompositeTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:212:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:216:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:217:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:217:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:218:3: ( rule__CompositeType__Alternatives )
            {
             before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            // InternalSM2.g:219:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:219:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:228:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:229:1: ( ruleMapping EOF )
            // InternalSM2.g:230:1: ruleMapping EOF
            {
             before(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;

             after(grammarAccess.getMappingRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:237:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:241:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:242:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:242:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:243:3: ( rule__Mapping__Group__0 )
            {
             before(grammarAccess.getMappingAccess().getGroup()); 
            // InternalSM2.g:244:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:244:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:253:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:254:1: ( ruleStruct EOF )
            // InternalSM2.g:255:1: ruleStruct EOF
            {
             before(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;

             after(grammarAccess.getStructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:262:1: ruleStruct : ( ( rule__Struct__Group__0 ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:266:2: ( ( ( rule__Struct__Group__0 ) ) )
            // InternalSM2.g:267:2: ( ( rule__Struct__Group__0 ) )
            {
            // InternalSM2.g:267:2: ( ( rule__Struct__Group__0 ) )
            // InternalSM2.g:268:3: ( rule__Struct__Group__0 )
            {
             before(grammarAccess.getStructAccess().getGroup()); 
            // InternalSM2.g:269:3: ( rule__Struct__Group__0 )
            // InternalSM2.g:269:4: rule__Struct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:278:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:279:1: ( ruleEnum EOF )
            // InternalSM2.g:280:1: ruleEnum EOF
            {
             before(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;

             after(grammarAccess.getEnumRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:287:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:291:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:292:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:292:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:293:3: ( rule__Enum__Group__0 )
            {
             before(grammarAccess.getEnumAccess().getGroup()); 
            // InternalSM2.g:294:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:294:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:303:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:304:1: ( ruleProperty EOF )
            // InternalSM2.g:305:1: ruleProperty EOF
            {
             before(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getPropertyRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:312:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:316:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:317:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:317:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:318:3: ( rule__Property__Group__0 )
            {
             before(grammarAccess.getPropertyAccess().getGroup()); 
            // InternalSM2.g:319:3: ( rule__Property__Group__0 )
            // InternalSM2.g:319:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:328:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:329:1: ( ruleInputParam EOF )
            // InternalSM2.g:330:1: ruleInputParam EOF
            {
             before(grammarAccess.getInputParamRule()); 
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getInputParamRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:337:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:341:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:342:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:342:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:343:3: ( rule__InputParam__Group__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup()); 
            // InternalSM2.g:344:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:344:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:353:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:354:1: ( ruleRestriction EOF )
            // InternalSM2.g:355:1: ruleRestriction EOF
            {
             before(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getRestrictionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:362:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:366:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:367:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:367:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:368:3: ( rule__Restriction__Group__0 )
            {
             before(grammarAccess.getRestrictionAccess().getGroup()); 
            // InternalSM2.g:369:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:369:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:378:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:379:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:380:1: ruleRestrictionGas EOF
            {
             before(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getRestrictionGasRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:387:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:391:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:392:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:392:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:393:3: ( rule__RestrictionGas__Group__0 )
            {
             before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            // InternalSM2.g:394:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:394:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:403:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:404:1: ( ruleClause EOF )
            // InternalSM2.g:405:1: ruleClause EOF
            {
             before(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getClauseRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:412:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:416:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:417:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:417:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:418:3: ( rule__Clause__Group__0 )
            {
             before(grammarAccess.getClauseAccess().getGroup()); 
            // InternalSM2.g:419:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:419:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2.g:428:1: entryRuleSelfdestruct : ruleSelfdestruct EOF ;
    public final void entryRuleSelfdestruct() throws RecognitionException {
        try {
            // InternalSM2.g:429:1: ( ruleSelfdestruct EOF )
            // InternalSM2.g:430:1: ruleSelfdestruct EOF
            {
             before(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            ruleSelfdestruct();

            state._fsp--;

             after(grammarAccess.getSelfdestructRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2.g:437:1: ruleSelfdestruct : ( ( rule__Selfdestruct__Group__0 ) ) ;
    public final void ruleSelfdestruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:441:2: ( ( ( rule__Selfdestruct__Group__0 ) ) )
            // InternalSM2.g:442:2: ( ( rule__Selfdestruct__Group__0 ) )
            {
            // InternalSM2.g:442:2: ( ( rule__Selfdestruct__Group__0 ) )
            // InternalSM2.g:443:3: ( rule__Selfdestruct__Group__0 )
            {
             before(grammarAccess.getSelfdestructAccess().getGroup()); 
            // InternalSM2.g:444:3: ( rule__Selfdestruct__Group__0 )
            // InternalSM2.g:444:4: rule__Selfdestruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getSelfdestructAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:453:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:454:1: ( ruleExpression EOF )
            // InternalSM2.g:455:1: ruleExpression EOF
            {
             before(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:462:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:466:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:467:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:467:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:468:3: ( rule__Expression__Alternatives )
            {
             before(grammarAccess.getExpressionAccess().getAlternatives()); 
            // InternalSM2.g:469:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:469:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:478:1: entryRuleArithmethicalExpression : ruleArithmethicalExpression EOF ;
    public final void entryRuleArithmethicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:479:1: ( ruleArithmethicalExpression EOF )
            // InternalSM2.g:480:1: ruleArithmethicalExpression EOF
            {
             before(grammarAccess.getArithmethicalExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleArithmethicalExpression();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:487:1: ruleArithmethicalExpression : ( ( rule__ArithmethicalExpression__Alternatives ) ) ;
    public final void ruleArithmethicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:491:2: ( ( ( rule__ArithmethicalExpression__Alternatives ) ) )
            // InternalSM2.g:492:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            {
            // InternalSM2.g:492:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            // InternalSM2.g:493:3: ( rule__ArithmethicalExpression__Alternatives )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            // InternalSM2.g:494:3: ( rule__ArithmethicalExpression__Alternatives )
            // InternalSM2.g:494:4: rule__ArithmethicalExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:503:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:504:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:505:1: ruleSyntaxExpression EOF
            {
             before(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getSyntaxExpressionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:512:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Alternatives ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:516:2: ( ( ( rule__SyntaxExpression__Alternatives ) ) )
            // InternalSM2.g:517:2: ( ( rule__SyntaxExpression__Alternatives ) )
            {
            // InternalSM2.g:517:2: ( ( rule__SyntaxExpression__Alternatives ) )
            // InternalSM2.g:518:3: ( rule__SyntaxExpression__Alternatives )
            {
             before(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            // InternalSM2.g:519:3: ( rule__SyntaxExpression__Alternatives )
            // InternalSM2.g:519:4: rule__SyntaxExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:528:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:529:1: ( ruleComment EOF )
            // InternalSM2.g:530:1: ruleComment EOF
            {
             before(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:537:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:541:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:542:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:542:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:543:3: ( rule__Comment__Alternatives )
            {
             before(grammarAccess.getCommentAccess().getAlternatives()); 
            // InternalSM2.g:544:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:544:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCommentAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:553:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:554:1: ( ruleShortComment EOF )
            // InternalSM2.g:555:1: ruleShortComment EOF
            {
             before(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;

             after(grammarAccess.getShortCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:562:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:566:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:567:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:567:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:568:3: ( rule__ShortComment__Group__0 )
            {
             before(grammarAccess.getShortCommentAccess().getGroup()); 
            // InternalSM2.g:569:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:569:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:578:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:579:1: ( ruleLongComment EOF )
            // InternalSM2.g:580:1: ruleLongComment EOF
            {
             before(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;

             after(grammarAccess.getLongCommentRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:587:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:591:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:592:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:592:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:593:3: ( rule__LongComment__Group__0 )
            {
             before(grammarAccess.getLongCommentAccess().getGroup()); 
            // InternalSM2.g:594:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:594:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:603:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:607:1: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:608:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:608:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:609:3: ( rule__SingularType__Alternatives )
            {
             before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            // InternalSM2.g:610:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:610:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getSingularTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:619:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:623:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:624:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:624:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:625:3: ( rule__Visibility__Alternatives )
            {
             before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            // InternalSM2.g:626:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:626:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getVisibilityAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:635:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:639:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:640:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:640:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:641:3: ( rule__Coin__Alternatives )
            {
             before(grammarAccess.getCoinAccess().getAlternatives()); 
            // InternalSM2.g:642:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:642:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getCoinAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:651:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:655:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:656:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:656:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:657:3: ( rule__ComparationOperator__Alternatives )
            {
             before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            // InternalSM2.g:658:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:658:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:667:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:671:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:672:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:672:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:673:3: ( rule__LogicalPairOperator__Alternatives )
            {
             before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            // InternalSM2.g:674:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:674:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:683:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:687:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:688:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:688:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:689:3: ( rule__ArithmeticalOperator__Alternatives )
            {
             before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            // InternalSM2.g:690:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:690:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__Version__SymbolAlternatives_0_0"
    // InternalSM2.g:698:1: rule__Version__SymbolAlternatives_0_0 : ( ( '^' ) | ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:702:1: ( ( '^' ) | ( '>' ) | ( '>=' ) )
            int alt1=3;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt1=1;
                }
                break;
            case 18:
                {
                alt1=2;
                }
                break;
            case 19:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalSM2.g:703:2: ( '^' )
                    {
                    // InternalSM2.g:703:2: ( '^' )
                    // InternalSM2.g:704:3: '^'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
                    match(input,17,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:709:2: ( '>' )
                    {
                    // InternalSM2.g:709:2: ( '>' )
                    // InternalSM2.g:710:3: '>'
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_0_0_1()); 
                    match(input,18,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_0_0_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:715:2: ( '>=' )
                    {
                    // InternalSM2.g:715:2: ( '>=' )
                    // InternalSM2.g:716:3: '>='
                    {
                     before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_0_0_2()); 
                    match(input,19,FOLLOW_2); 
                     after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_0_0_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_0_0"


    // $ANTLR start "rule__Attributes__Alternatives"
    // InternalSM2.g:725:1: rule__Attributes__Alternatives : ( ( ruleProperty ) | ( ruleDataType ) );
    public final void rule__Attributes__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:729:1: ( ( ruleProperty ) | ( ruleDataType ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( ((LA2_0>=20 && LA2_0<=27)) ) {
                alt2=1;
            }
            else if ( (LA2_0==RULE_ID||LA2_0==54||(LA2_0>=56 && LA2_0<=57)) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:730:2: ( ruleProperty )
                    {
                    // InternalSM2.g:730:2: ( ruleProperty )
                    // InternalSM2.g:731:3: ruleProperty
                    {
                     before(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleProperty();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:736:2: ( ruleDataType )
                    {
                    // InternalSM2.g:736:2: ( ruleDataType )
                    // InternalSM2.g:737:3: ruleDataType
                    {
                     before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleDataType();

                    state._fsp--;

                     after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attributes__Alternatives"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:746:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:750:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt3=3;
            switch ( input.LA(1) ) {
            case 54:
            case 56:
                {
                alt3=1;
                }
                break;
            case 57:
                {
                alt3=2;
                }
                break;
            case RULE_ID:
                {
                alt3=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // InternalSM2.g:751:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:751:2: ( ruleCompositeType )
                    // InternalSM2.g:752:3: ruleCompositeType
                    {
                     before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:757:2: ( ruleEnum )
                    {
                    // InternalSM2.g:757:2: ( ruleEnum )
                    // InternalSM2.g:758:3: ruleEnum
                    {
                     before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;

                     after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:763:2: ( RULE_ID )
                    {
                    // InternalSM2.g:763:2: ( RULE_ID )
                    // InternalSM2.g:764:3: RULE_ID
                    {
                     before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:773:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:777:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==54) ) {
                alt4=1;
            }
            else if ( (LA4_0==56) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:778:2: ( ruleMapping )
                    {
                    // InternalSM2.g:778:2: ( ruleMapping )
                    // InternalSM2.g:779:3: ruleMapping
                    {
                     before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:784:2: ( ruleStruct )
                    {
                    // InternalSM2.g:784:2: ( ruleStruct )
                    // InternalSM2.g:785:3: ruleStruct
                    {
                     before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;

                     after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:794:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:798:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INT ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_STRING) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_INT) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:799:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:799:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:800:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                     before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    // InternalSM2.g:801:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:801:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:805:2: ( RULE_INT )
                    {
                    // InternalSM2.g:805:2: ( RULE_INT )
                    // InternalSM2.g:806:3: RULE_INT
                    {
                     before(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 
                    match(input,RULE_INT,FOLLOW_2); 
                     after(grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:815:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:819:1: ( ( ruleArithmethicalExpression ) | ( ruleSyntaxExpression ) )
            int alt6=2;
            switch ( input.LA(1) ) {
            case RULE_OPENPARENTHESIS:
                {
                alt6=1;
                }
                break;
            case RULE_INT:
                {
                int LA6_2 = input.LA(2);

                if ( ((LA6_2>=43 && LA6_2<=46)) ) {
                    alt6=1;
                }
                else if ( (LA6_2==EOF||LA6_2==RULE_EOLINE||LA6_2==RULE_CLOSEKEY||LA6_2==48) ) {
                    alt6=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 6, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt6=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSM2.g:820:2: ( ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:820:2: ( ruleArithmethicalExpression )
                    // InternalSM2.g:821:3: ruleArithmethicalExpression
                    {
                     before(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:826:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:826:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:827:3: ruleSyntaxExpression
                    {
                     before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;

                     after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__ArithmethicalExpression__Alternatives"
    // InternalSM2.g:836:1: rule__ArithmethicalExpression__Alternatives : ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) );
    public final void rule__ArithmethicalExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:840:1: ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_OPENPARENTHESIS) ) {
                alt7=1;
            }
            else if ( (LA7_0==RULE_INT) ) {
                alt7=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:841:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    {
                    // InternalSM2.g:841:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    // InternalSM2.g:842:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    // InternalSM2.g:843:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    // InternalSM2.g:843:4: rule__ArithmethicalExpression__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_0__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:847:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:847:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    // InternalSM2.g:848:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    {
                     before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:849:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    // InternalSM2.g:849:4: rule__ArithmethicalExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Alternatives"


    // $ANTLR start "rule__SyntaxExpression__Alternatives"
    // InternalSM2.g:857:1: rule__SyntaxExpression__Alternatives : ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) );
    public final void rule__SyntaxExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:861:1: ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_STRING) ) {
                alt8=1;
            }
            else if ( (LA8_0==RULE_INT) ) {
                alt8=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:862:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    {
                    // InternalSM2.g:862:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    // InternalSM2.g:863:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    // InternalSM2.g:864:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    // InternalSM2.g:864:4: rule__SyntaxExpression__TextAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__TextAssignment_0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:868:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:868:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    // InternalSM2.g:869:3: ( rule__SyntaxExpression__Group_1__0 )
                    {
                     before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    // InternalSM2.g:870:3: ( rule__SyntaxExpression__Group_1__0 )
                    // InternalSM2.g:870:4: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:878:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:882:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==63) ) {
                alt9=1;
            }
            else if ( (LA9_0==64) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:883:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:883:2: ( ruleShortComment )
                    // InternalSM2.g:884:3: ruleShortComment
                    {
                     before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:889:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:889:2: ( ruleLongComment )
                    // InternalSM2.g:890:3: ruleLongComment
                    {
                     before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;

                     after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:899:1: rule__SingularType__Alternatives : ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:903:1: ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) )
            int alt10=8;
            switch ( input.LA(1) ) {
            case 20:
                {
                alt10=1;
                }
                break;
            case 21:
                {
                alt10=2;
                }
                break;
            case 22:
                {
                alt10=3;
                }
                break;
            case 23:
                {
                alt10=4;
                }
                break;
            case 24:
                {
                alt10=5;
                }
                break;
            case 25:
                {
                alt10=6;
                }
                break;
            case 26:
                {
                alt10=7;
                }
                break;
            case 27:
                {
                alt10=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalSM2.g:904:2: ( ( 'int' ) )
                    {
                    // InternalSM2.g:904:2: ( ( 'int' ) )
                    // InternalSM2.g:905:3: ( 'int' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:906:3: ( 'int' )
                    // InternalSM2.g:906:4: 'int'
                    {
                    match(input,20,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:910:2: ( ( 'uint' ) )
                    {
                    // InternalSM2.g:910:2: ( ( 'uint' ) )
                    // InternalSM2.g:911:3: ( 'uint' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:912:3: ( 'uint' )
                    // InternalSM2.g:912:4: 'uint'
                    {
                    match(input,21,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:916:2: ( ( 'uint8' ) )
                    {
                    // InternalSM2.g:916:2: ( ( 'uint8' ) )
                    // InternalSM2.g:917:3: ( 'uint8' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    // InternalSM2.g:918:3: ( 'uint8' )
                    // InternalSM2.g:918:4: 'uint8'
                    {
                    match(input,22,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:922:2: ( ( 'string' ) )
                    {
                    // InternalSM2.g:922:2: ( ( 'string' ) )
                    // InternalSM2.g:923:3: ( 'string' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:924:3: ( 'string' )
                    // InternalSM2.g:924:4: 'string'
                    {
                    match(input,23,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:928:2: ( ( 'address' ) )
                    {
                    // InternalSM2.g:928:2: ( ( 'address' ) )
                    // InternalSM2.g:929:3: ( 'address' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:930:3: ( 'address' )
                    // InternalSM2.g:930:4: 'address'
                    {
                    match(input,24,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:934:2: ( ( 'address payable' ) )
                    {
                    // InternalSM2.g:934:2: ( ( 'address payable' ) )
                    // InternalSM2.g:935:3: ( 'address payable' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:936:3: ( 'address payable' )
                    // InternalSM2.g:936:4: 'address payable'
                    {
                    match(input,25,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:940:2: ( ( 'double' ) )
                    {
                    // InternalSM2.g:940:2: ( ( 'double' ) )
                    // InternalSM2.g:941:3: ( 'double' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_6()); 
                    // InternalSM2.g:942:3: ( 'double' )
                    // InternalSM2.g:942:4: 'double'
                    {
                    match(input,26,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_6()); 

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:946:2: ( ( 'bool' ) )
                    {
                    // InternalSM2.g:946:2: ( ( 'bool' ) )
                    // InternalSM2.g:947:3: ( 'bool' )
                    {
                     before(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_7()); 
                    // InternalSM2.g:948:3: ( 'bool' )
                    // InternalSM2.g:948:4: 'bool'
                    {
                    match(input,27,FOLLOW_2); 

                    }

                     after(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_7()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:956:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:960:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt11=1;
                }
                break;
            case 29:
                {
                alt11=2;
                }
                break;
            case 30:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalSM2.g:961:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:961:2: ( ( 'public' ) )
                    // InternalSM2.g:962:3: ( 'public' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:963:3: ( 'public' )
                    // InternalSM2.g:963:4: 'public'
                    {
                    match(input,28,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:967:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:967:2: ( ( 'private' ) )
                    // InternalSM2.g:968:3: ( 'private' )
                    {
                     before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:969:3: ( 'private' )
                    // InternalSM2.g:969:4: 'private'
                    {
                    match(input,29,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:973:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:973:2: ( ( 'internal' ) )
                    // InternalSM2.g:974:3: ( 'internal' )
                    {
                     before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:975:3: ( 'internal' )
                    // InternalSM2.g:975:4: 'internal'
                    {
                    match(input,30,FOLLOW_2); 

                    }

                     after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:983:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:987:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt12=6;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt12=1;
                }
                break;
            case 32:
                {
                alt12=2;
                }
                break;
            case 33:
                {
                alt12=3;
                }
                break;
            case 34:
                {
                alt12=4;
                }
                break;
            case 35:
                {
                alt12=5;
                }
                break;
            case 36:
                {
                alt12=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }

            switch (alt12) {
                case 1 :
                    // InternalSM2.g:988:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:988:2: ( ( 'ether' ) )
                    // InternalSM2.g:989:3: ( 'ether' )
                    {
                     before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    // InternalSM2.g:990:3: ( 'ether' )
                    // InternalSM2.g:990:4: 'ether'
                    {
                    match(input,31,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:994:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:994:2: ( ( 'wei' ) )
                    // InternalSM2.g:995:3: ( 'wei' )
                    {
                     before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:996:3: ( 'wei' )
                    // InternalSM2.g:996:4: 'wei'
                    {
                    match(input,32,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1000:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1000:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1001:3: ( 'gwei' )
                    {
                     before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1002:3: ( 'gwei' )
                    // InternalSM2.g:1002:4: 'gwei'
                    {
                    match(input,33,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1006:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1006:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1007:3: ( 'pwei' )
                    {
                     before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1008:3: ( 'pwei' )
                    // InternalSM2.g:1008:4: 'pwei'
                    {
                    match(input,34,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1012:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1012:2: ( ( 'finney' ) )
                    // InternalSM2.g:1013:3: ( 'finney' )
                    {
                     before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1014:3: ( 'finney' )
                    // InternalSM2.g:1014:4: 'finney'
                    {
                    match(input,35,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1018:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1018:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1019:3: ( 'szabo' )
                    {
                     before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1020:3: ( 'szabo' )
                    // InternalSM2.g:1020:4: 'szabo'
                    {
                    match(input,36,FOLLOW_2); 

                    }

                     after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1028:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1032:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt13=6;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt13=1;
                }
                break;
            case 37:
                {
                alt13=2;
                }
                break;
            case 19:
                {
                alt13=3;
                }
                break;
            case 38:
                {
                alt13=4;
                }
                break;
            case 39:
                {
                alt13=5;
                }
                break;
            case 40:
                {
                alt13=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }

            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1033:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1033:2: ( ( '>' ) )
                    // InternalSM2.g:1034:3: ( '>' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1035:3: ( '>' )
                    // InternalSM2.g:1035:4: '>'
                    {
                    match(input,18,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1039:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1039:2: ( ( '<' ) )
                    // InternalSM2.g:1040:3: ( '<' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1041:3: ( '<' )
                    // InternalSM2.g:1041:4: '<'
                    {
                    match(input,37,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1045:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1045:2: ( ( '>=' ) )
                    // InternalSM2.g:1046:3: ( '>=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1047:3: ( '>=' )
                    // InternalSM2.g:1047:4: '>='
                    {
                    match(input,19,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1051:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1051:2: ( ( '<=' ) )
                    // InternalSM2.g:1052:3: ( '<=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1053:3: ( '<=' )
                    // InternalSM2.g:1053:4: '<='
                    {
                    match(input,38,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1057:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1057:2: ( ( '==' ) )
                    // InternalSM2.g:1058:3: ( '==' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    // InternalSM2.g:1059:3: ( '==' )
                    // InternalSM2.g:1059:4: '=='
                    {
                    match(input,39,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1063:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1063:2: ( ( '!=' ) )
                    // InternalSM2.g:1064:3: ( '!=' )
                    {
                     before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    // InternalSM2.g:1065:3: ( '!=' )
                    // InternalSM2.g:1065:4: '!='
                    {
                    match(input,40,FOLLOW_2); 

                    }

                     after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1073:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1077:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==41) ) {
                alt14=1;
            }
            else if ( (LA14_0==42) ) {
                alt14=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1078:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1078:2: ( ( '&&' ) )
                    // InternalSM2.g:1079:3: ( '&&' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1080:3: ( '&&' )
                    // InternalSM2.g:1080:4: '&&'
                    {
                    match(input,41,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1084:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1084:2: ( ( '||' ) )
                    // InternalSM2.g:1085:3: ( '||' )
                    {
                     before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1086:3: ( '||' )
                    // InternalSM2.g:1086:4: '||'
                    {
                    match(input,42,FOLLOW_2); 

                    }

                     after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1094:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1098:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) )
            int alt15=4;
            switch ( input.LA(1) ) {
            case 43:
                {
                alt15=1;
                }
                break;
            case 44:
                {
                alt15=2;
                }
                break;
            case 45:
                {
                alt15=3;
                }
                break;
            case 46:
                {
                alt15=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }

            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1099:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1099:2: ( ( '+' ) )
                    // InternalSM2.g:1100:3: ( '+' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    // InternalSM2.g:1101:3: ( '+' )
                    // InternalSM2.g:1101:4: '+'
                    {
                    match(input,43,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1105:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1105:2: ( ( '-' ) )
                    // InternalSM2.g:1106:3: ( '-' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    // InternalSM2.g:1107:3: ( '-' )
                    // InternalSM2.g:1107:4: '-'
                    {
                    match(input,44,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1111:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1111:2: ( ( '*' ) )
                    // InternalSM2.g:1112:3: ( '*' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    // InternalSM2.g:1113:3: ( '*' )
                    // InternalSM2.g:1113:4: '*'
                    {
                    match(input,45,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1117:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1117:2: ( ( '/' ) )
                    // InternalSM2.g:1118:3: ( '/' )
                    {
                     before(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    // InternalSM2.g:1119:3: ( '/' )
                    // InternalSM2.g:1119:4: '/'
                    {
                    match(input,46,FOLLOW_2); 

                    }

                     after(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__SmartContract__Group__0"
    // InternalSM2.g:1127:1: rule__SmartContract__Group__0 : rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 ;
    public final void rule__SmartContract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1131:1: ( rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 )
            // InternalSM2.g:1132:2: rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__SmartContract__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0"


    // $ANTLR start "rule__SmartContract__Group__0__Impl"
    // InternalSM2.g:1139:1: rule__SmartContract__Group__0__Impl : ( ( rule__SmartContract__CompilerAssignment_0 ) ) ;
    public final void rule__SmartContract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1143:1: ( ( ( rule__SmartContract__CompilerAssignment_0 ) ) )
            // InternalSM2.g:1144:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            {
            // InternalSM2.g:1144:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            // InternalSM2.g:1145:2: ( rule__SmartContract__CompilerAssignment_0 )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            // InternalSM2.g:1146:2: ( rule__SmartContract__CompilerAssignment_0 )
            // InternalSM2.g:1146:3: rule__SmartContract__CompilerAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__CompilerAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0__Impl"


    // $ANTLR start "rule__SmartContract__Group__1"
    // InternalSM2.g:1154:1: rule__SmartContract__Group__1 : rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 ;
    public final void rule__SmartContract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1158:1: ( rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 )
            // InternalSM2.g:1159:2: rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SmartContract__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1"


    // $ANTLR start "rule__SmartContract__Group__1__Impl"
    // InternalSM2.g:1166:1: rule__SmartContract__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__SmartContract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1170:1: ( ( 'solidity' ) )
            // InternalSM2.g:1171:1: ( 'solidity' )
            {
            // InternalSM2.g:1171:1: ( 'solidity' )
            // InternalSM2.g:1172:2: 'solidity'
            {
             before(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1__Impl"


    // $ANTLR start "rule__SmartContract__Group__2"
    // InternalSM2.g:1181:1: rule__SmartContract__Group__2 : rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 ;
    public final void rule__SmartContract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1185:1: ( rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 )
            // InternalSM2.g:1186:2: rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__SmartContract__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2"


    // $ANTLR start "rule__SmartContract__Group__2__Impl"
    // InternalSM2.g:1193:1: rule__SmartContract__Group__2__Impl : ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) ;
    public final void rule__SmartContract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1197:1: ( ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) )
            // InternalSM2.g:1198:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            {
            // InternalSM2.g:1198:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            // InternalSM2.g:1199:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            // InternalSM2.g:1200:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            // InternalSM2.g:1200:3: rule__SmartContract__VersionCompilerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__VersionCompilerAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__Group__3"
    // InternalSM2.g:1208:1: rule__SmartContract__Group__3 : rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 ;
    public final void rule__SmartContract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1212:1: ( rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 )
            // InternalSM2.g:1213:2: rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3"


    // $ANTLR start "rule__SmartContract__Group__3__Impl"
    // InternalSM2.g:1220:1: rule__SmartContract__Group__3__Impl : ( ';' ) ;
    public final void rule__SmartContract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1224:1: ( ( ';' ) )
            // InternalSM2.g:1225:1: ( ';' )
            {
            // InternalSM2.g:1225:1: ( ';' )
            // InternalSM2.g:1226:2: ';'
            {
             before(grammarAccess.getSmartContractAccess().getSemicolonKeyword_3()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getSemicolonKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3__Impl"


    // $ANTLR start "rule__SmartContract__Group__4"
    // InternalSM2.g:1235:1: rule__SmartContract__Group__4 : rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 ;
    public final void rule__SmartContract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1239:1: ( rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 )
            // InternalSM2.g:1240:2: rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4"


    // $ANTLR start "rule__SmartContract__Group__4__Impl"
    // InternalSM2.g:1247:1: rule__SmartContract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1251:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1252:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1252:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1253:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:1254:2: ( RULE_EOLINE )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==RULE_EOLINE) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1254:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4__Impl"


    // $ANTLR start "rule__SmartContract__Group__5"
    // InternalSM2.g:1262:1: rule__SmartContract__Group__5 : rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 ;
    public final void rule__SmartContract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1266:1: ( rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 )
            // InternalSM2.g:1267:2: rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5"


    // $ANTLR start "rule__SmartContract__Group__5__Impl"
    // InternalSM2.g:1274:1: rule__SmartContract__Group__5__Impl : ( ( rule__SmartContract__ImportsAssignment_5 )* ) ;
    public final void rule__SmartContract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1278:1: ( ( ( rule__SmartContract__ImportsAssignment_5 )* ) )
            // InternalSM2.g:1279:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            {
            // InternalSM2.g:1279:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            // InternalSM2.g:1280:2: ( rule__SmartContract__ImportsAssignment_5 )*
            {
             before(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            // InternalSM2.g:1281:2: ( rule__SmartContract__ImportsAssignment_5 )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==51) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalSM2.g:1281:3: rule__SmartContract__ImportsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SmartContract__ImportsAssignment_5();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5__Impl"


    // $ANTLR start "rule__SmartContract__Group__6"
    // InternalSM2.g:1289:1: rule__SmartContract__Group__6 : rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 ;
    public final void rule__SmartContract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1293:1: ( rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 )
            // InternalSM2.g:1294:2: rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6"


    // $ANTLR start "rule__SmartContract__Group__6__Impl"
    // InternalSM2.g:1301:1: rule__SmartContract__Group__6__Impl : ( ( rule__SmartContract__ContractAssignment_6 ) ) ;
    public final void rule__SmartContract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1305:1: ( ( ( rule__SmartContract__ContractAssignment_6 ) ) )
            // InternalSM2.g:1306:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            {
            // InternalSM2.g:1306:1: ( ( rule__SmartContract__ContractAssignment_6 ) )
            // InternalSM2.g:1307:2: ( rule__SmartContract__ContractAssignment_6 )
            {
             before(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 
            // InternalSM2.g:1308:2: ( rule__SmartContract__ContractAssignment_6 )
            // InternalSM2.g:1308:3: rule__SmartContract__ContractAssignment_6
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__ContractAssignment_6();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getContractAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6__Impl"


    // $ANTLR start "rule__SmartContract__Group__7"
    // InternalSM2.g:1316:1: rule__SmartContract__Group__7 : rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 ;
    public final void rule__SmartContract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1320:1: ( rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 )
            // InternalSM2.g:1321:2: rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7"


    // $ANTLR start "rule__SmartContract__Group__7__Impl"
    // InternalSM2.g:1328:1: rule__SmartContract__Group__7__Impl : ( ( rule__SmartContract__NameContractAssignment_7 ) ) ;
    public final void rule__SmartContract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1332:1: ( ( ( rule__SmartContract__NameContractAssignment_7 ) ) )
            // InternalSM2.g:1333:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            {
            // InternalSM2.g:1333:1: ( ( rule__SmartContract__NameContractAssignment_7 ) )
            // InternalSM2.g:1334:2: ( rule__SmartContract__NameContractAssignment_7 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 
            // InternalSM2.g:1335:2: ( rule__SmartContract__NameContractAssignment_7 )
            // InternalSM2.g:1335:3: rule__SmartContract__NameContractAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7__Impl"


    // $ANTLR start "rule__SmartContract__Group__8"
    // InternalSM2.g:1343:1: rule__SmartContract__Group__8 : rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 ;
    public final void rule__SmartContract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1347:1: ( rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 )
            // InternalSM2.g:1348:2: rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8"


    // $ANTLR start "rule__SmartContract__Group__8__Impl"
    // InternalSM2.g:1355:1: rule__SmartContract__Group__8__Impl : ( ( rule__SmartContract__Group_8__0 )? ) ;
    public final void rule__SmartContract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1359:1: ( ( ( rule__SmartContract__Group_8__0 )? ) )
            // InternalSM2.g:1360:1: ( ( rule__SmartContract__Group_8__0 )? )
            {
            // InternalSM2.g:1360:1: ( ( rule__SmartContract__Group_8__0 )? )
            // InternalSM2.g:1361:2: ( rule__SmartContract__Group_8__0 )?
            {
             before(grammarAccess.getSmartContractAccess().getGroup_8()); 
            // InternalSM2.g:1362:2: ( rule__SmartContract__Group_8__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==49) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1362:3: rule__SmartContract__Group_8__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__Group_8__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getGroup_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8__Impl"


    // $ANTLR start "rule__SmartContract__Group__9"
    // InternalSM2.g:1370:1: rule__SmartContract__Group__9 : rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 ;
    public final void rule__SmartContract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1374:1: ( rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 )
            // InternalSM2.g:1375:2: rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9"


    // $ANTLR start "rule__SmartContract__Group__9__Impl"
    // InternalSM2.g:1382:1: rule__SmartContract__Group__9__Impl : ( RULE_OPENKEY ) ;
    public final void rule__SmartContract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1386:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:1387:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:1387:1: ( RULE_OPENKEY )
            // InternalSM2.g:1388:2: RULE_OPENKEY
            {
             before(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9__Impl"


    // $ANTLR start "rule__SmartContract__Group__10"
    // InternalSM2.g:1397:1: rule__SmartContract__Group__10 : rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 ;
    public final void rule__SmartContract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1401:1: ( rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 )
            // InternalSM2.g:1402:2: rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10"


    // $ANTLR start "rule__SmartContract__Group__10__Impl"
    // InternalSM2.g:1409:1: rule__SmartContract__Group__10__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1413:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1414:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1414:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1415:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 
            // InternalSM2.g:1416:2: ( RULE_EOLINE )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==RULE_EOLINE) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1416:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10__Impl"


    // $ANTLR start "rule__SmartContract__Group__11"
    // InternalSM2.g:1424:1: rule__SmartContract__Group__11 : rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 ;
    public final void rule__SmartContract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1428:1: ( rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 )
            // InternalSM2.g:1429:2: rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11"


    // $ANTLR start "rule__SmartContract__Group__11__Impl"
    // InternalSM2.g:1436:1: rule__SmartContract__Group__11__Impl : ( ( rule__SmartContract__AttributesAssignment_11 )* ) ;
    public final void rule__SmartContract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1440:1: ( ( ( rule__SmartContract__AttributesAssignment_11 )* ) )
            // InternalSM2.g:1441:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            {
            // InternalSM2.g:1441:1: ( ( rule__SmartContract__AttributesAssignment_11 )* )
            // InternalSM2.g:1442:2: ( rule__SmartContract__AttributesAssignment_11 )*
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 
            // InternalSM2.g:1443:2: ( rule__SmartContract__AttributesAssignment_11 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_ID||(LA20_0>=20 && LA20_0<=27)||LA20_0==54||(LA20_0>=56 && LA20_0<=57)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalSM2.g:1443:3: rule__SmartContract__AttributesAssignment_11
            	    {
            	    pushFollow(FOLLOW_11);
            	    rule__SmartContract__AttributesAssignment_11();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getAttributesAssignment_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11__Impl"


    // $ANTLR start "rule__SmartContract__Group__12"
    // InternalSM2.g:1451:1: rule__SmartContract__Group__12 : rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 ;
    public final void rule__SmartContract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1455:1: ( rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 )
            // InternalSM2.g:1456:2: rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12"


    // $ANTLR start "rule__SmartContract__Group__12__Impl"
    // InternalSM2.g:1463:1: rule__SmartContract__Group__12__Impl : ( ( rule__SmartContract__ModifierAssignment_12 )* ) ;
    public final void rule__SmartContract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1467:1: ( ( ( rule__SmartContract__ModifierAssignment_12 )* ) )
            // InternalSM2.g:1468:1: ( ( rule__SmartContract__ModifierAssignment_12 )* )
            {
            // InternalSM2.g:1468:1: ( ( rule__SmartContract__ModifierAssignment_12 )* )
            // InternalSM2.g:1469:2: ( rule__SmartContract__ModifierAssignment_12 )*
            {
             before(grammarAccess.getSmartContractAccess().getModifierAssignment_12()); 
            // InternalSM2.g:1470:2: ( rule__SmartContract__ModifierAssignment_12 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==52) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalSM2.g:1470:3: rule__SmartContract__ModifierAssignment_12
            	    {
            	    pushFollow(FOLLOW_12);
            	    rule__SmartContract__ModifierAssignment_12();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getModifierAssignment_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12__Impl"


    // $ANTLR start "rule__SmartContract__Group__13"
    // InternalSM2.g:1478:1: rule__SmartContract__Group__13 : rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 ;
    public final void rule__SmartContract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1482:1: ( rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 )
            // InternalSM2.g:1483:2: rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13"


    // $ANTLR start "rule__SmartContract__Group__13__Impl"
    // InternalSM2.g:1490:1: rule__SmartContract__Group__13__Impl : ( ( rule__SmartContract__ClausesAssignment_13 )* ) ;
    public final void rule__SmartContract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1494:1: ( ( ( rule__SmartContract__ClausesAssignment_13 )* ) )
            // InternalSM2.g:1495:1: ( ( rule__SmartContract__ClausesAssignment_13 )* )
            {
            // InternalSM2.g:1495:1: ( ( rule__SmartContract__ClausesAssignment_13 )* )
            // InternalSM2.g:1496:2: ( rule__SmartContract__ClausesAssignment_13 )*
            {
             before(grammarAccess.getSmartContractAccess().getClausesAssignment_13()); 
            // InternalSM2.g:1497:2: ( rule__SmartContract__ClausesAssignment_13 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==61) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalSM2.g:1497:3: rule__SmartContract__ClausesAssignment_13
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__SmartContract__ClausesAssignment_13();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getClausesAssignment_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13__Impl"


    // $ANTLR start "rule__SmartContract__Group__14"
    // InternalSM2.g:1505:1: rule__SmartContract__Group__14 : rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 ;
    public final void rule__SmartContract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1509:1: ( rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 )
            // InternalSM2.g:1510:2: rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14"


    // $ANTLR start "rule__SmartContract__Group__14__Impl"
    // InternalSM2.g:1517:1: rule__SmartContract__Group__14__Impl : ( ( rule__SmartContract__CommentsAssignment_14 )* ) ;
    public final void rule__SmartContract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1521:1: ( ( ( rule__SmartContract__CommentsAssignment_14 )* ) )
            // InternalSM2.g:1522:1: ( ( rule__SmartContract__CommentsAssignment_14 )* )
            {
            // InternalSM2.g:1522:1: ( ( rule__SmartContract__CommentsAssignment_14 )* )
            // InternalSM2.g:1523:2: ( rule__SmartContract__CommentsAssignment_14 )*
            {
             before(grammarAccess.getSmartContractAccess().getCommentsAssignment_14()); 
            // InternalSM2.g:1524:2: ( rule__SmartContract__CommentsAssignment_14 )*
            loop23:
            do {
                int alt23=2;
                int LA23_0 = input.LA(1);

                if ( ((LA23_0>=63 && LA23_0<=64)) ) {
                    alt23=1;
                }


                switch (alt23) {
            	case 1 :
            	    // InternalSM2.g:1524:3: rule__SmartContract__CommentsAssignment_14
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__SmartContract__CommentsAssignment_14();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop23;
                }
            } while (true);

             after(grammarAccess.getSmartContractAccess().getCommentsAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14__Impl"


    // $ANTLR start "rule__SmartContract__Group__15"
    // InternalSM2.g:1532:1: rule__SmartContract__Group__15 : rule__SmartContract__Group__15__Impl ;
    public final void rule__SmartContract__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1536:1: ( rule__SmartContract__Group__15__Impl )
            // InternalSM2.g:1537:2: rule__SmartContract__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15"


    // $ANTLR start "rule__SmartContract__Group__15__Impl"
    // InternalSM2.g:1543:1: rule__SmartContract__Group__15__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__SmartContract__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1547:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:1548:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:1548:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:1549:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_15()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__0"
    // InternalSM2.g:1559:1: rule__SmartContract__Group_8__0 : rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 ;
    public final void rule__SmartContract__Group_8__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1563:1: ( rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1 )
            // InternalSM2.g:1564:2: rule__SmartContract__Group_8__0__Impl rule__SmartContract__Group_8__1
            {
            pushFollow(FOLLOW_8);
            rule__SmartContract__Group_8__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0"


    // $ANTLR start "rule__SmartContract__Group_8__0__Impl"
    // InternalSM2.g:1571:1: rule__SmartContract__Group_8__0__Impl : ( 'is' ) ;
    public final void rule__SmartContract__Group_8__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1575:1: ( ( 'is' ) )
            // InternalSM2.g:1576:1: ( 'is' )
            {
            // InternalSM2.g:1576:1: ( 'is' )
            // InternalSM2.g:1577:2: 'is'
            {
             before(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getIsKeyword_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__0__Impl"


    // $ANTLR start "rule__SmartContract__Group_8__1"
    // InternalSM2.g:1586:1: rule__SmartContract__Group_8__1 : rule__SmartContract__Group_8__1__Impl ;
    public final void rule__SmartContract__Group_8__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1590:1: ( rule__SmartContract__Group_8__1__Impl )
            // InternalSM2.g:1591:2: rule__SmartContract__Group_8__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_8__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1"


    // $ANTLR start "rule__SmartContract__Group_8__1__Impl"
    // InternalSM2.g:1597:1: rule__SmartContract__Group_8__1__Impl : ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) ;
    public final void rule__SmartContract__Group_8__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1601:1: ( ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) ) )
            // InternalSM2.g:1602:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            {
            // InternalSM2.g:1602:1: ( ( rule__SmartContract__NameContractFatherAssignment_8_1 ) )
            // InternalSM2.g:1603:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 
            // InternalSM2.g:1604:2: ( rule__SmartContract__NameContractFatherAssignment_8_1 )
            // InternalSM2.g:1604:3: rule__SmartContract__NameContractFatherAssignment_8_1
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractFatherAssignment_8_1();

            state._fsp--;


            }

             after(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_8_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_8__1__Impl"


    // $ANTLR start "rule__Version__Group__0"
    // InternalSM2.g:1613:1: rule__Version__Group__0 : rule__Version__Group__0__Impl rule__Version__Group__1 ;
    public final void rule__Version__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1617:1: ( rule__Version__Group__0__Impl rule__Version__Group__1 )
            // InternalSM2.g:1618:2: rule__Version__Group__0__Impl rule__Version__Group__1
            {
            pushFollow(FOLLOW_15);
            rule__Version__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0"


    // $ANTLR start "rule__Version__Group__0__Impl"
    // InternalSM2.g:1625:1: rule__Version__Group__0__Impl : ( ( rule__Version__SymbolAssignment_0 ) ) ;
    public final void rule__Version__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1629:1: ( ( ( rule__Version__SymbolAssignment_0 ) ) )
            // InternalSM2.g:1630:1: ( ( rule__Version__SymbolAssignment_0 ) )
            {
            // InternalSM2.g:1630:1: ( ( rule__Version__SymbolAssignment_0 ) )
            // InternalSM2.g:1631:2: ( rule__Version__SymbolAssignment_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAssignment_0()); 
            // InternalSM2.g:1632:2: ( rule__Version__SymbolAssignment_0 )
            // InternalSM2.g:1632:3: rule__Version__SymbolAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__0__Impl"


    // $ANTLR start "rule__Version__Group__1"
    // InternalSM2.g:1640:1: rule__Version__Group__1 : rule__Version__Group__1__Impl rule__Version__Group__2 ;
    public final void rule__Version__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1644:1: ( rule__Version__Group__1__Impl rule__Version__Group__2 )
            // InternalSM2.g:1645:2: rule__Version__Group__1__Impl rule__Version__Group__2
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1"


    // $ANTLR start "rule__Version__Group__1__Impl"
    // InternalSM2.g:1652:1: rule__Version__Group__1__Impl : ( ( rule__Version__NumberVersionAssignment_1 ) ) ;
    public final void rule__Version__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1656:1: ( ( ( rule__Version__NumberVersionAssignment_1 ) ) )
            // InternalSM2.g:1657:1: ( ( rule__Version__NumberVersionAssignment_1 ) )
            {
            // InternalSM2.g:1657:1: ( ( rule__Version__NumberVersionAssignment_1 ) )
            // InternalSM2.g:1658:2: ( rule__Version__NumberVersionAssignment_1 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersionAssignment_1()); 
            // InternalSM2.g:1659:2: ( rule__Version__NumberVersionAssignment_1 )
            // InternalSM2.g:1659:3: rule__Version__NumberVersionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__1__Impl"


    // $ANTLR start "rule__Version__Group__2"
    // InternalSM2.g:1667:1: rule__Version__Group__2 : rule__Version__Group__2__Impl rule__Version__Group__3 ;
    public final void rule__Version__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1671:1: ( rule__Version__Group__2__Impl rule__Version__Group__3 )
            // InternalSM2.g:1672:2: rule__Version__Group__2__Impl rule__Version__Group__3
            {
            pushFollow(FOLLOW_15);
            rule__Version__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2"


    // $ANTLR start "rule__Version__Group__2__Impl"
    // InternalSM2.g:1679:1: rule__Version__Group__2__Impl : ( '.' ) ;
    public final void rule__Version__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1683:1: ( ( '.' ) )
            // InternalSM2.g:1684:1: ( '.' )
            {
            // InternalSM2.g:1684:1: ( '.' )
            // InternalSM2.g:1685:2: '.'
            {
             before(grammarAccess.getVersionAccess().getFullStopKeyword_2()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__2__Impl"


    // $ANTLR start "rule__Version__Group__3"
    // InternalSM2.g:1694:1: rule__Version__Group__3 : rule__Version__Group__3__Impl rule__Version__Group__4 ;
    public final void rule__Version__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1698:1: ( rule__Version__Group__3__Impl rule__Version__Group__4 )
            // InternalSM2.g:1699:2: rule__Version__Group__3__Impl rule__Version__Group__4
            {
            pushFollow(FOLLOW_16);
            rule__Version__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3"


    // $ANTLR start "rule__Version__Group__3__Impl"
    // InternalSM2.g:1706:1: rule__Version__Group__3__Impl : ( ( rule__Version__NumberVersion2Assignment_3 ) ) ;
    public final void rule__Version__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1710:1: ( ( ( rule__Version__NumberVersion2Assignment_3 ) ) )
            // InternalSM2.g:1711:1: ( ( rule__Version__NumberVersion2Assignment_3 ) )
            {
            // InternalSM2.g:1711:1: ( ( rule__Version__NumberVersion2Assignment_3 ) )
            // InternalSM2.g:1712:2: ( rule__Version__NumberVersion2Assignment_3 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_3()); 
            // InternalSM2.g:1713:2: ( rule__Version__NumberVersion2Assignment_3 )
            // InternalSM2.g:1713:3: rule__Version__NumberVersion2Assignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_3();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__3__Impl"


    // $ANTLR start "rule__Version__Group__4"
    // InternalSM2.g:1721:1: rule__Version__Group__4 : rule__Version__Group__4__Impl rule__Version__Group__5 ;
    public final void rule__Version__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1725:1: ( rule__Version__Group__4__Impl rule__Version__Group__5 )
            // InternalSM2.g:1726:2: rule__Version__Group__4__Impl rule__Version__Group__5
            {
            pushFollow(FOLLOW_15);
            rule__Version__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4"


    // $ANTLR start "rule__Version__Group__4__Impl"
    // InternalSM2.g:1733:1: rule__Version__Group__4__Impl : ( '.' ) ;
    public final void rule__Version__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1737:1: ( ( '.' ) )
            // InternalSM2.g:1738:1: ( '.' )
            {
            // InternalSM2.g:1738:1: ( '.' )
            // InternalSM2.g:1739:2: '.'
            {
             before(grammarAccess.getVersionAccess().getFullStopKeyword_4()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getFullStopKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__4__Impl"


    // $ANTLR start "rule__Version__Group__5"
    // InternalSM2.g:1748:1: rule__Version__Group__5 : rule__Version__Group__5__Impl rule__Version__Group__6 ;
    public final void rule__Version__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1752:1: ( rule__Version__Group__5__Impl rule__Version__Group__6 )
            // InternalSM2.g:1753:2: rule__Version__Group__5__Impl rule__Version__Group__6
            {
            pushFollow(FOLLOW_8);
            rule__Version__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Version__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5"


    // $ANTLR start "rule__Version__Group__5__Impl"
    // InternalSM2.g:1760:1: rule__Version__Group__5__Impl : ( ( rule__Version__NumberVersion3Assignment_5 ) ) ;
    public final void rule__Version__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1764:1: ( ( ( rule__Version__NumberVersion3Assignment_5 ) ) )
            // InternalSM2.g:1765:1: ( ( rule__Version__NumberVersion3Assignment_5 ) )
            {
            // InternalSM2.g:1765:1: ( ( rule__Version__NumberVersion3Assignment_5 ) )
            // InternalSM2.g:1766:2: ( rule__Version__NumberVersion3Assignment_5 )
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_5()); 
            // InternalSM2.g:1767:2: ( rule__Version__NumberVersion3Assignment_5 )
            // InternalSM2.g:1767:3: rule__Version__NumberVersion3Assignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_5();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__5__Impl"


    // $ANTLR start "rule__Version__Group__6"
    // InternalSM2.g:1775:1: rule__Version__Group__6 : rule__Version__Group__6__Impl ;
    public final void rule__Version__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1779:1: ( rule__Version__Group__6__Impl )
            // InternalSM2.g:1780:2: rule__Version__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6"


    // $ANTLR start "rule__Version__Group__6__Impl"
    // InternalSM2.g:1786:1: rule__Version__Group__6__Impl : ( ( rule__Version__OptionalversionAssignment_6 )? ) ;
    public final void rule__Version__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1790:1: ( ( ( rule__Version__OptionalversionAssignment_6 )? ) )
            // InternalSM2.g:1791:1: ( ( rule__Version__OptionalversionAssignment_6 )? )
            {
            // InternalSM2.g:1791:1: ( ( rule__Version__OptionalversionAssignment_6 )? )
            // InternalSM2.g:1792:2: ( rule__Version__OptionalversionAssignment_6 )?
            {
             before(grammarAccess.getVersionAccess().getOptionalversionAssignment_6()); 
            // InternalSM2.g:1793:2: ( rule__Version__OptionalversionAssignment_6 )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==RULE_ID) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalSM2.g:1793:3: rule__Version__OptionalversionAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__OptionalversionAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getVersionAccess().getOptionalversionAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group__6__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:1802:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1806:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:1807:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__Import__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:1814:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1818:1: ( ( 'import' ) )
            // InternalSM2.g:1819:1: ( 'import' )
            {
            // InternalSM2.g:1819:1: ( 'import' )
            // InternalSM2.g:1820:2: 'import'
            {
             before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getImportKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:1829:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1833:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:1834:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Import__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:1841:1: rule__Import__Group__1__Impl : ( ( rule__Import__NameLibraryAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1845:1: ( ( ( rule__Import__NameLibraryAssignment_1 ) ) )
            // InternalSM2.g:1846:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            {
            // InternalSM2.g:1846:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            // InternalSM2.g:1847:2: ( rule__Import__NameLibraryAssignment_1 )
            {
             before(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            // InternalSM2.g:1848:2: ( rule__Import__NameLibraryAssignment_1 )
            // InternalSM2.g:1848:3: rule__Import__NameLibraryAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__NameLibraryAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:1856:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1860:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:1861:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_18);
            rule__Import__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:1868:1: rule__Import__Group__2__Impl : ( ';' ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1872:1: ( ( ';' ) )
            // InternalSM2.g:1873:1: ( ';' )
            {
            // InternalSM2.g:1873:1: ( ';' )
            // InternalSM2.g:1874:2: ';'
            {
             before(grammarAccess.getImportAccess().getSemicolonKeyword_2()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getSemicolonKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:1883:1: rule__Import__Group__3 : rule__Import__Group__3__Impl ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1887:1: ( rule__Import__Group__3__Impl )
            // InternalSM2.g:1888:2: rule__Import__Group__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:1894:1: rule__Import__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1898:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1899:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1899:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1900:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:1901:2: ( RULE_EOLINE )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_EOLINE) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2.g:1901:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:1910:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1914:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:1915:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Modifier__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:1922:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1926:1: ( ( 'modifier' ) )
            // InternalSM2.g:1927:1: ( 'modifier' )
            {
            // InternalSM2.g:1927:1: ( 'modifier' )
            // InternalSM2.g:1928:2: 'modifier'
            {
             before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:1937:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1941:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:1942:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__Modifier__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:1949:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1953:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:1954:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:1954:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:1955:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
             before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            // InternalSM2.g:1956:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:1956:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:1964:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1968:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:1969:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_20);
            rule__Modifier__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:1976:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1980:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:1981:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:1981:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:1982:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:1991:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1995:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:1996:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_20);
            rule__Modifier__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:2003:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2007:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:2008:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:2008:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:2009:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
             before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:2010:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( ((LA26_0>=20 && LA26_0<=27)) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:2010:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_21);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

             after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:2018:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2022:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:2023:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:2030:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2034:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2035:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2035:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2036:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:2045:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2049:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:2050:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_23);
            rule__Modifier__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:2057:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2061:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2062:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2062:1: ( RULE_OPENKEY )
            // InternalSM2.g:2063:2: RULE_OPENKEY
            {
             before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:2072:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2076:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:2077:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_23);
            rule__Modifier__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:2084:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2088:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2089:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2089:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2090:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2091:2: ( RULE_EOLINE )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==RULE_EOLINE) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:2091:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:2099:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2103:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:2104:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Modifier__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:2111:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2115:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:2116:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:2116:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:2117:2: ( rule__Modifier__ExprAssignment_7 )
            {
             before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            // InternalSM2.g:2118:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:2118:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getModifierAccess().getExprAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:2126:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2130:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:2131:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:2138:1: rule__Modifier__Group__8__Impl : ( ';' ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2142:1: ( ( ';' ) )
            // InternalSM2.g:2143:1: ( ';' )
            {
            // InternalSM2.g:2143:1: ( ';' )
            // InternalSM2.g:2144:2: ';'
            {
             before(grammarAccess.getModifierAccess().getSemicolonKeyword_8()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getSemicolonKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:2153:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2157:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:2158:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_24);
            rule__Modifier__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:2165:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2169:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2170:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2170:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2171:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            // InternalSM2.g:2172:2: ( RULE_EOLINE )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_EOLINE) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:2172:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:2180:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2184:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:2185:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_25);
            rule__Modifier__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:2192:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2196:1: ( ( '_;' ) )
            // InternalSM2.g:2197:1: ( '_;' )
            {
            // InternalSM2.g:2197:1: ( '_;' )
            // InternalSM2.g:2198:2: '_;'
            {
             before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().get_Keyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:2207:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2211:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:2212:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_18);
            rule__Modifier__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:2219:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2223:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:2224:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:2224:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:2225:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:2234:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2238:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:2239:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:2245:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2249:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2250:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2250:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2251:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            // InternalSM2.g:2252:2: ( RULE_EOLINE )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==RULE_EOLINE) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalSM2.g:2252:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:2261:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2265:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:2266:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__Mapping__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:2273:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2277:1: ( ( 'mapping' ) )
            // InternalSM2.g:2278:1: ( 'mapping' )
            {
            // InternalSM2.g:2278:1: ( 'mapping' )
            // InternalSM2.g:2279:2: 'mapping'
            {
             before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:2288:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2292:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:2293:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_26);
            rule__Mapping__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:2300:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2304:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:2305:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:2305:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:2306:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:2315:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2319:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:2320:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_27);
            rule__Mapping__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:2327:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2331:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:2332:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:2332:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:2333:2: ( rule__Mapping__TypeAssignment_2 )
            {
             before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            // InternalSM2.g:2334:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:2334:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:2342:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2346:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:2347:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__Mapping__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:2354:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2358:1: ( ( '=>' ) )
            // InternalSM2.g:2359:1: ( '=>' )
            {
            // InternalSM2.g:2359:1: ( '=>' )
            // InternalSM2.g:2360:2: '=>'
            {
             before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            match(input,55,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:2369:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2373:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:2374:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_28);
            rule__Mapping__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:2381:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2385:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:2386:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:2386:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:2387:2: ( rule__Mapping__ExprAssignment_4 )
            {
             before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            // InternalSM2.g:2388:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:2388:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:2396:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2400:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:2401:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:2408:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2412:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:2413:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:2413:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:2414:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:2423:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2427:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:2428:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:2435:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2439:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:2440:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:2440:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:2441:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
             before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            // InternalSM2.g:2442:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( ((LA30_0>=28 && LA30_0<=30)) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:2442:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:2450:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2454:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:2455:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Mapping__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:2462:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2466:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:2467:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:2467:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:2468:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
             before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            // InternalSM2.g:2469:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:2469:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;


            }

             after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:2477:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2481:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:2482:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:2488:1: rule__Mapping__Group__8__Impl : ( ';' ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2492:1: ( ( ';' ) )
            // InternalSM2.g:2493:1: ( ';' )
            {
            // InternalSM2.g:2493:1: ( ';' )
            // InternalSM2.g:2494:2: ';'
            {
             before(grammarAccess.getMappingAccess().getSemicolonKeyword_8()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getSemicolonKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__Struct__Group__0"
    // InternalSM2.g:2504:1: rule__Struct__Group__0 : rule__Struct__Group__0__Impl rule__Struct__Group__1 ;
    public final void rule__Struct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2508:1: ( rule__Struct__Group__0__Impl rule__Struct__Group__1 )
            // InternalSM2.g:2509:2: rule__Struct__Group__0__Impl rule__Struct__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Struct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0"


    // $ANTLR start "rule__Struct__Group__0__Impl"
    // InternalSM2.g:2516:1: rule__Struct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__Struct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2520:1: ( ( 'struct' ) )
            // InternalSM2.g:2521:1: ( 'struct' )
            {
            // InternalSM2.g:2521:1: ( 'struct' )
            // InternalSM2.g:2522:2: 'struct'
            {
             before(grammarAccess.getStructAccess().getStructKeyword_0()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getStructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__0__Impl"


    // $ANTLR start "rule__Struct__Group__1"
    // InternalSM2.g:2531:1: rule__Struct__Group__1 : rule__Struct__Group__1__Impl rule__Struct__Group__2 ;
    public final void rule__Struct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2535:1: ( rule__Struct__Group__1__Impl rule__Struct__Group__2 )
            // InternalSM2.g:2536:2: rule__Struct__Group__1__Impl rule__Struct__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__Struct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1"


    // $ANTLR start "rule__Struct__Group__1__Impl"
    // InternalSM2.g:2543:1: rule__Struct__Group__1__Impl : ( ( rule__Struct__NameStructAssignment_1 ) ) ;
    public final void rule__Struct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2547:1: ( ( ( rule__Struct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:2548:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:2548:1: ( ( rule__Struct__NameStructAssignment_1 ) )
            // InternalSM2.g:2549:2: ( rule__Struct__NameStructAssignment_1 )
            {
             before(grammarAccess.getStructAccess().getNameStructAssignment_1()); 
            // InternalSM2.g:2550:2: ( rule__Struct__NameStructAssignment_1 )
            // InternalSM2.g:2550:3: rule__Struct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Struct__NameStructAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getNameStructAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__1__Impl"


    // $ANTLR start "rule__Struct__Group__2"
    // InternalSM2.g:2558:1: rule__Struct__Group__2 : rule__Struct__Group__2__Impl rule__Struct__Group__3 ;
    public final void rule__Struct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2562:1: ( rule__Struct__Group__2__Impl rule__Struct__Group__3 )
            // InternalSM2.g:2563:2: rule__Struct__Group__2__Impl rule__Struct__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__Struct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2"


    // $ANTLR start "rule__Struct__Group__2__Impl"
    // InternalSM2.g:2570:1: rule__Struct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Struct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2574:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2575:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2575:1: ( RULE_OPENKEY )
            // InternalSM2.g:2576:2: RULE_OPENKEY
            {
             before(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__2__Impl"


    // $ANTLR start "rule__Struct__Group__3"
    // InternalSM2.g:2585:1: rule__Struct__Group__3 : rule__Struct__Group__3__Impl rule__Struct__Group__4 ;
    public final void rule__Struct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2589:1: ( rule__Struct__Group__3__Impl rule__Struct__Group__4 )
            // InternalSM2.g:2590:2: rule__Struct__Group__3__Impl rule__Struct__Group__4
            {
            pushFollow(FOLLOW_30);
            rule__Struct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3"


    // $ANTLR start "rule__Struct__Group__3__Impl"
    // InternalSM2.g:2597:1: rule__Struct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2601:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2602:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2602:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2603:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 
            // InternalSM2.g:2604:2: ( RULE_EOLINE )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==RULE_EOLINE) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2.g:2604:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__3__Impl"


    // $ANTLR start "rule__Struct__Group__4"
    // InternalSM2.g:2612:1: rule__Struct__Group__4 : rule__Struct__Group__4__Impl rule__Struct__Group__5 ;
    public final void rule__Struct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2616:1: ( rule__Struct__Group__4__Impl rule__Struct__Group__5 )
            // InternalSM2.g:2617:2: rule__Struct__Group__4__Impl rule__Struct__Group__5
            {
            pushFollow(FOLLOW_25);
            rule__Struct__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4"


    // $ANTLR start "rule__Struct__Group__4__Impl"
    // InternalSM2.g:2624:1: rule__Struct__Group__4__Impl : ( ( rule__Struct__PropertiesAssignment_4 ) ) ;
    public final void rule__Struct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2628:1: ( ( ( rule__Struct__PropertiesAssignment_4 ) ) )
            // InternalSM2.g:2629:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            {
            // InternalSM2.g:2629:1: ( ( rule__Struct__PropertiesAssignment_4 ) )
            // InternalSM2.g:2630:2: ( rule__Struct__PropertiesAssignment_4 )
            {
             before(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 
            // InternalSM2.g:2631:2: ( rule__Struct__PropertiesAssignment_4 )
            // InternalSM2.g:2631:3: rule__Struct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Struct__PropertiesAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getStructAccess().getPropertiesAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__4__Impl"


    // $ANTLR start "rule__Struct__Group__5"
    // InternalSM2.g:2639:1: rule__Struct__Group__5 : rule__Struct__Group__5__Impl rule__Struct__Group__6 ;
    public final void rule__Struct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2643:1: ( rule__Struct__Group__5__Impl rule__Struct__Group__6 )
            // InternalSM2.g:2644:2: rule__Struct__Group__5__Impl rule__Struct__Group__6
            {
            pushFollow(FOLLOW_18);
            rule__Struct__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Struct__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5"


    // $ANTLR start "rule__Struct__Group__5__Impl"
    // InternalSM2.g:2651:1: rule__Struct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Struct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2655:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:2656:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:2656:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:2657:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__5__Impl"


    // $ANTLR start "rule__Struct__Group__6"
    // InternalSM2.g:2666:1: rule__Struct__Group__6 : rule__Struct__Group__6__Impl ;
    public final void rule__Struct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2670:1: ( rule__Struct__Group__6__Impl )
            // InternalSM2.g:2671:2: rule__Struct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Struct__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6"


    // $ANTLR start "rule__Struct__Group__6__Impl"
    // InternalSM2.g:2677:1: rule__Struct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Struct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2681:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2682:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2682:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2683:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:2684:2: ( RULE_EOLINE )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==RULE_EOLINE) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalSM2.g:2684:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getStructAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:2693:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2697:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:2698:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Enum__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:2705:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2709:1: ( ( 'enum' ) )
            // InternalSM2.g:2710:1: ( 'enum' )
            {
            // InternalSM2.g:2710:1: ( 'enum' )
            // InternalSM2.g:2711:2: 'enum'
            {
             before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            match(input,57,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:2720:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2724:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:2725:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__Enum__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:2732:1: rule__Enum__Group__1__Impl : ( ( rule__Enum__NameEnumAssignment_1 ) ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2736:1: ( ( ( rule__Enum__NameEnumAssignment_1 ) ) )
            // InternalSM2.g:2737:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            {
            // InternalSM2.g:2737:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            // InternalSM2.g:2738:2: ( rule__Enum__NameEnumAssignment_1 )
            {
             before(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            // InternalSM2.g:2739:2: ( rule__Enum__NameEnumAssignment_1 )
            // InternalSM2.g:2739:3: rule__Enum__NameEnumAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Enum__NameEnumAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:2747:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2751:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:2752:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_17);
            rule__Enum__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:2759:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2763:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2764:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2764:1: ( RULE_OPENKEY )
            // InternalSM2.g:2765:2: RULE_OPENKEY
            {
             before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:2774:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2778:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:2779:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_31);
            rule__Enum__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:2786:1: rule__Enum__Group__3__Impl : ( ( rule__Enum__ExprAssignment_3 ) ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2790:1: ( ( ( rule__Enum__ExprAssignment_3 ) ) )
            // InternalSM2.g:2791:1: ( ( rule__Enum__ExprAssignment_3 ) )
            {
            // InternalSM2.g:2791:1: ( ( rule__Enum__ExprAssignment_3 ) )
            // InternalSM2.g:2792:2: ( rule__Enum__ExprAssignment_3 )
            {
             before(grammarAccess.getEnumAccess().getExprAssignment_3()); 
            // InternalSM2.g:2793:2: ( rule__Enum__ExprAssignment_3 )
            // InternalSM2.g:2793:3: rule__Enum__ExprAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Enum__ExprAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getEnumAccess().getExprAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:2801:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2805:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:2806:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Enum__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:2813:1: rule__Enum__Group__4__Impl : ( ( ',' )? ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2817:1: ( ( ( ',' )? ) )
            // InternalSM2.g:2818:1: ( ( ',' )? )
            {
            // InternalSM2.g:2818:1: ( ( ',' )? )
            // InternalSM2.g:2819:2: ( ',' )?
            {
             before(grammarAccess.getEnumAccess().getCommaKeyword_4()); 
            // InternalSM2.g:2820:2: ( ',' )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==58) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalSM2.g:2820:3: ','
                    {
                    match(input,58,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getCommaKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:2828:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2832:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:2833:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Enum__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:2840:1: rule__Enum__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2844:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:2845:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:2845:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:2846:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:2855:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl rule__Enum__Group__7 ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2859:1: ( rule__Enum__Group__6__Impl rule__Enum__Group__7 )
            // InternalSM2.g:2860:2: rule__Enum__Group__6__Impl rule__Enum__Group__7
            {
            pushFollow(FOLLOW_18);
            rule__Enum__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Enum__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:2867:1: rule__Enum__Group__6__Impl : ( ';' ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2871:1: ( ( ';' ) )
            // InternalSM2.g:2872:1: ( ';' )
            {
            // InternalSM2.g:2872:1: ( ';' )
            // InternalSM2.g:2873:2: ';'
            {
             before(grammarAccess.getEnumAccess().getSemicolonKeyword_6()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getSemicolonKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group__7"
    // InternalSM2.g:2882:1: rule__Enum__Group__7 : rule__Enum__Group__7__Impl ;
    public final void rule__Enum__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2886:1: ( rule__Enum__Group__7__Impl )
            // InternalSM2.g:2887:2: rule__Enum__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7"


    // $ANTLR start "rule__Enum__Group__7__Impl"
    // InternalSM2.g:2893:1: rule__Enum__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2897:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2898:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2898:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2899:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 
            // InternalSM2.g:2900:2: ( RULE_EOLINE )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==RULE_EOLINE) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalSM2.g:2900:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__7__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:2909:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2913:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:2914:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__Property__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:2921:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2925:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:2926:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:2926:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:2927:2: ( rule__Property__TypeAssignment_0 )
            {
             before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            // InternalSM2.g:2928:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:2928:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:2936:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2940:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:2941:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__Property__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:2948:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2952:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:2953:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:2953:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:2954:2: ( rule__Property__VisibilityAssignment_1 )?
            {
             before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            // InternalSM2.g:2955:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( ((LA35_0>=28 && LA35_0<=30)) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:2955:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:2963:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2967:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:2968:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_32);
            rule__Property__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:2975:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2979:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:2980:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:2980:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:2981:2: ( rule__Property__NamePropertyAssignment_2 )
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            // InternalSM2.g:2982:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:2982:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:2990:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2994:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:2995:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_33);
            rule__Property__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:3002:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3006:1: ( ( '=' ) )
            // InternalSM2.g:3007:1: ( '=' )
            {
            // InternalSM2.g:3007:1: ( '=' )
            // InternalSM2.g:3008:2: '='
            {
             before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            match(input,59,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:3017:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3021:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:3022:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_33);
            rule__Property__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:3029:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3033:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:3034:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:3034:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:3035:2: ( rule__Property__Alternatives_4 )?
            {
             before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            // InternalSM2.g:3036:2: ( rule__Property__Alternatives_4 )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==RULE_INT||LA36_0==RULE_STRING) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:3036:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getAlternatives_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:3044:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3048:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:3049:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_18);
            rule__Property__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:3056:1: rule__Property__Group__5__Impl : ( ';' ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3060:1: ( ( ';' ) )
            // InternalSM2.g:3061:1: ( ';' )
            {
            // InternalSM2.g:3061:1: ( ';' )
            // InternalSM2.g:3062:2: ';'
            {
             before(grammarAccess.getPropertyAccess().getSemicolonKeyword_5()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getSemicolonKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:3071:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3075:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:3076:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:3082:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3086:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3087:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3087:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3088:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            // InternalSM2.g:3089:2: ( RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:3089:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:3098:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3102:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:3103:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_34);
            rule__InputParam__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:3110:1: rule__InputParam__Group__0__Impl : ( ( rule__InputParam__Group_0__0 ) ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3114:1: ( ( ( rule__InputParam__Group_0__0 ) ) )
            // InternalSM2.g:3115:1: ( ( rule__InputParam__Group_0__0 ) )
            {
            // InternalSM2.g:3115:1: ( ( rule__InputParam__Group_0__0 ) )
            // InternalSM2.g:3116:2: ( rule__InputParam__Group_0__0 )
            {
             before(grammarAccess.getInputParamAccess().getGroup_0()); 
            // InternalSM2.g:3117:2: ( rule__InputParam__Group_0__0 )
            // InternalSM2.g:3117:3: rule__InputParam__Group_0__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getGroup_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:3125:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3129:1: ( rule__InputParam__Group__1__Impl )
            // InternalSM2.g:3130:2: rule__InputParam__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:3136:1: rule__InputParam__Group__1__Impl : ( ( ',' )? ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3140:1: ( ( ( ',' )? ) )
            // InternalSM2.g:3141:1: ( ( ',' )? )
            {
            // InternalSM2.g:3141:1: ( ( ',' )? )
            // InternalSM2.g:3142:2: ( ',' )?
            {
             before(grammarAccess.getInputParamAccess().getCommaKeyword_1()); 
            // InternalSM2.g:3143:2: ( ',' )?
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==58) ) {
                alt38=1;
            }
            switch (alt38) {
                case 1 :
                    // InternalSM2.g:3143:3: ','
                    {
                    match(input,58,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getInputParamAccess().getCommaKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__0"
    // InternalSM2.g:3152:1: rule__InputParam__Group_0__0 : rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 ;
    public final void rule__InputParam__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3156:1: ( rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 )
            // InternalSM2.g:3157:2: rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1
            {
            pushFollow(FOLLOW_8);
            rule__InputParam__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0"


    // $ANTLR start "rule__InputParam__Group_0__0__Impl"
    // InternalSM2.g:3164:1: rule__InputParam__Group_0__0__Impl : ( ( rule__InputParam__TypeAssignment_0_0 ) ) ;
    public final void rule__InputParam__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3168:1: ( ( ( rule__InputParam__TypeAssignment_0_0 ) ) )
            // InternalSM2.g:3169:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            {
            // InternalSM2.g:3169:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            // InternalSM2.g:3170:2: ( rule__InputParam__TypeAssignment_0_0 )
            {
             before(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            // InternalSM2.g:3171:2: ( rule__InputParam__TypeAssignment_0_0 )
            // InternalSM2.g:3171:3: rule__InputParam__TypeAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__TypeAssignment_0_0();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0__1"
    // InternalSM2.g:3179:1: rule__InputParam__Group_0__1 : rule__InputParam__Group_0__1__Impl ;
    public final void rule__InputParam__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3183:1: ( rule__InputParam__Group_0__1__Impl )
            // InternalSM2.g:3184:2: rule__InputParam__Group_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1"


    // $ANTLR start "rule__InputParam__Group_0__1__Impl"
    // InternalSM2.g:3190:1: rule__InputParam__Group_0__1__Impl : ( ( rule__InputParam__NameParamAssignment_0_1 ) ) ;
    public final void rule__InputParam__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3194:1: ( ( ( rule__InputParam__NameParamAssignment_0_1 ) ) )
            // InternalSM2.g:3195:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            {
            // InternalSM2.g:3195:1: ( ( rule__InputParam__NameParamAssignment_0_1 ) )
            // InternalSM2.g:3196:2: ( rule__InputParam__NameParamAssignment_0_1 )
            {
             before(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 
            // InternalSM2.g:3197:2: ( rule__InputParam__NameParamAssignment_0_1 )
            // InternalSM2.g:3197:3: rule__InputParam__NameParamAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getInputParamAccess().getNameParamAssignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:3206:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3210:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:3211:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__Restriction__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:3218:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3222:1: ( ( 'require' ) )
            // InternalSM2.g:3223:1: ( 'require' )
            {
            // InternalSM2.g:3223:1: ( 'require' )
            // InternalSM2.g:3224:2: 'require'
            {
             before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:3233:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3237:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:3238:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_35);
            rule__Restriction__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:3245:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3249:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3250:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3250:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3251:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:3260:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3264:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:3265:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__Restriction__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:3272:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__ExprAssignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3276:1: ( ( ( rule__Restriction__ExprAssignment_2 ) ) )
            // InternalSM2.g:3277:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            {
            // InternalSM2.g:3277:1: ( ( rule__Restriction__ExprAssignment_2 ) )
            // InternalSM2.g:3278:2: ( rule__Restriction__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 
            // InternalSM2.g:3279:2: ( rule__Restriction__ExprAssignment_2 )
            // InternalSM2.g:3279:3: rule__Restriction__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:3287:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3291:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:3292:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__Restriction__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:3299:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3303:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:3304:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:3304:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:3305:2: ( rule__Restriction__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:3306:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:3306:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:3314:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3318:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:3319:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_28);
            rule__Restriction__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:3326:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__ExprAssignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3330:1: ( ( ( rule__Restriction__ExprAssignment_4 ) ) )
            // InternalSM2.g:3331:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            {
            // InternalSM2.g:3331:1: ( ( rule__Restriction__ExprAssignment_4 ) )
            // InternalSM2.g:3332:2: ( rule__Restriction__ExprAssignment_4 )
            {
             before(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 
            // InternalSM2.g:3333:2: ( rule__Restriction__ExprAssignment_4 )
            // InternalSM2.g:3333:3: rule__Restriction__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__ExprAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionAccess().getExprAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:3341:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3345:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:3346:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Restriction__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:3353:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3357:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3358:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3358:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3359:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:3368:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3372:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:3373:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_18);
            rule__Restriction__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:3380:1: rule__Restriction__Group__6__Impl : ( ';' ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3384:1: ( ( ';' ) )
            // InternalSM2.g:3385:1: ( ';' )
            {
            // InternalSM2.g:3385:1: ( ';' )
            // InternalSM2.g:3386:2: ';'
            {
             before(grammarAccess.getRestrictionAccess().getSemicolonKeyword_6()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getSemicolonKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:3395:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3399:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:3400:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:3406:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3410:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3411:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3411:1: ( RULE_EOLINE )
            // InternalSM2.g:3412:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:3422:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3426:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:3427:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:3434:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3438:1: ( ( 'require' ) )
            // InternalSM2.g:3439:1: ( 'require' )
            {
            // InternalSM2.g:3439:1: ( 'require' )
            // InternalSM2.g:3440:2: 'require'
            {
             before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            match(input,60,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:3449:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3453:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:3454:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_35);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:3461:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3465:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3466:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3466:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3467:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:3476:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3480:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:3481:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:3488:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3492:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:3493:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:3493:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:3494:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
             before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            // InternalSM2.g:3495:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:3495:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:3503:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3507:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:3508:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_37);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:3515:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3519:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:3520:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:3520:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:3521:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            // InternalSM2.g:3522:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:3522:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:3530:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3534:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:3535:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_38);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:3542:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3546:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:3547:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:3547:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:3548:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            // InternalSM2.g:3549:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:3549:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:3557:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3561:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:3562:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_28);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:3569:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3573:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:3574:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:3574:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:3575:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            // InternalSM2.g:3576:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:3576:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:3584:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3588:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:3589:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:3596:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3600:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3601:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3601:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3602:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:3611:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3615:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:3616:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_18);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:3623:1: rule__RestrictionGas__Group__7__Impl : ( ';' ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3627:1: ( ( ';' ) )
            // InternalSM2.g:3628:1: ( ';' )
            {
            // InternalSM2.g:3628:1: ( ';' )
            // InternalSM2.g:3629:2: ';'
            {
             before(grammarAccess.getRestrictionGasAccess().getSemicolonKeyword_7()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getSemicolonKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:3638:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3642:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:3643:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:3649:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3653:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3654:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3654:1: ( RULE_EOLINE )
            // InternalSM2.g:3655:2: RULE_EOLINE
            {
             before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:3665:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3669:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:3670:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:3677:1: rule__Clause__Group__0__Impl : ( 'function' ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3681:1: ( ( 'function' ) )
            // InternalSM2.g:3682:1: ( 'function' )
            {
            // InternalSM2.g:3682:1: ( 'function' )
            // InternalSM2.g:3683:2: 'function'
            {
             before(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 
            match(input,61,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getFunctionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:3692:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3696:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:3697:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_19);
            rule__Clause__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:3704:1: rule__Clause__Group__1__Impl : ( ( rule__Clause__NameFunctionAssignment_1 ) ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3708:1: ( ( ( rule__Clause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:3709:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:3709:1: ( ( rule__Clause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:3710:2: ( rule__Clause__NameFunctionAssignment_1 )
            {
             before(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 
            // InternalSM2.g:3711:2: ( rule__Clause__NameFunctionAssignment_1 )
            // InternalSM2.g:3711:3: rule__Clause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Clause__NameFunctionAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getNameFunctionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:3719:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3723:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:3724:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_8);
            rule__Clause__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:3731:1: rule__Clause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3735:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3736:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3736:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3737:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:3746:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3750:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:3751:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_39);
            rule__Clause__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:3758:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__InputParamsAssignment_3 ) ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3762:1: ( ( ( rule__Clause__InputParamsAssignment_3 ) ) )
            // InternalSM2.g:3763:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            {
            // InternalSM2.g:3763:1: ( ( rule__Clause__InputParamsAssignment_3 ) )
            // InternalSM2.g:3764:2: ( rule__Clause__InputParamsAssignment_3 )
            {
             before(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 
            // InternalSM2.g:3765:2: ( rule__Clause__InputParamsAssignment_3 )
            // InternalSM2.g:3765:3: rule__Clause__InputParamsAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Clause__InputParamsAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getInputParamsAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:3773:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3777:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:3778:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_28);
            rule__Clause__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:3785:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3789:1: ( ( ( rule__Clause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:3790:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:3790:1: ( ( rule__Clause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:3791:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 
            // InternalSM2.g:3792:2: ( rule__Clause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:3792:3: rule__Clause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Clause__VisibilityAccessAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getClauseAccess().getVisibilityAccessAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:3800:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3804:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:3805:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_22);
            rule__Clause__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:3812:1: rule__Clause__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3816:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3817:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3817:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3818:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:3827:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3831:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:3832:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_18);
            rule__Clause__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:3839:1: rule__Clause__Group__6__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3843:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3844:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3844:1: ( RULE_OPENKEY )
            // InternalSM2.g:3845:2: RULE_OPENKEY
            {
             before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6()); 
            match(input,RULE_OPENKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:3854:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3858:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:3859:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_40);
            rule__Clause__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:3866:1: rule__Clause__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3870:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3871:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3871:1: ( RULE_EOLINE )
            // InternalSM2.g:3872:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:3881:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3885:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:3886:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_40);
            rule__Clause__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:3893:1: rule__Clause__Group__8__Impl : ( ( rule__Clause__RestrictionAssignment_8 )? ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3897:1: ( ( ( rule__Clause__RestrictionAssignment_8 )? ) )
            // InternalSM2.g:3898:1: ( ( rule__Clause__RestrictionAssignment_8 )? )
            {
            // InternalSM2.g:3898:1: ( ( rule__Clause__RestrictionAssignment_8 )? )
            // InternalSM2.g:3899:2: ( rule__Clause__RestrictionAssignment_8 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionAssignment_8()); 
            // InternalSM2.g:3900:2: ( rule__Clause__RestrictionAssignment_8 )?
            int alt39=2;
            alt39 = dfa39.predict(input);
            switch (alt39) {
                case 1 :
                    // InternalSM2.g:3900:3: rule__Clause__RestrictionAssignment_8
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_8();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:3908:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl rule__Clause__Group__10 ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3912:1: ( rule__Clause__Group__9__Impl rule__Clause__Group__10 )
            // InternalSM2.g:3913:2: rule__Clause__Group__9__Impl rule__Clause__Group__10
            {
            pushFollow(FOLLOW_40);
            rule__Clause__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:3920:1: rule__Clause__Group__9__Impl : ( ( rule__Clause__RestrictionGasAssignment_9 )? ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3924:1: ( ( ( rule__Clause__RestrictionGasAssignment_9 )? ) )
            // InternalSM2.g:3925:1: ( ( rule__Clause__RestrictionGasAssignment_9 )? )
            {
            // InternalSM2.g:3925:1: ( ( rule__Clause__RestrictionGasAssignment_9 )? )
            // InternalSM2.g:3926:2: ( rule__Clause__RestrictionGasAssignment_9 )?
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasAssignment_9()); 
            // InternalSM2.g:3927:2: ( rule__Clause__RestrictionGasAssignment_9 )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==60) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalSM2.g:3927:3: rule__Clause__RestrictionGasAssignment_9
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionGasAssignment_9();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getRestrictionGasAssignment_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__Clause__Group__10"
    // InternalSM2.g:3935:1: rule__Clause__Group__10 : rule__Clause__Group__10__Impl rule__Clause__Group__11 ;
    public final void rule__Clause__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3939:1: ( rule__Clause__Group__10__Impl rule__Clause__Group__11 )
            // InternalSM2.g:3940:2: rule__Clause__Group__10__Impl rule__Clause__Group__11
            {
            pushFollow(FOLLOW_40);
            rule__Clause__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10"


    // $ANTLR start "rule__Clause__Group__10__Impl"
    // InternalSM2.g:3947:1: rule__Clause__Group__10__Impl : ( ( rule__Clause__ExpressionAssignment_10 )? ) ;
    public final void rule__Clause__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3951:1: ( ( ( rule__Clause__ExpressionAssignment_10 )? ) )
            // InternalSM2.g:3952:1: ( ( rule__Clause__ExpressionAssignment_10 )? )
            {
            // InternalSM2.g:3952:1: ( ( rule__Clause__ExpressionAssignment_10 )? )
            // InternalSM2.g:3953:2: ( rule__Clause__ExpressionAssignment_10 )?
            {
             before(grammarAccess.getClauseAccess().getExpressionAssignment_10()); 
            // InternalSM2.g:3954:2: ( rule__Clause__ExpressionAssignment_10 )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==RULE_INT||LA41_0==RULE_OPENPARENTHESIS||LA41_0==RULE_STRING) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalSM2.g:3954:3: rule__Clause__ExpressionAssignment_10
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__ExpressionAssignment_10();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getExpressionAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__10__Impl"


    // $ANTLR start "rule__Clause__Group__11"
    // InternalSM2.g:3962:1: rule__Clause__Group__11 : rule__Clause__Group__11__Impl rule__Clause__Group__12 ;
    public final void rule__Clause__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3966:1: ( rule__Clause__Group__11__Impl rule__Clause__Group__12 )
            // InternalSM2.g:3967:2: rule__Clause__Group__11__Impl rule__Clause__Group__12
            {
            pushFollow(FOLLOW_40);
            rule__Clause__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11"


    // $ANTLR start "rule__Clause__Group__11__Impl"
    // InternalSM2.g:3974:1: rule__Clause__Group__11__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3978:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3979:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3979:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3980:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_11()); 
            // InternalSM2.g:3981:2: ( RULE_EOLINE )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==RULE_EOLINE) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalSM2.g:3981:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__11__Impl"


    // $ANTLR start "rule__Clause__Group__12"
    // InternalSM2.g:3989:1: rule__Clause__Group__12 : rule__Clause__Group__12__Impl rule__Clause__Group__13 ;
    public final void rule__Clause__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3993:1: ( rule__Clause__Group__12__Impl rule__Clause__Group__13 )
            // InternalSM2.g:3994:2: rule__Clause__Group__12__Impl rule__Clause__Group__13
            {
            pushFollow(FOLLOW_18);
            rule__Clause__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Clause__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12"


    // $ANTLR start "rule__Clause__Group__12__Impl"
    // InternalSM2.g:4001:1: rule__Clause__Group__12__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4005:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4006:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4006:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4007:2: RULE_CLOSEKEY
            {
             before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_12()); 
            match(input,RULE_CLOSEKEY,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__12__Impl"


    // $ANTLR start "rule__Clause__Group__13"
    // InternalSM2.g:4016:1: rule__Clause__Group__13 : rule__Clause__Group__13__Impl ;
    public final void rule__Clause__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4020:1: ( rule__Clause__Group__13__Impl )
            // InternalSM2.g:4021:2: rule__Clause__Group__13__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__13__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13"


    // $ANTLR start "rule__Clause__Group__13__Impl"
    // InternalSM2.g:4027:1: rule__Clause__Group__13__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4031:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4032:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4032:1: ( RULE_EOLINE )
            // InternalSM2.g:4033:2: RULE_EOLINE
            {
             before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_13()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__13__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__0"
    // InternalSM2.g:4043:1: rule__Selfdestruct__Group__0 : rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 ;
    public final void rule__Selfdestruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4047:1: ( rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1 )
            // InternalSM2.g:4048:2: rule__Selfdestruct__Group__0__Impl rule__Selfdestruct__Group__1
            {
            pushFollow(FOLLOW_19);
            rule__Selfdestruct__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0"


    // $ANTLR start "rule__Selfdestruct__Group__0__Impl"
    // InternalSM2.g:4055:1: rule__Selfdestruct__Group__0__Impl : ( 'selfdesctruct' ) ;
    public final void rule__Selfdestruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4059:1: ( ( 'selfdesctruct' ) )
            // InternalSM2.g:4060:1: ( 'selfdesctruct' )
            {
            // InternalSM2.g:4060:1: ( 'selfdesctruct' )
            // InternalSM2.g:4061:2: 'selfdesctruct'
            {
             before(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 
            match(input,62,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__0__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__1"
    // InternalSM2.g:4070:1: rule__Selfdestruct__Group__1 : rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 ;
    public final void rule__Selfdestruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4074:1: ( rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2 )
            // InternalSM2.g:4075:2: rule__Selfdestruct__Group__1__Impl rule__Selfdestruct__Group__2
            {
            pushFollow(FOLLOW_28);
            rule__Selfdestruct__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1"


    // $ANTLR start "rule__Selfdestruct__Group__1__Impl"
    // InternalSM2.g:4082:1: rule__Selfdestruct__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4086:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4087:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4087:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4088:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getOPENPARENTHESISTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__1__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__2"
    // InternalSM2.g:4097:1: rule__Selfdestruct__Group__2 : rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 ;
    public final void rule__Selfdestruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4101:1: ( rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3 )
            // InternalSM2.g:4102:2: rule__Selfdestruct__Group__2__Impl rule__Selfdestruct__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__Selfdestruct__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2"


    // $ANTLR start "rule__Selfdestruct__Group__2__Impl"
    // InternalSM2.g:4109:1: rule__Selfdestruct__Group__2__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Selfdestruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4113:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4114:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4114:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4115:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_2()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getCLOSEPARENTHESISTerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__2__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__3"
    // InternalSM2.g:4124:1: rule__Selfdestruct__Group__3 : rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 ;
    public final void rule__Selfdestruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4128:1: ( rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4 )
            // InternalSM2.g:4129:2: rule__Selfdestruct__Group__3__Impl rule__Selfdestruct__Group__4
            {
            pushFollow(FOLLOW_18);
            rule__Selfdestruct__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3"


    // $ANTLR start "rule__Selfdestruct__Group__3__Impl"
    // InternalSM2.g:4136:1: rule__Selfdestruct__Group__3__Impl : ( ';' ) ;
    public final void rule__Selfdestruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4140:1: ( ( ';' ) )
            // InternalSM2.g:4141:1: ( ';' )
            {
            // InternalSM2.g:4141:1: ( ';' )
            // InternalSM2.g:4142:2: ';'
            {
             before(grammarAccess.getSelfdestructAccess().getSemicolonKeyword_3()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getSelfdestructAccess().getSemicolonKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__3__Impl"


    // $ANTLR start "rule__Selfdestruct__Group__4"
    // InternalSM2.g:4151:1: rule__Selfdestruct__Group__4 : rule__Selfdestruct__Group__4__Impl ;
    public final void rule__Selfdestruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4155:1: ( rule__Selfdestruct__Group__4__Impl )
            // InternalSM2.g:4156:2: rule__Selfdestruct__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Selfdestruct__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4"


    // $ANTLR start "rule__Selfdestruct__Group__4__Impl"
    // InternalSM2.g:4162:1: rule__Selfdestruct__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Selfdestruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4166:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4167:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4167:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4168:2: ( RULE_EOLINE )?
            {
             before(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_4()); 
            // InternalSM2.g:4169:2: ( RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:4169:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getSelfdestructAccess().getEOLINETerminalRuleCall_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Selfdestruct__Group__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0"
    // InternalSM2.g:4178:1: rule__ArithmethicalExpression__Group_0__0 : rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 ;
    public final void rule__ArithmethicalExpression__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4182:1: ( rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 )
            // InternalSM2.g:4183:2: rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1
            {
            pushFollow(FOLLOW_37);
            rule__ArithmethicalExpression__Group_0__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0__Impl"
    // InternalSM2.g:4190:1: rule__ArithmethicalExpression__Group_0__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4194:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:4195:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:4195:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:4196:2: RULE_OPENPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1"
    // InternalSM2.g:4205:1: rule__ArithmethicalExpression__Group_0__1 : rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 ;
    public final void rule__ArithmethicalExpression__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4209:1: ( rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 )
            // InternalSM2.g:4210:2: rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2
            {
            pushFollow(FOLLOW_41);
            rule__ArithmethicalExpression__Group_0__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1__Impl"
    // InternalSM2.g:4217:1: rule__ArithmethicalExpression__Group_0__1__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4221:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) )
            // InternalSM2.g:4222:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            {
            // InternalSM2.g:4222:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            // InternalSM2.g:4223:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            // InternalSM2.g:4224:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            // InternalSM2.g:4224:3: rule__ArithmethicalExpression__Op1Assignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_0_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2"
    // InternalSM2.g:4232:1: rule__ArithmethicalExpression__Group_0__2 : rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 ;
    public final void rule__ArithmethicalExpression__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4236:1: ( rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 )
            // InternalSM2.g:4237:2: rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3
            {
            pushFollow(FOLLOW_37);
            rule__ArithmethicalExpression__Group_0__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2__Impl"
    // InternalSM2.g:4244:1: rule__ArithmethicalExpression__Group_0__2__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4248:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) )
            // InternalSM2.g:4249:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            {
            // InternalSM2.g:4249:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            // InternalSM2.g:4250:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            // InternalSM2.g:4251:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            // InternalSM2.g:4251:3: rule__ArithmethicalExpression__OperatorAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_0_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3"
    // InternalSM2.g:4259:1: rule__ArithmethicalExpression__Group_0__3 : rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 ;
    public final void rule__ArithmethicalExpression__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4263:1: ( rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 )
            // InternalSM2.g:4264:2: rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4
            {
            pushFollow(FOLLOW_28);
            rule__ArithmethicalExpression__Group_0__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3__Impl"
    // InternalSM2.g:4271:1: rule__ArithmethicalExpression__Group_0__3__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4275:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) )
            // InternalSM2.g:4276:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            {
            // InternalSM2.g:4276:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            // InternalSM2.g:4277:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            // InternalSM2.g:4278:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            // InternalSM2.g:4278:3: rule__ArithmethicalExpression__Op2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_0_3();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4"
    // InternalSM2.g:4286:1: rule__ArithmethicalExpression__Group_0__4 : rule__ArithmethicalExpression__Group_0__4__Impl ;
    public final void rule__ArithmethicalExpression__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4290:1: ( rule__ArithmethicalExpression__Group_0__4__Impl )
            // InternalSM2.g:4291:2: rule__ArithmethicalExpression__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4__Impl"
    // InternalSM2.g:4297:1: rule__ArithmethicalExpression__Group_0__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4301:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4302:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4302:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4303:2: RULE_CLOSEPARENTHESIS
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0"
    // InternalSM2.g:4313:1: rule__ArithmethicalExpression__Group_1__0 : rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 ;
    public final void rule__ArithmethicalExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4317:1: ( rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 )
            // InternalSM2.g:4318:2: rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1
            {
            pushFollow(FOLLOW_41);
            rule__ArithmethicalExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0__Impl"
    // InternalSM2.g:4325:1: rule__ArithmethicalExpression__Group_1__0__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4329:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) )
            // InternalSM2.g:4330:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            {
            // InternalSM2.g:4330:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            // InternalSM2.g:4331:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            // InternalSM2.g:4332:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            // InternalSM2.g:4332:3: rule__ArithmethicalExpression__Op1Assignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_1_0();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1"
    // InternalSM2.g:4340:1: rule__ArithmethicalExpression__Group_1__1 : rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 ;
    public final void rule__ArithmethicalExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4344:1: ( rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 )
            // InternalSM2.g:4345:2: rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2
            {
            pushFollow(FOLLOW_37);
            rule__ArithmethicalExpression__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1__Impl"
    // InternalSM2.g:4352:1: rule__ArithmethicalExpression__Group_1__1__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4356:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) )
            // InternalSM2.g:4357:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            {
            // InternalSM2.g:4357:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            // InternalSM2.g:4358:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            // InternalSM2.g:4359:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            // InternalSM2.g:4359:3: rule__ArithmethicalExpression__OperatorAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2"
    // InternalSM2.g:4367:1: rule__ArithmethicalExpression__Group_1__2 : rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 ;
    public final void rule__ArithmethicalExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4371:1: ( rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 )
            // InternalSM2.g:4372:2: rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalExpression__Group_1__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2__Impl"
    // InternalSM2.g:4379:1: rule__ArithmethicalExpression__Group_1__2__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4383:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) )
            // InternalSM2.g:4384:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            {
            // InternalSM2.g:4384:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            // InternalSM2.g:4385:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            // InternalSM2.g:4386:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            // InternalSM2.g:4386:3: rule__ArithmethicalExpression__Op2Assignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_1_2();

            state._fsp--;


            }

             after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3"
    // InternalSM2.g:4394:1: rule__ArithmethicalExpression__Group_1__3 : rule__ArithmethicalExpression__Group_1__3__Impl ;
    public final void rule__ArithmethicalExpression__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4398:1: ( rule__ArithmethicalExpression__Group_1__3__Impl )
            // InternalSM2.g:4399:2: rule__ArithmethicalExpression__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3__Impl"
    // InternalSM2.g:4405:1: rule__ArithmethicalExpression__Group_1__3__Impl : ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) ;
    public final void rule__ArithmethicalExpression__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4409:1: ( ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) )
            // InternalSM2.g:4410:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            {
            // InternalSM2.g:4410:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            // InternalSM2.g:4411:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            // InternalSM2.g:4412:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==48) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalSM2.g:4412:3: rule__ArithmethicalExpression__Group_1_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0"
    // InternalSM2.g:4421:1: rule__ArithmethicalExpression__Group_1_3__0 : rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 ;
    public final void rule__ArithmethicalExpression__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4425:1: ( rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 )
            // InternalSM2.g:4426:2: rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1
            {
            pushFollow(FOLLOW_18);
            rule__ArithmethicalExpression__Group_1_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0__Impl"
    // InternalSM2.g:4433:1: rule__ArithmethicalExpression__Group_1_3__0__Impl : ( ';' ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4437:1: ( ( ';' ) )
            // InternalSM2.g:4438:1: ( ';' )
            {
            // InternalSM2.g:4438:1: ( ';' )
            // InternalSM2.g:4439:2: ';'
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getSemicolonKeyword_1_3_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getSemicolonKeyword_1_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1"
    // InternalSM2.g:4448:1: rule__ArithmethicalExpression__Group_1_3__1 : rule__ArithmethicalExpression__Group_1_3__1__Impl ;
    public final void rule__ArithmethicalExpression__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4452:1: ( rule__ArithmethicalExpression__Group_1_3__1__Impl )
            // InternalSM2.g:4453:2: rule__ArithmethicalExpression__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1__Impl"
    // InternalSM2.g:4459:1: rule__ArithmethicalExpression__Group_1_3__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4463:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4464:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4464:1: ( RULE_EOLINE )
            // InternalSM2.g:4465:2: RULE_EOLINE
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:4475:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4479:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:4480:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_5);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:4487:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_INT ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4491:1: ( ( RULE_INT ) )
            // InternalSM2.g:4492:1: ( RULE_INT )
            {
            // InternalSM2.g:4492:1: ( RULE_INT )
            // InternalSM2.g:4493:2: RULE_INT
            {
             before(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:4502:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4506:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:4507:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:4513:1: rule__SyntaxExpression__Group_1__1__Impl : ( ( rule__SyntaxExpression__Group_1_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4517:1: ( ( ( rule__SyntaxExpression__Group_1_1__0 )? ) )
            // InternalSM2.g:4518:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            {
            // InternalSM2.g:4518:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            // InternalSM2.g:4519:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            {
             before(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            // InternalSM2.g:4520:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==48) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:4520:3: rule__SyntaxExpression__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1_1__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0"
    // InternalSM2.g:4529:1: rule__SyntaxExpression__Group_1_1__0 : rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 ;
    public final void rule__SyntaxExpression__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4533:1: ( rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 )
            // InternalSM2.g:4534:2: rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1
            {
            pushFollow(FOLLOW_18);
            rule__SyntaxExpression__Group_1_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0__Impl"
    // InternalSM2.g:4541:1: rule__SyntaxExpression__Group_1_1__0__Impl : ( ';' ) ;
    public final void rule__SyntaxExpression__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4545:1: ( ( ';' ) )
            // InternalSM2.g:4546:1: ( ';' )
            {
            // InternalSM2.g:4546:1: ( ';' )
            // InternalSM2.g:4547:2: ';'
            {
             before(grammarAccess.getSyntaxExpressionAccess().getSemicolonKeyword_1_1_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getSemicolonKeyword_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1"
    // InternalSM2.g:4556:1: rule__SyntaxExpression__Group_1_1__1 : rule__SyntaxExpression__Group_1_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4560:1: ( rule__SyntaxExpression__Group_1_1__1__Impl )
            // InternalSM2.g:4561:2: rule__SyntaxExpression__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1__Impl"
    // InternalSM2.g:4567:1: rule__SyntaxExpression__Group_1_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4571:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4572:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4572:1: ( RULE_EOLINE )
            // InternalSM2.g:4573:2: RULE_EOLINE
            {
             before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:4583:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4587:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:4588:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:4595:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4599:1: ( ( '//' ) )
            // InternalSM2.g:4600:1: ( '//' )
            {
            // InternalSM2.g:4600:1: ( '//' )
            // InternalSM2.g:4601:2: '//'
            {
             before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            match(input,63,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:4610:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4614:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:4615:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_18);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:4622:1: rule__ShortComment__Group__1__Impl : ( ( rule__ShortComment__ExprAssignment_1 ) ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4626:1: ( ( ( rule__ShortComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:4627:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:4627:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            // InternalSM2.g:4628:2: ( rule__ShortComment__ExprAssignment_1 )
            {
             before(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            // InternalSM2.g:4629:2: ( rule__ShortComment__ExprAssignment_1 )
            // InternalSM2.g:4629:3: rule__ShortComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__ExprAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:4637:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4641:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:4642:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:4648:1: rule__ShortComment__Group__2__Impl : ( RULE_EOLINE ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4652:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:4653:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:4653:1: ( RULE_EOLINE )
            // InternalSM2.g:4654:2: RULE_EOLINE
            {
             before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            match(input,RULE_EOLINE,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:4664:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4668:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:4669:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_17);
            rule__LongComment__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:4676:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4680:1: ( ( '/*' ) )
            // InternalSM2.g:4681:1: ( '/*' )
            {
            // InternalSM2.g:4681:1: ( '/*' )
            // InternalSM2.g:4682:2: '/*'
            {
             before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            match(input,64,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:4691:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4695:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:4696:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_42);
            rule__LongComment__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:4703:1: rule__LongComment__Group__1__Impl : ( ( rule__LongComment__ExprAssignment_1 ) ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4707:1: ( ( ( rule__LongComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:4708:1: ( ( rule__LongComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:4708:1: ( ( rule__LongComment__ExprAssignment_1 ) )
            // InternalSM2.g:4709:2: ( rule__LongComment__ExprAssignment_1 )
            {
             before(grammarAccess.getLongCommentAccess().getExprAssignment_1()); 
            // InternalSM2.g:4710:2: ( rule__LongComment__ExprAssignment_1 )
            // InternalSM2.g:4710:3: rule__LongComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExprAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getLongCommentAccess().getExprAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:4718:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4722:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:4723:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:4729:1: rule__LongComment__Group__2__Impl : ( '*/' ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4733:1: ( ( '*/' ) )
            // InternalSM2.g:4734:1: ( '*/' )
            {
            // InternalSM2.g:4734:1: ( '*/' )
            // InternalSM2.g:4735:2: '*/'
            {
             before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            match(input,65,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__CompilerAssignment_0"
    // InternalSM2.g:4745:1: rule__SmartContract__CompilerAssignment_0 : ( ( 'pragma' ) ) ;
    public final void rule__SmartContract__CompilerAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4749:1: ( ( ( 'pragma' ) ) )
            // InternalSM2.g:4750:2: ( ( 'pragma' ) )
            {
            // InternalSM2.g:4750:2: ( ( 'pragma' ) )
            // InternalSM2.g:4751:3: ( 'pragma' )
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            // InternalSM2.g:4752:3: ( 'pragma' )
            // InternalSM2.g:4753:4: 'pragma'
            {
             before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            match(input,66,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CompilerAssignment_0"


    // $ANTLR start "rule__SmartContract__VersionCompilerAssignment_2"
    // InternalSM2.g:4764:1: rule__SmartContract__VersionCompilerAssignment_2 : ( ruleVersion ) ;
    public final void rule__SmartContract__VersionCompilerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4768:1: ( ( ruleVersion ) )
            // InternalSM2.g:4769:2: ( ruleVersion )
            {
            // InternalSM2.g:4769:2: ( ruleVersion )
            // InternalSM2.g:4770:3: ruleVersion
            {
             before(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__VersionCompilerAssignment_2"


    // $ANTLR start "rule__SmartContract__ImportsAssignment_5"
    // InternalSM2.g:4779:1: rule__SmartContract__ImportsAssignment_5 : ( ruleImport ) ;
    public final void rule__SmartContract__ImportsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4783:1: ( ( ruleImport ) )
            // InternalSM2.g:4784:2: ( ruleImport )
            {
            // InternalSM2.g:4784:2: ( ruleImport )
            // InternalSM2.g:4785:3: ruleImport
            {
             before(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ImportsAssignment_5"


    // $ANTLR start "rule__SmartContract__ContractAssignment_6"
    // InternalSM2.g:4794:1: rule__SmartContract__ContractAssignment_6 : ( ( 'contract' ) ) ;
    public final void rule__SmartContract__ContractAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4798:1: ( ( ( 'contract' ) ) )
            // InternalSM2.g:4799:2: ( ( 'contract' ) )
            {
            // InternalSM2.g:4799:2: ( ( 'contract' ) )
            // InternalSM2.g:4800:3: ( 'contract' )
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            // InternalSM2.g:4801:3: ( 'contract' )
            // InternalSM2.g:4802:4: 'contract'
            {
             before(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 
            match(input,67,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }

             after(grammarAccess.getSmartContractAccess().getContractContractKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ContractAssignment_6"


    // $ANTLR start "rule__SmartContract__NameContractAssignment_7"
    // InternalSM2.g:4813:1: rule__SmartContract__NameContractAssignment_7 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4817:1: ( ( RULE_ID ) )
            // InternalSM2.g:4818:2: ( RULE_ID )
            {
            // InternalSM2.g:4818:2: ( RULE_ID )
            // InternalSM2.g:4819:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractAssignment_7"


    // $ANTLR start "rule__SmartContract__NameContractFatherAssignment_8_1"
    // InternalSM2.g:4828:1: rule__SmartContract__NameContractFatherAssignment_8_1 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractFatherAssignment_8_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4832:1: ( ( RULE_ID ) )
            // InternalSM2.g:4833:2: ( RULE_ID )
            {
            // InternalSM2.g:4833:2: ( RULE_ID )
            // InternalSM2.g:4834:3: RULE_ID
            {
             before(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_8_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractFatherAssignment_8_1"


    // $ANTLR start "rule__SmartContract__AttributesAssignment_11"
    // InternalSM2.g:4843:1: rule__SmartContract__AttributesAssignment_11 : ( ruleAttributes ) ;
    public final void rule__SmartContract__AttributesAssignment_11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4847:1: ( ( ruleAttributes ) )
            // InternalSM2.g:4848:2: ( ruleAttributes )
            {
            // InternalSM2.g:4848:2: ( ruleAttributes )
            // InternalSM2.g:4849:3: ruleAttributes
            {
             before(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__AttributesAssignment_11"


    // $ANTLR start "rule__SmartContract__ModifierAssignment_12"
    // InternalSM2.g:4858:1: rule__SmartContract__ModifierAssignment_12 : ( ruleModifier ) ;
    public final void rule__SmartContract__ModifierAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4862:1: ( ( ruleModifier ) )
            // InternalSM2.g:4863:2: ( ruleModifier )
            {
            // InternalSM2.g:4863:2: ( ruleModifier )
            // InternalSM2.g:4864:3: ruleModifier
            {
             before(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_12_0()); 
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_12_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ModifierAssignment_12"


    // $ANTLR start "rule__SmartContract__ClausesAssignment_13"
    // InternalSM2.g:4873:1: rule__SmartContract__ClausesAssignment_13 : ( ruleClause ) ;
    public final void rule__SmartContract__ClausesAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4877:1: ( ( ruleClause ) )
            // InternalSM2.g:4878:2: ( ruleClause )
            {
            // InternalSM2.g:4878:2: ( ruleClause )
            // InternalSM2.g:4879:3: ruleClause
            {
             before(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_13_0()); 
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ClausesAssignment_13"


    // $ANTLR start "rule__SmartContract__CommentsAssignment_14"
    // InternalSM2.g:4888:1: rule__SmartContract__CommentsAssignment_14 : ( ruleComment ) ;
    public final void rule__SmartContract__CommentsAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4892:1: ( ( ruleComment ) )
            // InternalSM2.g:4893:2: ( ruleComment )
            {
            // InternalSM2.g:4893:2: ( ruleComment )
            // InternalSM2.g:4894:3: ruleComment
            {
             before(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;

             after(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CommentsAssignment_14"


    // $ANTLR start "rule__Version__SymbolAssignment_0"
    // InternalSM2.g:4903:1: rule__Version__SymbolAssignment_0 : ( ( rule__Version__SymbolAlternatives_0_0 ) ) ;
    public final void rule__Version__SymbolAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4907:1: ( ( ( rule__Version__SymbolAlternatives_0_0 ) ) )
            // InternalSM2.g:4908:2: ( ( rule__Version__SymbolAlternatives_0_0 ) )
            {
            // InternalSM2.g:4908:2: ( ( rule__Version__SymbolAlternatives_0_0 ) )
            // InternalSM2.g:4909:3: ( rule__Version__SymbolAlternatives_0_0 )
            {
             before(grammarAccess.getVersionAccess().getSymbolAlternatives_0_0()); 
            // InternalSM2.g:4910:3: ( rule__Version__SymbolAlternatives_0_0 )
            // InternalSM2.g:4910:4: rule__Version__SymbolAlternatives_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_0_0();

            state._fsp--;


            }

             after(grammarAccess.getVersionAccess().getSymbolAlternatives_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_1"
    // InternalSM2.g:4918:1: rule__Version__NumberVersionAssignment_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4922:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:4923:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:4923:2: ( RULE_NUMBER )
            // InternalSM2.g:4924:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_3"
    // InternalSM2.g:4933:1: rule__Version__NumberVersion2Assignment_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4937:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:4938:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:4938:2: ( RULE_NUMBER )
            // InternalSM2.g:4939:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_3_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_5"
    // InternalSM2.g:4948:1: rule__Version__NumberVersion3Assignment_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4952:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:4953:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:4953:2: ( RULE_NUMBER )
            // InternalSM2.g:4954:3: RULE_NUMBER
            {
             before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_5_0()); 
            match(input,RULE_NUMBER,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_5"


    // $ANTLR start "rule__Version__OptionalversionAssignment_6"
    // InternalSM2.g:4963:1: rule__Version__OptionalversionAssignment_6 : ( ( RULE_ID ) ) ;
    public final void rule__Version__OptionalversionAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4967:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:4968:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:4968:2: ( ( RULE_ID ) )
            // InternalSM2.g:4969:3: ( RULE_ID )
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_6_0()); 
            // InternalSM2.g:4970:3: ( RULE_ID )
            // InternalSM2.g:4971:4: RULE_ID
            {
             before(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_6_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getVersionAccess().getOptionalversionVersionIDTerminalRuleCall_6_0_1()); 

            }

             after(grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__OptionalversionAssignment_6"


    // $ANTLR start "rule__Import__NameLibraryAssignment_1"
    // InternalSM2.g:4982:1: rule__Import__NameLibraryAssignment_1 : ( RULE_STRING ) ;
    public final void rule__Import__NameLibraryAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4986:1: ( ( RULE_STRING ) )
            // InternalSM2.g:4987:2: ( RULE_STRING )
            {
            // InternalSM2.g:4987:2: ( RULE_STRING )
            // InternalSM2.g:4988:3: RULE_STRING
            {
             before(grammarAccess.getImportAccess().getNameLibrarySTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getImportAccess().getNameLibrarySTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__NameLibraryAssignment_1"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:4997:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5001:1: ( ( RULE_ID ) )
            // InternalSM2.g:5002:2: ( RULE_ID )
            {
            // InternalSM2.g:5002:2: ( RULE_ID )
            // InternalSM2.g:5003:3: RULE_ID
            {
             before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:5012:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5016:1: ( ( ruleInputParam ) )
            // InternalSM2.g:5017:2: ( ruleInputParam )
            {
            // InternalSM2.g:5017:2: ( ruleInputParam )
            // InternalSM2.g:5018:3: ruleInputParam
            {
             before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;

             after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:5027:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5031:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5032:2: ( RULE_STRING )
            {
            // InternalSM2.g:5032:2: ( RULE_STRING )
            // InternalSM2.g:5033:3: RULE_STRING
            {
             before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:5042:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5046:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5047:2: ( ruleSingularType )
            {
            // InternalSM2.g:5047:2: ( ruleSingularType )
            // InternalSM2.g:5048:3: ruleSingularType
            {
             before(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:5057:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5061:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5062:2: ( RULE_STRING )
            {
            // InternalSM2.g:5062:2: ( RULE_STRING )
            // InternalSM2.g:5063:3: RULE_STRING
            {
             before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:5072:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5076:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5077:2: ( ruleVisibility )
            {
            // InternalSM2.g:5077:2: ( ruleVisibility )
            // InternalSM2.g:5078:3: ruleVisibility
            {
             before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:5087:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5091:1: ( ( RULE_ID ) )
            // InternalSM2.g:5092:2: ( RULE_ID )
            {
            // InternalSM2.g:5092:2: ( RULE_ID )
            // InternalSM2.g:5093:3: RULE_ID
            {
             before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__Struct__NameStructAssignment_1"
    // InternalSM2.g:5102:1: rule__Struct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__Struct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5106:1: ( ( RULE_ID ) )
            // InternalSM2.g:5107:2: ( RULE_ID )
            {
            // InternalSM2.g:5107:2: ( RULE_ID )
            // InternalSM2.g:5108:3: RULE_ID
            {
             before(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__NameStructAssignment_1"


    // $ANTLR start "rule__Struct__PropertiesAssignment_4"
    // InternalSM2.g:5117:1: rule__Struct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__Struct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5121:1: ( ( ruleProperty ) )
            // InternalSM2.g:5122:2: ( ruleProperty )
            {
            // InternalSM2.g:5122:2: ( ruleProperty )
            // InternalSM2.g:5123:3: ruleProperty
            {
             before(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;

             after(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__PropertiesAssignment_4"


    // $ANTLR start "rule__Enum__NameEnumAssignment_1"
    // InternalSM2.g:5132:1: rule__Enum__NameEnumAssignment_1 : ( RULE_ID ) ;
    public final void rule__Enum__NameEnumAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5136:1: ( ( RULE_ID ) )
            // InternalSM2.g:5137:2: ( RULE_ID )
            {
            // InternalSM2.g:5137:2: ( RULE_ID )
            // InternalSM2.g:5138:3: RULE_ID
            {
             before(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__NameEnumAssignment_1"


    // $ANTLR start "rule__Enum__ExprAssignment_3"
    // InternalSM2.g:5147:1: rule__Enum__ExprAssignment_3 : ( RULE_STRING ) ;
    public final void rule__Enum__ExprAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5151:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5152:2: ( RULE_STRING )
            {
            // InternalSM2.g:5152:2: ( RULE_STRING )
            // InternalSM2.g:5153:3: RULE_STRING
            {
             before(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__ExprAssignment_3"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:5162:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5166:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5167:2: ( ruleSingularType )
            {
            // InternalSM2.g:5167:2: ( ruleSingularType )
            // InternalSM2.g:5168:3: ruleSingularType
            {
             before(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:5177:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5181:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5182:2: ( ruleVisibility )
            {
            // InternalSM2.g:5182:2: ( ruleVisibility )
            // InternalSM2.g:5183:3: ruleVisibility
            {
             before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:5192:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5196:1: ( ( RULE_ID ) )
            // InternalSM2.g:5197:2: ( RULE_ID )
            {
            // InternalSM2.g:5197:2: ( RULE_ID )
            // InternalSM2.g:5198:3: RULE_ID
            {
             before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:5207:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5211:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5212:2: ( RULE_STRING )
            {
            // InternalSM2.g:5212:2: ( RULE_STRING )
            // InternalSM2.g:5213:3: RULE_STRING
            {
             before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__TypeAssignment_0_0"
    // InternalSM2.g:5222:1: rule__InputParam__TypeAssignment_0_0 : ( ruleSingularType ) ;
    public final void rule__InputParam__TypeAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5226:1: ( ( ruleSingularType ) )
            // InternalSM2.g:5227:2: ( ruleSingularType )
            {
            // InternalSM2.g:5227:2: ( ruleSingularType )
            // InternalSM2.g:5228:3: ruleSingularType
            {
             before(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;

             after(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__TypeAssignment_0_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_0_1"
    // InternalSM2.g:5237:1: rule__InputParam__NameParamAssignment_0_1 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5241:1: ( ( RULE_ID ) )
            // InternalSM2.g:5242:2: ( RULE_ID )
            {
            // InternalSM2.g:5242:2: ( RULE_ID )
            // InternalSM2.g:5243:3: RULE_ID
            {
             before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_0_1"


    // $ANTLR start "rule__Restriction__ExprAssignment_2"
    // InternalSM2.g:5252:1: rule__Restriction__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5256:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5257:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5257:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5258:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:5267:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5271:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:5272:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:5272:2: ( ruleComparationOperator )
            // InternalSM2.g:5273:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__ExprAssignment_4"
    // InternalSM2.g:5282:1: rule__Restriction__ExprAssignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5286:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5287:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5287:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5288:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__ExprAssignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:5297:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5301:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:5302:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:5302:2: ( ruleSyntaxExpression )
            // InternalSM2.g:5303:3: ruleSyntaxExpression
            {
             before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:5312:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5316:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:5317:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:5317:2: ( ruleComparationOperator )
            // InternalSM2.g:5318:3: ruleComparationOperator
            {
             before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:5327:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_INT ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5331:1: ( ( RULE_INT ) )
            // InternalSM2.g:5332:2: ( RULE_INT )
            {
            // InternalSM2.g:5332:2: ( RULE_INT )
            // InternalSM2.g:5333:3: RULE_INT
            {
             before(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:5342:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5346:1: ( ( ruleCoin ) )
            // InternalSM2.g:5347:2: ( ruleCoin )
            {
            // InternalSM2.g:5347:2: ( ruleCoin )
            // InternalSM2.g:5348:3: ruleCoin
            {
             before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;

             after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__NameFunctionAssignment_1"
    // InternalSM2.g:5357:1: rule__Clause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__Clause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5361:1: ( ( RULE_ID ) )
            // InternalSM2.g:5362:2: ( RULE_ID )
            {
            // InternalSM2.g:5362:2: ( RULE_ID )
            // InternalSM2.g:5363:3: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__NameFunctionAssignment_1"


    // $ANTLR start "rule__Clause__InputParamsAssignment_3"
    // InternalSM2.g:5372:1: rule__Clause__InputParamsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__Clause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5376:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:5377:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:5377:2: ( ( RULE_ID ) )
            // InternalSM2.g:5378:3: ( RULE_ID )
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            // InternalSM2.g:5379:3: ( RULE_ID )
            // InternalSM2.g:5380:4: RULE_ID
            {
             before(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 

            }

             after(grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__InputParamsAssignment_3"


    // $ANTLR start "rule__Clause__VisibilityAccessAssignment_4"
    // InternalSM2.g:5391:1: rule__Clause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__Clause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5395:1: ( ( ruleVisibility ) )
            // InternalSM2.g:5396:2: ( ruleVisibility )
            {
            // InternalSM2.g:5396:2: ( ruleVisibility )
            // InternalSM2.g:5397:3: ruleVisibility
            {
             before(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__Clause__RestrictionAssignment_8"
    // InternalSM2.g:5406:1: rule__Clause__RestrictionAssignment_8 : ( ruleRestriction ) ;
    public final void rule__Clause__RestrictionAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5410:1: ( ( ruleRestriction ) )
            // InternalSM2.g:5411:2: ( ruleRestriction )
            {
            // InternalSM2.g:5411:2: ( ruleRestriction )
            // InternalSM2.g:5412:3: ruleRestriction
            {
             before(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleRestriction();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_8"


    // $ANTLR start "rule__Clause__RestrictionGasAssignment_9"
    // InternalSM2.g:5421:1: rule__Clause__RestrictionGasAssignment_9 : ( ruleRestrictionGas ) ;
    public final void rule__Clause__RestrictionGasAssignment_9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5425:1: ( ( ruleRestrictionGas ) )
            // InternalSM2.g:5426:2: ( ruleRestrictionGas )
            {
            // InternalSM2.g:5426:2: ( ruleRestrictionGas )
            // InternalSM2.g:5427:3: ruleRestrictionGas
            {
             before(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_9_0()); 
            pushFollow(FOLLOW_2);
            ruleRestrictionGas();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionGasAssignment_9"


    // $ANTLR start "rule__Clause__ExpressionAssignment_10"
    // InternalSM2.g:5436:1: rule__Clause__ExpressionAssignment_10 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5440:1: ( ( ruleExpression ) )
            // InternalSM2.g:5441:2: ( ruleExpression )
            {
            // InternalSM2.g:5441:2: ( ruleExpression )
            // InternalSM2.g:5442:3: ruleExpression
            {
             before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_10"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_0_1"
    // InternalSM2.g:5451:1: rule__ArithmethicalExpression__Op1Assignment_0_1 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5455:1: ( ( RULE_INT ) )
            // InternalSM2.g:5456:2: ( RULE_INT )
            {
            // InternalSM2.g:5456:2: ( RULE_INT )
            // InternalSM2.g:5457:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_0_1"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_0_2"
    // InternalSM2.g:5466:1: rule__ArithmethicalExpression__OperatorAssignment_0_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5470:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:5471:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:5471:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:5472:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_0_2"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_0_3"
    // InternalSM2.g:5481:1: rule__ArithmethicalExpression__Op2Assignment_0_3 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5485:1: ( ( RULE_INT ) )
            // InternalSM2.g:5486:2: ( RULE_INT )
            {
            // InternalSM2.g:5486:2: ( RULE_INT )
            // InternalSM2.g:5487:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_0_3"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_1_0"
    // InternalSM2.g:5496:1: rule__ArithmethicalExpression__Op1Assignment_1_0 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5500:1: ( ( RULE_INT ) )
            // InternalSM2.g:5501:2: ( RULE_INT )
            {
            // InternalSM2.g:5501:2: ( RULE_INT )
            // InternalSM2.g:5502:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_1_0"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_1_1"
    // InternalSM2.g:5511:1: rule__ArithmethicalExpression__OperatorAssignment_1_1 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5515:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:5516:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:5516:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:5517:3: ruleArithmeticalOperator
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;

             after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_1_1"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_1_2"
    // InternalSM2.g:5526:1: rule__ArithmethicalExpression__Op2Assignment_1_2 : ( RULE_INT ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5530:1: ( ( RULE_INT ) )
            // InternalSM2.g:5531:2: ( RULE_INT )
            {
            // InternalSM2.g:5531:2: ( RULE_INT )
            // InternalSM2.g:5532:3: RULE_INT
            {
             before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_1_2"


    // $ANTLR start "rule__SyntaxExpression__TextAssignment_0"
    // InternalSM2.g:5541:1: rule__SyntaxExpression__TextAssignment_0 : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__TextAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5545:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5546:2: ( RULE_STRING )
            {
            // InternalSM2.g:5546:2: ( RULE_STRING )
            // InternalSM2.g:5547:3: RULE_STRING
            {
             before(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__TextAssignment_0"


    // $ANTLR start "rule__ShortComment__ExprAssignment_1"
    // InternalSM2.g:5556:1: rule__ShortComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ShortComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5560:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5561:2: ( RULE_STRING )
            {
            // InternalSM2.g:5561:2: ( RULE_STRING )
            // InternalSM2.g:5562:3: RULE_STRING
            {
             before(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__ExprAssignment_1"


    // $ANTLR start "rule__LongComment__ExprAssignment_1"
    // InternalSM2.g:5571:1: rule__LongComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__LongComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5575:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5576:2: ( RULE_STRING )
            {
            // InternalSM2.g:5576:2: ( RULE_STRING )
            // InternalSM2.g:5577:3: RULE_STRING
            {
             before(grammarAccess.getLongCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_2); 
             after(grammarAccess.getLongCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExprAssignment_1"

    // Delegated rules


    protected DFA39 dfa39 = new DFA39(this);
    static final String dfa_1s = "\20\uffff";
    static final String dfa_2s = "\1\5\1\11\1\uffff\1\5\2\22\6\5\1\6\1\uffff\1\12\1\22";
    static final String dfa_3s = "\1\74\1\11\1\uffff\1\14\1\50\1\60\6\14\1\6\1\uffff\1\60\1\50";
    static final String dfa_4s = "\2\uffff\1\2\12\uffff\1\1\2\uffff";
    static final String dfa_5s = "\20\uffff}>";
    static final String[] dfa_6s = {
            "\2\2\1\uffff\2\2\2\uffff\1\2\57\uffff\1\1",
            "\1\3",
            "",
            "\1\5\6\uffff\1\4",
            "\1\6\1\10\21\uffff\1\7\1\11\1\12\1\13",
            "\1\6\1\10\21\uffff\1\7\1\11\1\12\1\13\7\uffff\1\14",
            "\1\16\6\uffff\1\15",
            "\1\16\6\uffff\1\15",
            "\1\16\6\uffff\1\15",
            "\1\16\6\uffff\1\15",
            "\1\16\6\uffff\1\15",
            "\1\16\6\uffff\1\15",
            "\1\17",
            "",
            "\1\15\24\uffff\6\2\13\uffff\1\15",
            "\1\6\1\10\21\uffff\1\7\1\11\1\12\1\13"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA39 extends DFA {

        public DFA39(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 39;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "3900:2: ( rule__Clause__RestrictionAssignment_8 )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x00000000000E0000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0008000000000040L,0x0000000000000008L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0008000000000002L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0002000000000080L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0xA35000000FF00150L,0x0000000000000001L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x034000000FF00012L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0010000000000002L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x2000000000000002L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x8000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x000000000FF00400L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000000000FF00002L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000001040L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0020000000000040L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000000100L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x000000000FF00000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000000400L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000070000010L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x000000000FF00040L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0400000000000100L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0001000000001020L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000001020L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x000001E0000C0000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000001F80000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000000070000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x1000000000001360L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000780000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000002L});

}