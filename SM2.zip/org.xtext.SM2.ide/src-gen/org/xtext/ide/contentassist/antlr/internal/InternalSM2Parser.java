package org.xtext.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import org.xtext.services.SM2GrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
@SuppressWarnings("all")
public class InternalSM2Parser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INTEGER", "RULE_STRING", "RULE_PARAMSLONGCOMENT", "RULE_DEVLONGCOMENT", "RULE_RETURNSLONGCOMENT", "RULE_TITLELONGCOMENT", "RULE_NOTICELONGCOMENT", "RULE_SEMICOLON", "RULE_EOLINE", "RULE_OPENKEY", "RULE_CLOSEKEY", "RULE_DOT", "RULE_OPENPARENTHESIS", "RULE_CLOSEPARENTHESIS", "RULE_EMAIL", "RULE_COMMA", "RULE_NUMBER", "RULE_FLOAT", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'>'", "'>='", "'<'", "'<='", "'public'", "'internal'", "'local'", "'int'", "'uint'", "'uint8'", "'uint256'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'byte'", "'bytes32'", "'private'", "'external'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'", "'solidity'", "'is'", "'import'", "'as'", "'inteface'", "'constructor'", "'='", "'event'", "'modifier'", "'_;'", "'mapping'", "'=>'", "'struct'", "'amountAccount'", "'enum'", "'require'", "'function'", "'//'", "'/*'", "'*/'", "'pragma'", "'contract'", "'^'", "'[]'", "'memory'"
    };
    public static final int T__50=50;
    public static final int RULE_OPENPARENTHESIS=17;
    public static final int RULE_EOLINE=13;
    public static final int T__59=59;
    public static final int T__55=55;
    public static final int T__56=56;
    public static final int RULE_CLOSEKEY=15;
    public static final int T__57=57;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_PARAMSLONGCOMENT=7;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int RULE_COMMA=20;
    public static final int RULE_RETURNSLONGCOMENT=9;
    public static final int T__28=28;
    public static final int RULE_INT=23;
    public static final int T__29=29;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=24;
    public static final int T__67=67;
    public static final int T__68=68;
    public static final int T__69=69;
    public static final int RULE_SEMICOLON=12;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__64=64;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_TITLELONGCOMENT=10;
    public static final int RULE_STRING=6;
    public static final int RULE_NOTICELONGCOMENT=11;
    public static final int RULE_EMAIL=19;
    public static final int RULE_SL_COMMENT=25;
    public static final int T__37=37;
    public static final int RULE_OPENKEY=14;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__77=77;
    public static final int T__34=34;
    public static final int T__78=78;
    public static final int RULE_CLOSEPARENTHESIS=18;
    public static final int T__35=35;
    public static final int T__79=79;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int RULE_DOT=16;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=26;
    public static final int RULE_ANY_OTHER=27;
    public static final int RULE_NUMBER=21;
    public static final int RULE_DEVLONGCOMENT=8;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int RULE_FLOAT=22;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__84=84;
    public static final int T__41=41;
    public static final int T__85=85;
    public static final int RULE_INTEGER=5;
    public static final int T__42=42;
    public static final int T__86=86;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2Parser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2Parser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2Parser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2.g"; }


    	private SM2GrammarAccess grammarAccess;

    	public void setGrammarAccess(SM2GrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2.g:54:1: entryRuleSmartContract : ruleSmartContract EOF ;
    public final void entryRuleSmartContract() throws RecognitionException {
        try {
            // InternalSM2.g:55:1: ( ruleSmartContract EOF )
            // InternalSM2.g:56:1: ruleSmartContract EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleSmartContract();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2.g:63:1: ruleSmartContract : ( ( rule__SmartContract__Group__0 ) ) ;
    public final void ruleSmartContract() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:67:2: ( ( ( rule__SmartContract__Group__0 ) ) )
            // InternalSM2.g:68:2: ( ( rule__SmartContract__Group__0 ) )
            {
            // InternalSM2.g:68:2: ( ( rule__SmartContract__Group__0 ) )
            // InternalSM2.g:69:3: ( rule__SmartContract__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getGroup()); 
            }
            // InternalSM2.g:70:3: ( rule__SmartContract__Group__0 )
            // InternalSM2.g:70:4: rule__SmartContract__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2.g:79:1: entryRuleVersion : ruleVersion EOF ;
    public final void entryRuleVersion() throws RecognitionException {
        try {
            // InternalSM2.g:80:1: ( ruleVersion EOF )
            // InternalSM2.g:81:1: ruleVersion EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleVersion();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2.g:88:1: ruleVersion : ( ( rule__Version__Alternatives ) ) ;
    public final void ruleVersion() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:92:2: ( ( ( rule__Version__Alternatives ) ) )
            // InternalSM2.g:93:2: ( ( rule__Version__Alternatives ) )
            {
            // InternalSM2.g:93:2: ( ( rule__Version__Alternatives ) )
            // InternalSM2.g:94:3: ( rule__Version__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getAlternatives()); 
            }
            // InternalSM2.g:95:3: ( rule__Version__Alternatives )
            // InternalSM2.g:95:4: rule__Version__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Version__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2.g:104:1: entryRuleImport : ruleImport EOF ;
    public final void entryRuleImport() throws RecognitionException {
        try {
            // InternalSM2.g:105:1: ( ruleImport EOF )
            // InternalSM2.g:106:1: ruleImport EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleImport();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2.g:113:1: ruleImport : ( ( rule__Import__Group__0 ) ) ;
    public final void ruleImport() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:117:2: ( ( ( rule__Import__Group__0 ) ) )
            // InternalSM2.g:118:2: ( ( rule__Import__Group__0 ) )
            {
            // InternalSM2.g:118:2: ( ( rule__Import__Group__0 ) )
            // InternalSM2.g:119:3: ( rule__Import__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getGroup()); 
            }
            // InternalSM2.g:120:3: ( rule__Import__Group__0 )
            // InternalSM2.g:120:4: rule__Import__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleInterface"
    // InternalSM2.g:129:1: entryRuleInterface : ruleInterface EOF ;
    public final void entryRuleInterface() throws RecognitionException {
        try {
            // InternalSM2.g:130:1: ( ruleInterface EOF )
            // InternalSM2.g:131:1: ruleInterface EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleInterface();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInterface"


    // $ANTLR start "ruleInterface"
    // InternalSM2.g:138:1: ruleInterface : ( ( rule__Interface__Group__0 ) ) ;
    public final void ruleInterface() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:142:2: ( ( ( rule__Interface__Group__0 ) ) )
            // InternalSM2.g:143:2: ( ( rule__Interface__Group__0 ) )
            {
            // InternalSM2.g:143:2: ( ( rule__Interface__Group__0 ) )
            // InternalSM2.g:144:3: ( rule__Interface__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getGroup()); 
            }
            // InternalSM2.g:145:3: ( rule__Interface__Group__0 )
            // InternalSM2.g:145:4: rule__Interface__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Interface__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInterface"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2.g:154:1: entryRuleAttributes : ruleAttributes EOF ;
    public final void entryRuleAttributes() throws RecognitionException {
        try {
            // InternalSM2.g:155:1: ( ruleAttributes EOF )
            // InternalSM2.g:156:1: ruleAttributes EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getAttributesRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleAttributes();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getAttributesRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2.g:163:1: ruleAttributes : ( ( rule__Attributes__Alternatives ) ) ;
    public final void ruleAttributes() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:167:2: ( ( ( rule__Attributes__Alternatives ) ) )
            // InternalSM2.g:168:2: ( ( rule__Attributes__Alternatives ) )
            {
            // InternalSM2.g:168:2: ( ( rule__Attributes__Alternatives ) )
            // InternalSM2.g:169:3: ( rule__Attributes__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getAttributesAccess().getAlternatives()); 
            }
            // InternalSM2.g:170:3: ( rule__Attributes__Alternatives )
            // InternalSM2.g:170:4: rule__Attributes__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Attributes__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getAttributesAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleConstructor"
    // InternalSM2.g:179:1: entryRuleConstructor : ruleConstructor EOF ;
    public final void entryRuleConstructor() throws RecognitionException {
        try {
            // InternalSM2.g:180:1: ( ruleConstructor EOF )
            // InternalSM2.g:181:1: ruleConstructor EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleConstructor();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConstructor"


    // $ANTLR start "ruleConstructor"
    // InternalSM2.g:188:1: ruleConstructor : ( ( rule__Constructor__Group__0 ) ) ;
    public final void ruleConstructor() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:192:2: ( ( ( rule__Constructor__Group__0 ) ) )
            // InternalSM2.g:193:2: ( ( rule__Constructor__Group__0 ) )
            {
            // InternalSM2.g:193:2: ( ( rule__Constructor__Group__0 ) )
            // InternalSM2.g:194:3: ( rule__Constructor__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getGroup()); 
            }
            // InternalSM2.g:195:3: ( rule__Constructor__Group__0 )
            // InternalSM2.g:195:4: rule__Constructor__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConstructor"


    // $ANTLR start "entryRuleEvent"
    // InternalSM2.g:204:1: entryRuleEvent : ruleEvent EOF ;
    public final void entryRuleEvent() throws RecognitionException {
        try {
            // InternalSM2.g:205:1: ( ruleEvent EOF )
            // InternalSM2.g:206:1: ruleEvent EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleEvent();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEvent"


    // $ANTLR start "ruleEvent"
    // InternalSM2.g:213:1: ruleEvent : ( ( rule__Event__Group__0 ) ) ;
    public final void ruleEvent() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:217:2: ( ( ( rule__Event__Group__0 ) ) )
            // InternalSM2.g:218:2: ( ( rule__Event__Group__0 ) )
            {
            // InternalSM2.g:218:2: ( ( rule__Event__Group__0 ) )
            // InternalSM2.g:219:3: ( rule__Event__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getGroup()); 
            }
            // InternalSM2.g:220:3: ( rule__Event__Group__0 )
            // InternalSM2.g:220:4: rule__Event__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEvent"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2.g:229:1: entryRuleModifier : ruleModifier EOF ;
    public final void entryRuleModifier() throws RecognitionException {
        try {
            // InternalSM2.g:230:1: ( ruleModifier EOF )
            // InternalSM2.g:231:1: ruleModifier EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleModifier();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2.g:238:1: ruleModifier : ( ( rule__Modifier__Group__0 ) ) ;
    public final void ruleModifier() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:242:2: ( ( ( rule__Modifier__Group__0 ) ) )
            // InternalSM2.g:243:2: ( ( rule__Modifier__Group__0 ) )
            {
            // InternalSM2.g:243:2: ( ( rule__Modifier__Group__0 ) )
            // InternalSM2.g:244:3: ( rule__Modifier__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getGroup()); 
            }
            // InternalSM2.g:245:3: ( rule__Modifier__Group__0 )
            // InternalSM2.g:245:4: rule__Modifier__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2.g:254:1: entryRuleDataType : ruleDataType EOF ;
    public final void entryRuleDataType() throws RecognitionException {
        try {
            // InternalSM2.g:255:1: ( ruleDataType EOF )
            // InternalSM2.g:256:1: ruleDataType EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getDataTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleDataType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getDataTypeRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2.g:263:1: ruleDataType : ( ( rule__DataType__Alternatives ) ) ;
    public final void ruleDataType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:267:2: ( ( ( rule__DataType__Alternatives ) ) )
            // InternalSM2.g:268:2: ( ( rule__DataType__Alternatives ) )
            {
            // InternalSM2.g:268:2: ( ( rule__DataType__Alternatives ) )
            // InternalSM2.g:269:3: ( rule__DataType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getDataTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:270:3: ( rule__DataType__Alternatives )
            // InternalSM2.g:270:4: rule__DataType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__DataType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getDataTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2.g:279:1: entryRuleCompositeType : ruleCompositeType EOF ;
    public final void entryRuleCompositeType() throws RecognitionException {
        try {
            // InternalSM2.g:280:1: ( ruleCompositeType EOF )
            // InternalSM2.g:281:1: ruleCompositeType EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCompositeTypeRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleCompositeType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getCompositeTypeRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2.g:288:1: ruleCompositeType : ( ( rule__CompositeType__Alternatives ) ) ;
    public final void ruleCompositeType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:292:2: ( ( ( rule__CompositeType__Alternatives ) ) )
            // InternalSM2.g:293:2: ( ( rule__CompositeType__Alternatives ) )
            {
            // InternalSM2.g:293:2: ( ( rule__CompositeType__Alternatives ) )
            // InternalSM2.g:294:3: ( rule__CompositeType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:295:3: ( rule__CompositeType__Alternatives )
            // InternalSM2.g:295:4: rule__CompositeType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__CompositeType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCompositeTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2.g:304:1: entryRuleMapping : ruleMapping EOF ;
    public final void entryRuleMapping() throws RecognitionException {
        try {
            // InternalSM2.g:305:1: ( ruleMapping EOF )
            // InternalSM2.g:306:1: ruleMapping EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleMapping();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2.g:313:1: ruleMapping : ( ( rule__Mapping__Group__0 ) ) ;
    public final void ruleMapping() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:317:2: ( ( ( rule__Mapping__Group__0 ) ) )
            // InternalSM2.g:318:2: ( ( rule__Mapping__Group__0 ) )
            {
            // InternalSM2.g:318:2: ( ( rule__Mapping__Group__0 ) )
            // InternalSM2.g:319:3: ( rule__Mapping__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getGroup()); 
            }
            // InternalSM2.g:320:3: ( rule__Mapping__Group__0 )
            // InternalSM2.g:320:4: rule__Mapping__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2.g:329:1: entryRuleStruct : ruleStruct EOF ;
    public final void entryRuleStruct() throws RecognitionException {
        try {
            // InternalSM2.g:330:1: ( ruleStruct EOF )
            // InternalSM2.g:331:1: ruleStruct EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2.g:338:1: ruleStruct : ( ( rule__Struct__TypeStructAssignment ) ) ;
    public final void ruleStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:342:2: ( ( ( rule__Struct__TypeStructAssignment ) ) )
            // InternalSM2.g:343:2: ( ( rule__Struct__TypeStructAssignment ) )
            {
            // InternalSM2.g:343:2: ( ( rule__Struct__TypeStructAssignment ) )
            // InternalSM2.g:344:3: ( rule__Struct__TypeStructAssignment )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructAccess().getTypeStructAssignment()); 
            }
            // InternalSM2.g:345:3: ( rule__Struct__TypeStructAssignment )
            // InternalSM2.g:345:4: rule__Struct__TypeStructAssignment
            {
            pushFollow(FOLLOW_2);
            rule__Struct__TypeStructAssignment();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructAccess().getTypeStructAssignment()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRulePersonalizedStruct"
    // InternalSM2.g:354:1: entryRulePersonalizedStruct : rulePersonalizedStruct EOF ;
    public final void entryRulePersonalizedStruct() throws RecognitionException {
        try {
            // InternalSM2.g:355:1: ( rulePersonalizedStruct EOF )
            // InternalSM2.g:356:1: rulePersonalizedStruct EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructRule()); 
            }
            pushFollow(FOLLOW_1);
            rulePersonalizedStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePersonalizedStruct"


    // $ANTLR start "rulePersonalizedStruct"
    // InternalSM2.g:363:1: rulePersonalizedStruct : ( ( rule__PersonalizedStruct__Group__0 ) ) ;
    public final void rulePersonalizedStruct() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:367:2: ( ( ( rule__PersonalizedStruct__Group__0 ) ) )
            // InternalSM2.g:368:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            {
            // InternalSM2.g:368:2: ( ( rule__PersonalizedStruct__Group__0 ) )
            // InternalSM2.g:369:3: ( rule__PersonalizedStruct__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getGroup()); 
            }
            // InternalSM2.g:370:3: ( rule__PersonalizedStruct__Group__0 )
            // InternalSM2.g:370:4: rule__PersonalizedStruct__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePersonalizedStruct"


    // $ANTLR start "entryRuleUser"
    // InternalSM2.g:379:1: entryRuleUser : ruleUser EOF ;
    public final void entryRuleUser() throws RecognitionException {
        try {
            // InternalSM2.g:380:1: ( ruleUser EOF )
            // InternalSM2.g:381:1: ruleUser EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleUser();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleUser"


    // $ANTLR start "ruleUser"
    // InternalSM2.g:388:1: ruleUser : ( ( rule__User__Group__0 ) ) ;
    public final void ruleUser() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:392:2: ( ( ( rule__User__Group__0 ) ) )
            // InternalSM2.g:393:2: ( ( rule__User__Group__0 ) )
            {
            // InternalSM2.g:393:2: ( ( rule__User__Group__0 ) )
            // InternalSM2.g:394:3: ( rule__User__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup()); 
            }
            // InternalSM2.g:395:3: ( rule__User__Group__0 )
            // InternalSM2.g:395:4: rule__User__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleUser"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2.g:404:1: entryRuleEnum : ruleEnum EOF ;
    public final void entryRuleEnum() throws RecognitionException {
        try {
            // InternalSM2.g:405:1: ( ruleEnum EOF )
            // InternalSM2.g:406:1: ruleEnum EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleEnum();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2.g:413:1: ruleEnum : ( ( rule__Enum__Group__0 ) ) ;
    public final void ruleEnum() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:417:2: ( ( ( rule__Enum__Group__0 ) ) )
            // InternalSM2.g:418:2: ( ( rule__Enum__Group__0 ) )
            {
            // InternalSM2.g:418:2: ( ( rule__Enum__Group__0 ) )
            // InternalSM2.g:419:3: ( rule__Enum__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup()); 
            }
            // InternalSM2.g:420:3: ( rule__Enum__Group__0 )
            // InternalSM2.g:420:4: rule__Enum__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2.g:429:1: entryRuleProperty : ruleProperty EOF ;
    public final void entryRuleProperty() throws RecognitionException {
        try {
            // InternalSM2.g:430:1: ( ruleProperty EOF )
            // InternalSM2.g:431:1: ruleProperty EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleProperty();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2.g:438:1: ruleProperty : ( ( rule__Property__Group__0 ) ) ;
    public final void ruleProperty() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:442:2: ( ( ( rule__Property__Group__0 ) ) )
            // InternalSM2.g:443:2: ( ( rule__Property__Group__0 ) )
            {
            // InternalSM2.g:443:2: ( ( rule__Property__Group__0 ) )
            // InternalSM2.g:444:3: ( rule__Property__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getGroup()); 
            }
            // InternalSM2.g:445:3: ( rule__Property__Group__0 )
            // InternalSM2.g:445:4: rule__Property__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleInputParam"
    // InternalSM2.g:454:1: entryRuleInputParam : ruleInputParam EOF ;
    public final void entryRuleInputParam() throws RecognitionException {
        try {
            // InternalSM2.g:455:1: ( ruleInputParam EOF )
            // InternalSM2.g:456:1: ruleInputParam EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInputParam"


    // $ANTLR start "ruleInputParam"
    // InternalSM2.g:463:1: ruleInputParam : ( ( rule__InputParam__Group__0 ) ) ;
    public final void ruleInputParam() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:467:2: ( ( ( rule__InputParam__Group__0 ) ) )
            // InternalSM2.g:468:2: ( ( rule__InputParam__Group__0 ) )
            {
            // InternalSM2.g:468:2: ( ( rule__InputParam__Group__0 ) )
            // InternalSM2.g:469:3: ( rule__InputParam__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getGroup()); 
            }
            // InternalSM2.g:470:3: ( rule__InputParam__Group__0 )
            // InternalSM2.g:470:4: rule__InputParam__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInputParam"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2.g:479:1: entryRuleRestriction : ruleRestriction EOF ;
    public final void entryRuleRestriction() throws RecognitionException {
        try {
            // InternalSM2.g:480:1: ( ruleRestriction EOF )
            // InternalSM2.g:481:1: ruleRestriction EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleRestriction();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2.g:488:1: ruleRestriction : ( ( rule__Restriction__Group__0 ) ) ;
    public final void ruleRestriction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:492:2: ( ( ( rule__Restriction__Group__0 ) ) )
            // InternalSM2.g:493:2: ( ( rule__Restriction__Group__0 ) )
            {
            // InternalSM2.g:493:2: ( ( rule__Restriction__Group__0 ) )
            // InternalSM2.g:494:3: ( rule__Restriction__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getGroup()); 
            }
            // InternalSM2.g:495:3: ( rule__Restriction__Group__0 )
            // InternalSM2.g:495:4: rule__Restriction__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2.g:504:1: entryRuleRestrictionGas : ruleRestrictionGas EOF ;
    public final void entryRuleRestrictionGas() throws RecognitionException {
        try {
            // InternalSM2.g:505:1: ( ruleRestrictionGas EOF )
            // InternalSM2.g:506:1: ruleRestrictionGas EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2.g:513:1: ruleRestrictionGas : ( ( rule__RestrictionGas__Group__0 ) ) ;
    public final void ruleRestrictionGas() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:517:2: ( ( ( rule__RestrictionGas__Group__0 ) ) )
            // InternalSM2.g:518:2: ( ( rule__RestrictionGas__Group__0 ) )
            {
            // InternalSM2.g:518:2: ( ( rule__RestrictionGas__Group__0 ) )
            // InternalSM2.g:519:3: ( rule__RestrictionGas__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getGroup()); 
            }
            // InternalSM2.g:520:3: ( rule__RestrictionGas__Group__0 )
            // InternalSM2.g:520:4: rule__RestrictionGas__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2.g:529:1: entryRuleClause : ruleClause EOF ;
    public final void entryRuleClause() throws RecognitionException {
        try {
            // InternalSM2.g:530:1: ( ruleClause EOF )
            // InternalSM2.g:531:1: ruleClause EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2.g:538:1: ruleClause : ( ( rule__Clause__Group__0 ) ) ;
    public final void ruleClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:542:2: ( ( ( rule__Clause__Group__0 ) ) )
            // InternalSM2.g:543:2: ( ( rule__Clause__Group__0 ) )
            {
            // InternalSM2.g:543:2: ( ( rule__Clause__Group__0 ) )
            // InternalSM2.g:544:3: ( rule__Clause__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getGroup()); 
            }
            // InternalSM2.g:545:3: ( rule__Clause__Group__0 )
            // InternalSM2.g:545:4: rule__Clause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleHeadClause"
    // InternalSM2.g:554:1: entryRuleHeadClause : ruleHeadClause EOF ;
    public final void entryRuleHeadClause() throws RecognitionException {
        try {
            // InternalSM2.g:555:1: ( ruleHeadClause EOF )
            // InternalSM2.g:556:1: ruleHeadClause EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleHeadClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleHeadClause"


    // $ANTLR start "ruleHeadClause"
    // InternalSM2.g:563:1: ruleHeadClause : ( ( rule__HeadClause__Group__0 ) ) ;
    public final void ruleHeadClause() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:567:2: ( ( ( rule__HeadClause__Group__0 ) ) )
            // InternalSM2.g:568:2: ( ( rule__HeadClause__Group__0 ) )
            {
            // InternalSM2.g:568:2: ( ( rule__HeadClause__Group__0 ) )
            // InternalSM2.g:569:3: ( rule__HeadClause__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getGroup()); 
            }
            // InternalSM2.g:570:3: ( rule__HeadClause__Group__0 )
            // InternalSM2.g:570:4: rule__HeadClause__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleHeadClause"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2.g:579:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // InternalSM2.g:580:1: ( ruleExpression EOF )
            // InternalSM2.g:581:1: ruleExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2.g:588:1: ruleExpression : ( ( rule__Expression__Alternatives ) ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:592:2: ( ( ( rule__Expression__Alternatives ) ) )
            // InternalSM2.g:593:2: ( ( rule__Expression__Alternatives ) )
            {
            // InternalSM2.g:593:2: ( ( rule__Expression__Alternatives ) )
            // InternalSM2.g:594:3: ( rule__Expression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:595:3: ( rule__Expression__Alternatives )
            // InternalSM2.g:595:4: rule__Expression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Expression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2.g:604:1: entryRuleArithmethicalExpression : ruleArithmethicalExpression EOF ;
    public final void entryRuleArithmethicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:605:1: ( ruleArithmethicalExpression EOF )
            // InternalSM2.g:606:1: ruleArithmethicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2.g:613:1: ruleArithmethicalExpression : ( ( rule__ArithmethicalExpression__Alternatives ) ) ;
    public final void ruleArithmethicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:617:2: ( ( ( rule__ArithmethicalExpression__Alternatives ) ) )
            // InternalSM2.g:618:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            {
            // InternalSM2.g:618:2: ( ( rule__ArithmethicalExpression__Alternatives ) )
            // InternalSM2.g:619:3: ( rule__ArithmethicalExpression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:620:3: ( rule__ArithmethicalExpression__Alternatives )
            // InternalSM2.g:620:4: rule__ArithmethicalExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleArithmethicalLogicalExpression"
    // InternalSM2.g:629:1: entryRuleArithmethicalLogicalExpression : ruleArithmethicalLogicalExpression EOF ;
    public final void entryRuleArithmethicalLogicalExpression() throws RecognitionException {
        try {
            // InternalSM2.g:630:1: ( ruleArithmethicalLogicalExpression EOF )
            // InternalSM2.g:631:1: ruleArithmethicalLogicalExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleArithmethicalLogicalExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleArithmethicalLogicalExpression"


    // $ANTLR start "ruleArithmethicalLogicalExpression"
    // InternalSM2.g:638:1: ruleArithmethicalLogicalExpression : ( ( rule__ArithmethicalLogicalExpression__Group__0 ) ) ;
    public final void ruleArithmethicalLogicalExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:642:2: ( ( ( rule__ArithmethicalLogicalExpression__Group__0 ) ) )
            // InternalSM2.g:643:2: ( ( rule__ArithmethicalLogicalExpression__Group__0 ) )
            {
            // InternalSM2.g:643:2: ( ( rule__ArithmethicalLogicalExpression__Group__0 ) )
            // InternalSM2.g:644:3: ( rule__ArithmethicalLogicalExpression__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getGroup()); 
            }
            // InternalSM2.g:645:3: ( rule__ArithmethicalLogicalExpression__Group__0 )
            // InternalSM2.g:645:4: rule__ArithmethicalLogicalExpression__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmethicalLogicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2.g:654:1: entryRuleSyntaxExpression : ruleSyntaxExpression EOF ;
    public final void entryRuleSyntaxExpression() throws RecognitionException {
        try {
            // InternalSM2.g:655:1: ( ruleSyntaxExpression EOF )
            // InternalSM2.g:656:1: ruleSyntaxExpression EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2.g:663:1: ruleSyntaxExpression : ( ( rule__SyntaxExpression__Alternatives ) ) ;
    public final void ruleSyntaxExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:667:2: ( ( ( rule__SyntaxExpression__Alternatives ) ) )
            // InternalSM2.g:668:2: ( ( rule__SyntaxExpression__Alternatives ) )
            {
            // InternalSM2.g:668:2: ( ( rule__SyntaxExpression__Alternatives ) )
            // InternalSM2.g:669:3: ( rule__SyntaxExpression__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            }
            // InternalSM2.g:670:3: ( rule__SyntaxExpression__Alternatives )
            // InternalSM2.g:670:4: rule__SyntaxExpression__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2.g:679:1: entryRuleComment : ruleComment EOF ;
    public final void entryRuleComment() throws RecognitionException {
        try {
            // InternalSM2.g:680:1: ( ruleComment EOF )
            // InternalSM2.g:681:1: ruleComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2.g:688:1: ruleComment : ( ( rule__Comment__Alternatives ) ) ;
    public final void ruleComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:692:2: ( ( ( rule__Comment__Alternatives ) ) )
            // InternalSM2.g:693:2: ( ( rule__Comment__Alternatives ) )
            {
            // InternalSM2.g:693:2: ( ( rule__Comment__Alternatives ) )
            // InternalSM2.g:694:3: ( rule__Comment__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCommentAccess().getAlternatives()); 
            }
            // InternalSM2.g:695:3: ( rule__Comment__Alternatives )
            // InternalSM2.g:695:4: rule__Comment__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Comment__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCommentAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2.g:704:1: entryRuleShortComment : ruleShortComment EOF ;
    public final void entryRuleShortComment() throws RecognitionException {
        try {
            // InternalSM2.g:705:1: ( ruleShortComment EOF )
            // InternalSM2.g:706:1: ruleShortComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleShortComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2.g:713:1: ruleShortComment : ( ( rule__ShortComment__Group__0 ) ) ;
    public final void ruleShortComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:717:2: ( ( ( rule__ShortComment__Group__0 ) ) )
            // InternalSM2.g:718:2: ( ( rule__ShortComment__Group__0 ) )
            {
            // InternalSM2.g:718:2: ( ( rule__ShortComment__Group__0 ) )
            // InternalSM2.g:719:3: ( rule__ShortComment__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getGroup()); 
            }
            // InternalSM2.g:720:3: ( rule__ShortComment__Group__0 )
            // InternalSM2.g:720:4: rule__ShortComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2.g:729:1: entryRuleLongComment : ruleLongComment EOF ;
    public final void entryRuleLongComment() throws RecognitionException {
        try {
            // InternalSM2.g:730:1: ( ruleLongComment EOF )
            // InternalSM2.g:731:1: ruleLongComment EOF
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentRule()); 
            }
            pushFollow(FOLLOW_1);
            ruleLongComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentRule()); 
            }
            match(input,EOF,FOLLOW_2); if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2.g:738:1: ruleLongComment : ( ( rule__LongComment__Group__0 ) ) ;
    public final void ruleLongComment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:742:2: ( ( ( rule__LongComment__Group__0 ) ) )
            // InternalSM2.g:743:2: ( ( rule__LongComment__Group__0 ) )
            {
            // InternalSM2.g:743:2: ( ( rule__LongComment__Group__0 ) )
            // InternalSM2.g:744:3: ( rule__LongComment__Group__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getGroup()); 
            }
            // InternalSM2.g:745:3: ( rule__LongComment__Group__0 )
            // InternalSM2.g:745:4: rule__LongComment__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getGroup()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2.g:754:1: ruleSingularType : ( ( rule__SingularType__Alternatives ) ) ;
    public final void ruleSingularType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:758:1: ( ( ( rule__SingularType__Alternatives ) ) )
            // InternalSM2.g:759:2: ( ( rule__SingularType__Alternatives ) )
            {
            // InternalSM2.g:759:2: ( ( rule__SingularType__Alternatives ) )
            // InternalSM2.g:760:3: ( rule__SingularType__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            }
            // InternalSM2.g:761:3: ( rule__SingularType__Alternatives )
            // InternalSM2.g:761:4: rule__SingularType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__SingularType__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSingularTypeAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2.g:770:1: ruleVisibility : ( ( rule__Visibility__Alternatives ) ) ;
    public final void ruleVisibility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:774:1: ( ( ( rule__Visibility__Alternatives ) ) )
            // InternalSM2.g:775:2: ( ( rule__Visibility__Alternatives ) )
            {
            // InternalSM2.g:775:2: ( ( rule__Visibility__Alternatives ) )
            // InternalSM2.g:776:3: ( rule__Visibility__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVisibilityAccess().getAlternatives()); 
            }
            // InternalSM2.g:777:3: ( rule__Visibility__Alternatives )
            // InternalSM2.g:777:4: rule__Visibility__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Visibility__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVisibilityAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2.g:786:1: ruleCoin : ( ( rule__Coin__Alternatives ) ) ;
    public final void ruleCoin() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:790:1: ( ( ( rule__Coin__Alternatives ) ) )
            // InternalSM2.g:791:2: ( ( rule__Coin__Alternatives ) )
            {
            // InternalSM2.g:791:2: ( ( rule__Coin__Alternatives ) )
            // InternalSM2.g:792:3: ( rule__Coin__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getCoinAccess().getAlternatives()); 
            }
            // InternalSM2.g:793:3: ( rule__Coin__Alternatives )
            // InternalSM2.g:793:4: rule__Coin__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__Coin__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getCoinAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2.g:802:1: ruleComparationOperator : ( ( rule__ComparationOperator__Alternatives ) ) ;
    public final void ruleComparationOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:806:1: ( ( ( rule__ComparationOperator__Alternatives ) ) )
            // InternalSM2.g:807:2: ( ( rule__ComparationOperator__Alternatives ) )
            {
            // InternalSM2.g:807:2: ( ( rule__ComparationOperator__Alternatives ) )
            // InternalSM2.g:808:3: ( rule__ComparationOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:809:3: ( rule__ComparationOperator__Alternatives )
            // InternalSM2.g:809:4: rule__ComparationOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ComparationOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getComparationOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2.g:818:1: ruleLogicalPairOperator : ( ( rule__LogicalPairOperator__Alternatives ) ) ;
    public final void ruleLogicalPairOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:822:1: ( ( ( rule__LogicalPairOperator__Alternatives ) ) )
            // InternalSM2.g:823:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            {
            // InternalSM2.g:823:2: ( ( rule__LogicalPairOperator__Alternatives ) )
            // InternalSM2.g:824:3: ( rule__LogicalPairOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:825:3: ( rule__LogicalPairOperator__Alternatives )
            // InternalSM2.g:825:4: rule__LogicalPairOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__LogicalPairOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLogicalPairOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2.g:834:1: ruleArithmeticalOperator : ( ( rule__ArithmeticalOperator__Alternatives ) ) ;
    public final void ruleArithmeticalOperator() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:838:1: ( ( ( rule__ArithmeticalOperator__Alternatives ) ) )
            // InternalSM2.g:839:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            {
            // InternalSM2.g:839:2: ( ( rule__ArithmeticalOperator__Alternatives ) )
            // InternalSM2.g:840:3: ( rule__ArithmeticalOperator__Alternatives )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            }
            // InternalSM2.g:841:3: ( rule__ArithmeticalOperator__Alternatives )
            // InternalSM2.g:841:4: rule__ArithmeticalOperator__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__ArithmeticalOperator__Alternatives();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmeticalOperatorAccess().getAlternatives()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleArithmeticalOperator"


    // $ANTLR start "rule__Version__Alternatives"
    // InternalSM2.g:849:1: rule__Version__Alternatives : ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) );
    public final void rule__Version__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:853:1: ( ( ( rule__Version__Group_0__0 ) ) | ( ( rule__Version__Group_1__0 ) ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==84) ) {
                alt1=1;
            }
            else if ( ((LA1_0>=28 && LA1_0<=29)) ) {
                alt1=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // InternalSM2.g:854:2: ( ( rule__Version__Group_0__0 ) )
                    {
                    // InternalSM2.g:854:2: ( ( rule__Version__Group_0__0 ) )
                    // InternalSM2.g:855:3: ( rule__Version__Group_0__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getGroup_0()); 
                    }
                    // InternalSM2.g:856:3: ( rule__Version__Group_0__0 )
                    // InternalSM2.g:856:4: rule__Version__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_0__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getGroup_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:860:2: ( ( rule__Version__Group_1__0 ) )
                    {
                    // InternalSM2.g:860:2: ( ( rule__Version__Group_1__0 ) )
                    // InternalSM2.g:861:3: ( rule__Version__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:862:3: ( rule__Version__Group_1__0 )
                    // InternalSM2.g:862:4: rule__Version__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Alternatives"


    // $ANTLR start "rule__Version__SymbolAlternatives_1_0_0"
    // InternalSM2.g:870:1: rule__Version__SymbolAlternatives_1_0_0 : ( ( '>' ) | ( '>=' ) );
    public final void rule__Version__SymbolAlternatives_1_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:874:1: ( ( '>' ) | ( '>=' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==28) ) {
                alt2=1;
            }
            else if ( (LA2_0==29) ) {
                alt2=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2.g:875:2: ( '>' )
                    {
                    // InternalSM2.g:875:2: ( '>' )
                    // InternalSM2.g:876:3: '>'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 
                    }
                    match(input,28,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_1_0_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:881:2: ( '>=' )
                    {
                    // InternalSM2.g:881:2: ( '>=' )
                    // InternalSM2.g:882:3: '>='
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 
                    }
                    match(input,29,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_1_0_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAlternatives_1_0_0"


    // $ANTLR start "rule__Version__Symbol2Alternatives_1_6_0_0"
    // InternalSM2.g:891:1: rule__Version__Symbol2Alternatives_1_6_0_0 : ( ( '<' ) | ( '<=' ) );
    public final void rule__Version__Symbol2Alternatives_1_6_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:895:1: ( ( '<' ) | ( '<=' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==30) ) {
                alt3=1;
            }
            else if ( (LA3_0==31) ) {
                alt3=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalSM2.g:896:2: ( '<' )
                    {
                    // InternalSM2.g:896:2: ( '<' )
                    // InternalSM2.g:897:3: '<'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 
                    }
                    match(input,30,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbol2LessThanSignKeyword_1_6_0_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:902:2: ( '<=' )
                    {
                    // InternalSM2.g:902:2: ( '<=' )
                    // InternalSM2.g:903:3: '<='
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 
                    }
                    match(input,31,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVersionAccess().getSymbol2LessThanSignEqualsSignKeyword_1_6_0_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Alternatives_1_6_0_0"


    // $ANTLR start "rule__Attributes__Alternatives"
    // InternalSM2.g:912:1: rule__Attributes__Alternatives : ( ( ruleProperty ) | ( ruleDataType ) );
    public final void rule__Attributes__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:916:1: ( ( ruleProperty ) | ( ruleDataType ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( ((LA4_0>=35 && LA4_0<=45)) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_ID||LA4_0==72||LA4_0==74||LA4_0==76) ) {
                alt4=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalSM2.g:917:2: ( ruleProperty )
                    {
                    // InternalSM2.g:917:2: ( ruleProperty )
                    // InternalSM2.g:918:3: ruleProperty
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleProperty();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:923:2: ( ruleDataType )
                    {
                    // InternalSM2.g:923:2: ( ruleDataType )
                    // InternalSM2.g:924:3: ruleDataType
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleDataType();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Attributes__Alternatives"


    // $ANTLR start "rule__Constructor__TypeAlternatives_3_0"
    // InternalSM2.g:933:1: rule__Constructor__TypeAlternatives_3_0 : ( ( 'public' ) | ( 'internal' ) );
    public final void rule__Constructor__TypeAlternatives_3_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:937:1: ( ( 'public' ) | ( 'internal' ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==32) ) {
                alt5=1;
            }
            else if ( (LA5_0==33) ) {
                alt5=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalSM2.g:938:2: ( 'public' )
                    {
                    // InternalSM2.g:938:2: ( 'public' )
                    // InternalSM2.g:939:3: 'public'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0()); 
                    }
                    match(input,32,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getConstructorAccess().getTypePublicKeyword_3_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:944:2: ( 'internal' )
                    {
                    // InternalSM2.g:944:2: ( 'internal' )
                    // InternalSM2.g:945:3: 'internal'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1()); 
                    }
                    match(input,33,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getConstructorAccess().getTypeInternalKeyword_3_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__TypeAlternatives_3_0"


    // $ANTLR start "rule__DataType__Alternatives"
    // InternalSM2.g:954:1: rule__DataType__Alternatives : ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) );
    public final void rule__DataType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:958:1: ( ( ruleCompositeType ) | ( ruleEnum ) | ( RULE_ID ) )
            int alt6=3;
            switch ( input.LA(1) ) {
            case 72:
            case 74:
                {
                alt6=1;
                }
                break;
            case 76:
                {
                alt6=2;
                }
                break;
            case RULE_ID:
                {
                alt6=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // InternalSM2.g:959:2: ( ruleCompositeType )
                    {
                    // InternalSM2.g:959:2: ( ruleCompositeType )
                    // InternalSM2.g:960:3: ruleCompositeType
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleCompositeType();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:965:2: ( ruleEnum )
                    {
                    // InternalSM2.g:965:2: ( ruleEnum )
                    // InternalSM2.g:966:3: ruleEnum
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleEnum();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:971:2: ( RULE_ID )
                    {
                    // InternalSM2.g:971:2: ( RULE_ID )
                    // InternalSM2.g:972:3: RULE_ID
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    }
                    match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__DataType__Alternatives"


    // $ANTLR start "rule__CompositeType__Alternatives"
    // InternalSM2.g:981:1: rule__CompositeType__Alternatives : ( ( ruleMapping ) | ( ruleStruct ) );
    public final void rule__CompositeType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:985:1: ( ( ruleMapping ) | ( ruleStruct ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==72) ) {
                alt7=1;
            }
            else if ( (LA7_0==74) ) {
                alt7=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // InternalSM2.g:986:2: ( ruleMapping )
                    {
                    // InternalSM2.g:986:2: ( ruleMapping )
                    // InternalSM2.g:987:3: ruleMapping
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleMapping();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:992:2: ( ruleStruct )
                    {
                    // InternalSM2.g:992:2: ( ruleStruct )
                    // InternalSM2.g:993:3: ruleStruct
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleStruct();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__CompositeType__Alternatives"


    // $ANTLR start "rule__Struct__TypeStructAlternatives_0"
    // InternalSM2.g:1002:1: rule__Struct__TypeStructAlternatives_0 : ( ( rulePersonalizedStruct ) | ( ruleUser ) );
    public final void rule__Struct__TypeStructAlternatives_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1006:1: ( ( rulePersonalizedStruct ) | ( ruleUser ) )
            int alt8=2;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // InternalSM2.g:1007:2: ( rulePersonalizedStruct )
                    {
                    // InternalSM2.g:1007:2: ( rulePersonalizedStruct )
                    // InternalSM2.g:1008:3: rulePersonalizedStruct
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    rulePersonalizedStruct();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getStructAccess().getTypeStructPersonalizedStructParserRuleCall_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1013:2: ( ruleUser )
                    {
                    // InternalSM2.g:1013:2: ( ruleUser )
                    // InternalSM2.g:1014:3: ruleUser
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getStructAccess().getTypeStructUserParserRuleCall_0_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleUser();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getStructAccess().getTypeStructUserParserRuleCall_0_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__TypeStructAlternatives_0"


    // $ANTLR start "rule__User__Alternatives_26"
    // InternalSM2.g:1023:1: rule__User__Alternatives_26 : ( ( ( rule__User__Group_26_0__0 ) ) | ( RULE_INTEGER ) );
    public final void rule__User__Alternatives_26() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1027:1: ( ( ( rule__User__Group_26_0__0 ) ) | ( RULE_INTEGER ) )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==68) ) {
                alt9=1;
            }
            else if ( (LA9_0==RULE_INTEGER) ) {
                alt9=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2.g:1028:2: ( ( rule__User__Group_26_0__0 ) )
                    {
                    // InternalSM2.g:1028:2: ( ( rule__User__Group_26_0__0 ) )
                    // InternalSM2.g:1029:3: ( rule__User__Group_26_0__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getUserAccess().getGroup_26_0()); 
                    }
                    // InternalSM2.g:1030:3: ( rule__User__Group_26_0__0 )
                    // InternalSM2.g:1030:4: rule__User__Group_26_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_26_0__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getUserAccess().getGroup_26_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1034:2: ( RULE_INTEGER )
                    {
                    // InternalSM2.g:1034:2: ( RULE_INTEGER )
                    // InternalSM2.g:1035:3: RULE_INTEGER
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getUserAccess().getINTEGERTerminalRuleCall_26_1()); 
                    }
                    match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getUserAccess().getINTEGERTerminalRuleCall_26_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Alternatives_26"


    // $ANTLR start "rule__Property__Alternatives_4"
    // InternalSM2.g:1044:1: rule__Property__Alternatives_4 : ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INTEGER ) );
    public final void rule__Property__Alternatives_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1048:1: ( ( ( rule__Property__InicializationAssignment_4_0 ) ) | ( RULE_INTEGER ) )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_STRING) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_INTEGER) ) {
                alt10=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalSM2.g:1049:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    {
                    // InternalSM2.g:1049:2: ( ( rule__Property__InicializationAssignment_4_0 ) )
                    // InternalSM2.g:1050:3: ( rule__Property__InicializationAssignment_4_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    }
                    // InternalSM2.g:1051:3: ( rule__Property__InicializationAssignment_4_0 )
                    // InternalSM2.g:1051:4: rule__Property__InicializationAssignment_4_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__InicializationAssignment_4_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getPropertyAccess().getInicializationAssignment_4_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1055:2: ( RULE_INTEGER )
                    {
                    // InternalSM2.g:1055:2: ( RULE_INTEGER )
                    // InternalSM2.g:1056:3: RULE_INTEGER
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getPropertyAccess().getINTEGERTerminalRuleCall_4_1()); 
                    }
                    match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getPropertyAccess().getINTEGERTerminalRuleCall_4_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Alternatives_4"


    // $ANTLR start "rule__InputParam__Alternatives_0_2"
    // InternalSM2.g:1065:1: rule__InputParam__Alternatives_0_2 : ( ( ( rule__InputParam__StorageAssignment_0_2_0 ) ) | ( 'local' ) );
    public final void rule__InputParam__Alternatives_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1069:1: ( ( ( rule__InputParam__StorageAssignment_0_2_0 ) ) | ( 'local' ) )
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==86) ) {
                alt11=1;
            }
            else if ( (LA11_0==34) ) {
                alt11=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }
            switch (alt11) {
                case 1 :
                    // InternalSM2.g:1070:2: ( ( rule__InputParam__StorageAssignment_0_2_0 ) )
                    {
                    // InternalSM2.g:1070:2: ( ( rule__InputParam__StorageAssignment_0_2_0 ) )
                    // InternalSM2.g:1071:3: ( rule__InputParam__StorageAssignment_0_2_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getInputParamAccess().getStorageAssignment_0_2_0()); 
                    }
                    // InternalSM2.g:1072:3: ( rule__InputParam__StorageAssignment_0_2_0 )
                    // InternalSM2.g:1072:4: rule__InputParam__StorageAssignment_0_2_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__StorageAssignment_0_2_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getInputParamAccess().getStorageAssignment_0_2_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1076:2: ( 'local' )
                    {
                    // InternalSM2.g:1076:2: ( 'local' )
                    // InternalSM2.g:1077:3: 'local'
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1()); 
                    }
                    match(input,34,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getInputParamAccess().getLocalKeyword_0_2_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Alternatives_0_2"


    // $ANTLR start "rule__Expression__Alternatives"
    // InternalSM2.g:1086:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleArithmethicalLogicalExpression ) | ( ruleSyntaxExpression ) );
    public final void rule__Expression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1090:1: ( ( ruleArithmethicalExpression ) | ( ruleArithmethicalLogicalExpression ) | ( ruleSyntaxExpression ) )
            int alt12=3;
            alt12 = dfa12.predict(input);
            switch (alt12) {
                case 1 :
                    // InternalSM2.g:1091:2: ( ruleArithmethicalExpression )
                    {
                    // InternalSM2.g:1091:2: ( ruleArithmethicalExpression )
                    // InternalSM2.g:1092:3: ruleArithmethicalExpression
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalExpression();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1097:2: ( ruleArithmethicalLogicalExpression )
                    {
                    // InternalSM2.g:1097:2: ( ruleArithmethicalLogicalExpression )
                    // InternalSM2.g:1098:3: ruleArithmethicalLogicalExpression
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleArithmethicalLogicalExpression();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getExpressionAccess().getArithmethicalLogicalExpressionParserRuleCall_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1103:2: ( ruleSyntaxExpression )
                    {
                    // InternalSM2.g:1103:2: ( ruleSyntaxExpression )
                    // InternalSM2.g:1104:3: ruleSyntaxExpression
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleSyntaxExpression();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_2()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Expression__Alternatives"


    // $ANTLR start "rule__ArithmethicalExpression__Alternatives"
    // InternalSM2.g:1113:1: rule__ArithmethicalExpression__Alternatives : ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) );
    public final void rule__ArithmethicalExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1117:1: ( ( ( rule__ArithmethicalExpression__Group_0__0 ) ) | ( ( rule__ArithmethicalExpression__Group_1__0 ) ) )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==RULE_OPENPARENTHESIS) ) {
                alt13=1;
            }
            else if ( (LA13_0==RULE_INTEGER) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2.g:1118:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    {
                    // InternalSM2.g:1118:2: ( ( rule__ArithmethicalExpression__Group_0__0 ) )
                    // InternalSM2.g:1119:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    }
                    // InternalSM2.g:1120:3: ( rule__ArithmethicalExpression__Group_0__0 )
                    // InternalSM2.g:1120:4: rule__ArithmethicalExpression__Group_0__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_0__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalExpressionAccess().getGroup_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1124:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:1124:2: ( ( rule__ArithmethicalExpression__Group_1__0 ) )
                    // InternalSM2.g:1125:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:1126:3: ( rule__ArithmethicalExpression__Group_1__0 )
                    // InternalSM2.g:1126:4: rule__ArithmethicalExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Alternatives"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Alternatives_5"
    // InternalSM2.g:1134:1: rule__ArithmethicalLogicalExpression__Alternatives_5 : ( ( ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 ) ) | ( RULE_INTEGER ) );
    public final void rule__ArithmethicalLogicalExpression__Alternatives_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1138:1: ( ( ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 ) ) | ( RULE_INTEGER ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==RULE_OPENPARENTHESIS) ) {
                alt14=1;
            }
            else if ( (LA14_0==RULE_INTEGER) ) {
                int LA14_2 = input.LA(2);

                if ( ((LA14_2>=58 && LA14_2<=61)) ) {
                    alt14=1;
                }
                else if ( (LA14_2==RULE_CLOSEPARENTHESIS) ) {
                    alt14=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return ;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 14, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2.g:1139:2: ( ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 ) )
                    {
                    // InternalSM2.g:1139:2: ( ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 ) )
                    // InternalSM2.g:1140:3: ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprAssignment_5_0()); 
                    }
                    // InternalSM2.g:1141:3: ( rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 )
                    // InternalSM2.g:1141:4: rule__ArithmethicalLogicalExpression__ExprAssignment_5_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalLogicalExpression__ExprAssignment_5_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprAssignment_5_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1145:2: ( RULE_INTEGER )
                    {
                    // InternalSM2.g:1145:2: ( RULE_INTEGER )
                    // InternalSM2.g:1146:3: RULE_INTEGER
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmethicalLogicalExpressionAccess().getINTEGERTerminalRuleCall_5_1()); 
                    }
                    match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmethicalLogicalExpressionAccess().getINTEGERTerminalRuleCall_5_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Alternatives_5"


    // $ANTLR start "rule__SyntaxExpression__Alternatives"
    // InternalSM2.g:1155:1: rule__SyntaxExpression__Alternatives : ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) );
    public final void rule__SyntaxExpression__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1159:1: ( ( ( rule__SyntaxExpression__TextAssignment_0 ) ) | ( ( rule__SyntaxExpression__Group_1__0 ) ) )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==RULE_STRING) ) {
                alt15=1;
            }
            else if ( (LA15_0==RULE_INTEGER) ) {
                alt15=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2.g:1160:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    {
                    // InternalSM2.g:1160:2: ( ( rule__SyntaxExpression__TextAssignment_0 ) )
                    // InternalSM2.g:1161:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    }
                    // InternalSM2.g:1162:3: ( rule__SyntaxExpression__TextAssignment_0 )
                    // InternalSM2.g:1162:4: rule__SyntaxExpression__TextAssignment_0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__TextAssignment_0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSyntaxExpressionAccess().getTextAssignment_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1166:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    {
                    // InternalSM2.g:1166:2: ( ( rule__SyntaxExpression__Group_1__0 ) )
                    // InternalSM2.g:1167:3: ( rule__SyntaxExpression__Group_1__0 )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    }
                    // InternalSM2.g:1168:3: ( rule__SyntaxExpression__Group_1__0 )
                    // InternalSM2.g:1168:4: rule__SyntaxExpression__Group_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSyntaxExpressionAccess().getGroup_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Alternatives"


    // $ANTLR start "rule__Comment__Alternatives"
    // InternalSM2.g:1176:1: rule__Comment__Alternatives : ( ( ruleShortComment ) | ( ruleLongComment ) );
    public final void rule__Comment__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1180:1: ( ( ruleShortComment ) | ( ruleLongComment ) )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==79) ) {
                alt16=1;
            }
            else if ( (LA16_0==80) ) {
                alt16=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2.g:1181:2: ( ruleShortComment )
                    {
                    // InternalSM2.g:1181:2: ( ruleShortComment )
                    // InternalSM2.g:1182:3: ruleShortComment
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleShortComment();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1187:2: ( ruleLongComment )
                    {
                    // InternalSM2.g:1187:2: ( ruleLongComment )
                    // InternalSM2.g:1188:3: ruleLongComment
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    }
                    pushFollow(FOLLOW_2);
                    ruleLongComment();

                    state._fsp--;
                    if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Comment__Alternatives"


    // $ANTLR start "rule__LongComment__ExpressionAlternatives_1_0"
    // InternalSM2.g:1197:1: rule__LongComment__ExpressionAlternatives_1_0 : ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) );
    public final void rule__LongComment__ExpressionAlternatives_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1201:1: ( ( RULE_STRING ) | ( RULE_PARAMSLONGCOMENT ) | ( RULE_DEVLONGCOMENT ) | ( RULE_RETURNSLONGCOMENT ) | ( RULE_TITLELONGCOMENT ) | ( RULE_NOTICELONGCOMENT ) )
            int alt17=6;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt17=1;
                }
                break;
            case RULE_PARAMSLONGCOMENT:
                {
                alt17=2;
                }
                break;
            case RULE_DEVLONGCOMENT:
                {
                alt17=3;
                }
                break;
            case RULE_RETURNSLONGCOMENT:
                {
                alt17=4;
                }
                break;
            case RULE_TITLELONGCOMENT:
                {
                alt17=5;
                }
                break;
            case RULE_NOTICELONGCOMENT:
                {
                alt17=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // InternalSM2.g:1202:2: ( RULE_STRING )
                    {
                    // InternalSM2.g:1202:2: ( RULE_STRING )
                    // InternalSM2.g:1203:3: RULE_STRING
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 
                    }
                    match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionSTRINGTerminalRuleCall_1_0_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1208:2: ( RULE_PARAMSLONGCOMENT )
                    {
                    // InternalSM2.g:1208:2: ( RULE_PARAMSLONGCOMENT )
                    // InternalSM2.g:1209:3: RULE_PARAMSLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 
                    }
                    match(input,RULE_PARAMSLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionPARAMSLONGCOMENTTerminalRuleCall_1_0_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1214:2: ( RULE_DEVLONGCOMENT )
                    {
                    // InternalSM2.g:1214:2: ( RULE_DEVLONGCOMENT )
                    // InternalSM2.g:1215:3: RULE_DEVLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 
                    }
                    match(input,RULE_DEVLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionDEVLONGCOMENTTerminalRuleCall_1_0_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1220:2: ( RULE_RETURNSLONGCOMENT )
                    {
                    // InternalSM2.g:1220:2: ( RULE_RETURNSLONGCOMENT )
                    // InternalSM2.g:1221:3: RULE_RETURNSLONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 
                    }
                    match(input,RULE_RETURNSLONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionRETURNSLONGCOMENTTerminalRuleCall_1_0_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1226:2: ( RULE_TITLELONGCOMENT )
                    {
                    // InternalSM2.g:1226:2: ( RULE_TITLELONGCOMENT )
                    // InternalSM2.g:1227:3: RULE_TITLELONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 
                    }
                    match(input,RULE_TITLELONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionTITLELONGCOMENTTerminalRuleCall_1_0_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1232:2: ( RULE_NOTICELONGCOMENT )
                    {
                    // InternalSM2.g:1232:2: ( RULE_NOTICELONGCOMENT )
                    // InternalSM2.g:1233:3: RULE_NOTICELONGCOMENT
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 
                    }
                    match(input,RULE_NOTICELONGCOMENT,FOLLOW_2); if (state.failed) return ;
                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLongCommentAccess().getExpressionNOTICELONGCOMENTTerminalRuleCall_1_0_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAlternatives_1_0"


    // $ANTLR start "rule__SingularType__Alternatives"
    // InternalSM2.g:1242:1: rule__SingularType__Alternatives : ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) | ( ( 'byte' ) ) | ( ( 'bytes32' ) ) );
    public final void rule__SingularType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1246:1: ( ( ( 'int' ) ) | ( ( 'uint' ) ) | ( ( 'uint8' ) ) | ( ( 'uint256' ) ) | ( ( 'string' ) ) | ( ( 'address' ) ) | ( ( 'address payable' ) ) | ( ( 'double' ) ) | ( ( 'bool' ) ) | ( ( 'byte' ) ) | ( ( 'bytes32' ) ) )
            int alt18=11;
            switch ( input.LA(1) ) {
            case 35:
                {
                alt18=1;
                }
                break;
            case 36:
                {
                alt18=2;
                }
                break;
            case 37:
                {
                alt18=3;
                }
                break;
            case 38:
                {
                alt18=4;
                }
                break;
            case 39:
                {
                alt18=5;
                }
                break;
            case 40:
                {
                alt18=6;
                }
                break;
            case 41:
                {
                alt18=7;
                }
                break;
            case 42:
                {
                alt18=8;
                }
                break;
            case 43:
                {
                alt18=9;
                }
                break;
            case 44:
                {
                alt18=10;
                }
                break;
            case 45:
                {
                alt18=11;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 18, 0, input);

                throw nvae;
            }

            switch (alt18) {
                case 1 :
                    // InternalSM2.g:1247:2: ( ( 'int' ) )
                    {
                    // InternalSM2.g:1247:2: ( ( 'int' ) )
                    // InternalSM2.g:1248:3: ( 'int' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1249:3: ( 'int' )
                    // InternalSM2.g:1249:4: 'int'
                    {
                    match(input,35,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1253:2: ( ( 'uint' ) )
                    {
                    // InternalSM2.g:1253:2: ( ( 'uint' ) )
                    // InternalSM2.g:1254:3: ( 'uint' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1255:3: ( 'uint' )
                    // InternalSM2.g:1255:4: 'uint'
                    {
                    match(input,36,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1259:2: ( ( 'uint8' ) )
                    {
                    // InternalSM2.g:1259:2: ( ( 'uint8' ) )
                    // InternalSM2.g:1260:3: ( 'uint8' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1261:3: ( 'uint8' )
                    // InternalSM2.g:1261:4: 'uint8'
                    {
                    match(input,37,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1265:2: ( ( 'uint256' ) )
                    {
                    // InternalSM2.g:1265:2: ( ( 'uint256' ) )
                    // InternalSM2.g:1266:3: ( 'uint256' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1267:3: ( 'uint256' )
                    // InternalSM2.g:1267:4: 'uint256'
                    {
                    match(input,38,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getUINT256EnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1271:2: ( ( 'string' ) )
                    {
                    // InternalSM2.g:1271:2: ( ( 'string' ) )
                    // InternalSM2.g:1272:3: ( 'string' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1273:3: ( 'string' )
                    // InternalSM2.g:1273:4: 'string'
                    {
                    match(input,39,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1277:2: ( ( 'address' ) )
                    {
                    // InternalSM2.g:1277:2: ( ( 'address' ) )
                    // InternalSM2.g:1278:3: ( 'address' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1279:3: ( 'address' )
                    // InternalSM2.g:1279:4: 'address'
                    {
                    match(input,40,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2.g:1283:2: ( ( 'address payable' ) )
                    {
                    // InternalSM2.g:1283:2: ( ( 'address payable' ) )
                    // InternalSM2.g:1284:3: ( 'address payable' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    }
                    // InternalSM2.g:1285:3: ( 'address payable' )
                    // InternalSM2.g:1285:4: 'address payable'
                    {
                    match(input,41,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_6()); 
                    }

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2.g:1289:2: ( ( 'double' ) )
                    {
                    // InternalSM2.g:1289:2: ( ( 'double' ) )
                    // InternalSM2.g:1290:3: ( 'double' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    }
                    // InternalSM2.g:1291:3: ( 'double' )
                    // InternalSM2.g:1291:4: 'double'
                    {
                    match(input,42,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_7()); 
                    }

                    }


                    }
                    break;
                case 9 :
                    // InternalSM2.g:1295:2: ( ( 'bool' ) )
                    {
                    // InternalSM2.g:1295:2: ( ( 'bool' ) )
                    // InternalSM2.g:1296:3: ( 'bool' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    }
                    // InternalSM2.g:1297:3: ( 'bool' )
                    // InternalSM2.g:1297:4: 'bool'
                    {
                    match(input,43,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_8()); 
                    }

                    }


                    }
                    break;
                case 10 :
                    // InternalSM2.g:1301:2: ( ( 'byte' ) )
                    {
                    // InternalSM2.g:1301:2: ( ( 'byte' ) )
                    // InternalSM2.g:1302:3: ( 'byte' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9()); 
                    }
                    // InternalSM2.g:1303:3: ( 'byte' )
                    // InternalSM2.g:1303:4: 'byte'
                    {
                    match(input,44,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getBYTEEnumLiteralDeclaration_9()); 
                    }

                    }


                    }
                    break;
                case 11 :
                    // InternalSM2.g:1307:2: ( ( 'bytes32' ) )
                    {
                    // InternalSM2.g:1307:2: ( ( 'bytes32' ) )
                    // InternalSM2.g:1308:3: ( 'bytes32' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10()); 
                    }
                    // InternalSM2.g:1309:3: ( 'bytes32' )
                    // InternalSM2.g:1309:4: 'bytes32'
                    {
                    match(input,45,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getSingularTypeAccess().getBYTE32EnumLiteralDeclaration_10()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SingularType__Alternatives"


    // $ANTLR start "rule__Visibility__Alternatives"
    // InternalSM2.g:1317:1: rule__Visibility__Alternatives : ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) );
    public final void rule__Visibility__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1321:1: ( ( ( 'public' ) ) | ( ( 'private' ) ) | ( ( 'internal' ) ) | ( ( 'external' ) ) )
            int alt19=4;
            switch ( input.LA(1) ) {
            case 32:
                {
                alt19=1;
                }
                break;
            case 46:
                {
                alt19=2;
                }
                break;
            case 33:
                {
                alt19=3;
                }
                break;
            case 47:
                {
                alt19=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 19, 0, input);

                throw nvae;
            }

            switch (alt19) {
                case 1 :
                    // InternalSM2.g:1322:2: ( ( 'public' ) )
                    {
                    // InternalSM2.g:1322:2: ( ( 'public' ) )
                    // InternalSM2.g:1323:3: ( 'public' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1324:3: ( 'public' )
                    // InternalSM2.g:1324:4: 'public'
                    {
                    match(input,32,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1328:2: ( ( 'private' ) )
                    {
                    // InternalSM2.g:1328:2: ( ( 'private' ) )
                    // InternalSM2.g:1329:3: ( 'private' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1330:3: ( 'private' )
                    // InternalSM2.g:1330:4: 'private'
                    {
                    match(input,46,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1334:2: ( ( 'internal' ) )
                    {
                    // InternalSM2.g:1334:2: ( ( 'internal' ) )
                    // InternalSM2.g:1335:3: ( 'internal' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1336:3: ( 'internal' )
                    // InternalSM2.g:1336:4: 'internal'
                    {
                    match(input,33,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1340:2: ( ( 'external' ) )
                    {
                    // InternalSM2.g:1340:2: ( ( 'external' ) )
                    // InternalSM2.g:1341:3: ( 'external' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1342:3: ( 'external' )
                    // InternalSM2.g:1342:4: 'external'
                    {
                    match(input,47,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getVisibilityAccess().getEXTERNALEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Visibility__Alternatives"


    // $ANTLR start "rule__Coin__Alternatives"
    // InternalSM2.g:1350:1: rule__Coin__Alternatives : ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) );
    public final void rule__Coin__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1354:1: ( ( ( 'ether' ) ) | ( ( 'wei' ) ) | ( ( 'gwei' ) ) | ( ( 'pwei' ) ) | ( ( 'finney' ) ) | ( ( 'szabo' ) ) )
            int alt20=6;
            switch ( input.LA(1) ) {
            case 48:
                {
                alt20=1;
                }
                break;
            case 49:
                {
                alt20=2;
                }
                break;
            case 50:
                {
                alt20=3;
                }
                break;
            case 51:
                {
                alt20=4;
                }
                break;
            case 52:
                {
                alt20=5;
                }
                break;
            case 53:
                {
                alt20=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // InternalSM2.g:1355:2: ( ( 'ether' ) )
                    {
                    // InternalSM2.g:1355:2: ( ( 'ether' ) )
                    // InternalSM2.g:1356:3: ( 'ether' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1357:3: ( 'ether' )
                    // InternalSM2.g:1357:4: 'ether'
                    {
                    match(input,48,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1361:2: ( ( 'wei' ) )
                    {
                    // InternalSM2.g:1361:2: ( ( 'wei' ) )
                    // InternalSM2.g:1362:3: ( 'wei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1363:3: ( 'wei' )
                    // InternalSM2.g:1363:4: 'wei'
                    {
                    match(input,49,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1367:2: ( ( 'gwei' ) )
                    {
                    // InternalSM2.g:1367:2: ( ( 'gwei' ) )
                    // InternalSM2.g:1368:3: ( 'gwei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1369:3: ( 'gwei' )
                    // InternalSM2.g:1369:4: 'gwei'
                    {
                    match(input,50,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1373:2: ( ( 'pwei' ) )
                    {
                    // InternalSM2.g:1373:2: ( ( 'pwei' ) )
                    // InternalSM2.g:1374:3: ( 'pwei' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1375:3: ( 'pwei' )
                    // InternalSM2.g:1375:4: 'pwei'
                    {
                    match(input,51,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1379:2: ( ( 'finney' ) )
                    {
                    // InternalSM2.g:1379:2: ( ( 'finney' ) )
                    // InternalSM2.g:1380:3: ( 'finney' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1381:3: ( 'finney' )
                    // InternalSM2.g:1381:4: 'finney'
                    {
                    match(input,52,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1385:2: ( ( 'szabo' ) )
                    {
                    // InternalSM2.g:1385:2: ( ( 'szabo' ) )
                    // InternalSM2.g:1386:3: ( 'szabo' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1387:3: ( 'szabo' )
                    // InternalSM2.g:1387:4: 'szabo'
                    {
                    match(input,53,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Coin__Alternatives"


    // $ANTLR start "rule__ComparationOperator__Alternatives"
    // InternalSM2.g:1395:1: rule__ComparationOperator__Alternatives : ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) );
    public final void rule__ComparationOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1399:1: ( ( ( '>' ) ) | ( ( '<' ) ) | ( ( '>=' ) ) | ( ( '<=' ) ) | ( ( '==' ) ) | ( ( '!=' ) ) )
            int alt21=6;
            switch ( input.LA(1) ) {
            case 28:
                {
                alt21=1;
                }
                break;
            case 30:
                {
                alt21=2;
                }
                break;
            case 29:
                {
                alt21=3;
                }
                break;
            case 31:
                {
                alt21=4;
                }
                break;
            case 54:
                {
                alt21=5;
                }
                break;
            case 55:
                {
                alt21=6;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalSM2.g:1400:2: ( ( '>' ) )
                    {
                    // InternalSM2.g:1400:2: ( ( '>' ) )
                    // InternalSM2.g:1401:3: ( '>' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1402:3: ( '>' )
                    // InternalSM2.g:1402:4: '>'
                    {
                    match(input,28,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1406:2: ( ( '<' ) )
                    {
                    // InternalSM2.g:1406:2: ( ( '<' ) )
                    // InternalSM2.g:1407:3: ( '<' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1408:3: ( '<' )
                    // InternalSM2.g:1408:4: '<'
                    {
                    match(input,30,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1412:2: ( ( '>=' ) )
                    {
                    // InternalSM2.g:1412:2: ( ( '>=' ) )
                    // InternalSM2.g:1413:3: ( '>=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1414:3: ( '>=' )
                    // InternalSM2.g:1414:4: '>='
                    {
                    match(input,29,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1418:2: ( ( '<=' ) )
                    {
                    // InternalSM2.g:1418:2: ( ( '<=' ) )
                    // InternalSM2.g:1419:3: ( '<=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1420:3: ( '<=' )
                    // InternalSM2.g:1420:4: '<='
                    {
                    match(input,31,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2.g:1424:2: ( ( '==' ) )
                    {
                    // InternalSM2.g:1424:2: ( ( '==' ) )
                    // InternalSM2.g:1425:3: ( '==' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    }
                    // InternalSM2.g:1426:3: ( '==' )
                    // InternalSM2.g:1426:4: '=='
                    {
                    match(input,54,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4()); 
                    }

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2.g:1430:2: ( ( '!=' ) )
                    {
                    // InternalSM2.g:1430:2: ( ( '!=' ) )
                    // InternalSM2.g:1431:3: ( '!=' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    }
                    // InternalSM2.g:1432:3: ( '!=' )
                    // InternalSM2.g:1432:4: '!='
                    {
                    match(input,55,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ComparationOperator__Alternatives"


    // $ANTLR start "rule__LogicalPairOperator__Alternatives"
    // InternalSM2.g:1440:1: rule__LogicalPairOperator__Alternatives : ( ( ( '&&' ) ) | ( ( '||' ) ) );
    public final void rule__LogicalPairOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1444:1: ( ( ( '&&' ) ) | ( ( '||' ) ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==56) ) {
                alt22=1;
            }
            else if ( (LA22_0==57) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // InternalSM2.g:1445:2: ( ( '&&' ) )
                    {
                    // InternalSM2.g:1445:2: ( ( '&&' ) )
                    // InternalSM2.g:1446:3: ( '&&' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1447:3: ( '&&' )
                    // InternalSM2.g:1447:4: '&&'
                    {
                    match(input,56,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1451:2: ( ( '||' ) )
                    {
                    // InternalSM2.g:1451:2: ( ( '||' ) )
                    // InternalSM2.g:1452:3: ( '||' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1453:3: ( '||' )
                    // InternalSM2.g:1453:4: '||'
                    {
                    match(input,57,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LogicalPairOperator__Alternatives"


    // $ANTLR start "rule__ArithmeticalOperator__Alternatives"
    // InternalSM2.g:1461:1: rule__ArithmeticalOperator__Alternatives : ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) );
    public final void rule__ArithmeticalOperator__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1465:1: ( ( ( '+' ) ) | ( ( '-' ) ) | ( ( '*' ) ) | ( ( '/' ) ) )
            int alt23=4;
            switch ( input.LA(1) ) {
            case 58:
                {
                alt23=1;
                }
                break;
            case 59:
                {
                alt23=2;
                }
                break;
            case 60:
                {
                alt23=3;
                }
                break;
            case 61:
                {
                alt23=4;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return ;}
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }

            switch (alt23) {
                case 1 :
                    // InternalSM2.g:1466:2: ( ( '+' ) )
                    {
                    // InternalSM2.g:1466:2: ( ( '+' ) )
                    // InternalSM2.g:1467:3: ( '+' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    }
                    // InternalSM2.g:1468:3: ( '+' )
                    // InternalSM2.g:1468:4: '+'
                    {
                    match(input,58,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0()); 
                    }

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2.g:1472:2: ( ( '-' ) )
                    {
                    // InternalSM2.g:1472:2: ( ( '-' ) )
                    // InternalSM2.g:1473:3: ( '-' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    }
                    // InternalSM2.g:1474:3: ( '-' )
                    // InternalSM2.g:1474:4: '-'
                    {
                    match(input,59,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1()); 
                    }

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2.g:1478:2: ( ( '*' ) )
                    {
                    // InternalSM2.g:1478:2: ( ( '*' ) )
                    // InternalSM2.g:1479:3: ( '*' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    }
                    // InternalSM2.g:1480:3: ( '*' )
                    // InternalSM2.g:1480:4: '*'
                    {
                    match(input,60,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2()); 
                    }

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2.g:1484:2: ( ( '/' ) )
                    {
                    // InternalSM2.g:1484:2: ( ( '/' ) )
                    // InternalSM2.g:1485:3: ( '/' )
                    {
                    if ( state.backtracking==0 ) {
                       before(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    }
                    // InternalSM2.g:1486:3: ( '/' )
                    // InternalSM2.g:1486:4: '/'
                    {
                    match(input,61,FOLLOW_2); if (state.failed) return ;

                    }

                    if ( state.backtracking==0 ) {
                       after(grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3()); 
                    }

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmeticalOperator__Alternatives"


    // $ANTLR start "rule__SmartContract__Group__0"
    // InternalSM2.g:1494:1: rule__SmartContract__Group__0 : rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 ;
    public final void rule__SmartContract__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1498:1: ( rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1 )
            // InternalSM2.g:1499:2: rule__SmartContract__Group__0__Impl rule__SmartContract__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__SmartContract__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0"


    // $ANTLR start "rule__SmartContract__Group__0__Impl"
    // InternalSM2.g:1506:1: rule__SmartContract__Group__0__Impl : ( ( rule__SmartContract__CompilerAssignment_0 ) ) ;
    public final void rule__SmartContract__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1510:1: ( ( ( rule__SmartContract__CompilerAssignment_0 ) ) )
            // InternalSM2.g:1511:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            {
            // InternalSM2.g:1511:1: ( ( rule__SmartContract__CompilerAssignment_0 ) )
            // InternalSM2.g:1512:2: ( rule__SmartContract__CompilerAssignment_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            }
            // InternalSM2.g:1513:2: ( rule__SmartContract__CompilerAssignment_0 )
            // InternalSM2.g:1513:3: rule__SmartContract__CompilerAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__CompilerAssignment_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerAssignment_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__0__Impl"


    // $ANTLR start "rule__SmartContract__Group__1"
    // InternalSM2.g:1521:1: rule__SmartContract__Group__1 : rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 ;
    public final void rule__SmartContract__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1525:1: ( rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2 )
            // InternalSM2.g:1526:2: rule__SmartContract__Group__1__Impl rule__SmartContract__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__SmartContract__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1"


    // $ANTLR start "rule__SmartContract__Group__1__Impl"
    // InternalSM2.g:1533:1: rule__SmartContract__Group__1__Impl : ( 'solidity' ) ;
    public final void rule__SmartContract__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1537:1: ( ( 'solidity' ) )
            // InternalSM2.g:1538:1: ( 'solidity' )
            {
            // InternalSM2.g:1538:1: ( 'solidity' )
            // InternalSM2.g:1539:2: 'solidity'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            }
            match(input,62,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getSolidityKeyword_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__1__Impl"


    // $ANTLR start "rule__SmartContract__Group__2"
    // InternalSM2.g:1548:1: rule__SmartContract__Group__2 : rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 ;
    public final void rule__SmartContract__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1552:1: ( rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3 )
            // InternalSM2.g:1553:2: rule__SmartContract__Group__2__Impl rule__SmartContract__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__SmartContract__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2"


    // $ANTLR start "rule__SmartContract__Group__2__Impl"
    // InternalSM2.g:1560:1: rule__SmartContract__Group__2__Impl : ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) ;
    public final void rule__SmartContract__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1564:1: ( ( ( rule__SmartContract__VersionCompilerAssignment_2 ) ) )
            // InternalSM2.g:1565:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            {
            // InternalSM2.g:1565:1: ( ( rule__SmartContract__VersionCompilerAssignment_2 ) )
            // InternalSM2.g:1566:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            }
            // InternalSM2.g:1567:2: ( rule__SmartContract__VersionCompilerAssignment_2 )
            // InternalSM2.g:1567:3: rule__SmartContract__VersionCompilerAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__VersionCompilerAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getVersionCompilerAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__Group__3"
    // InternalSM2.g:1575:1: rule__SmartContract__Group__3 : rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 ;
    public final void rule__SmartContract__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1579:1: ( rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4 )
            // InternalSM2.g:1580:2: rule__SmartContract__Group__3__Impl rule__SmartContract__Group__4
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3"


    // $ANTLR start "rule__SmartContract__Group__3__Impl"
    // InternalSM2.g:1587:1: rule__SmartContract__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SmartContract__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1591:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:1592:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:1592:1: ( RULE_SEMICOLON )
            // InternalSM2.g:1593:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getSEMICOLONTerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__3__Impl"


    // $ANTLR start "rule__SmartContract__Group__4"
    // InternalSM2.g:1602:1: rule__SmartContract__Group__4 : rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 ;
    public final void rule__SmartContract__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1606:1: ( rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5 )
            // InternalSM2.g:1607:2: rule__SmartContract__Group__4__Impl rule__SmartContract__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4"


    // $ANTLR start "rule__SmartContract__Group__4__Impl"
    // InternalSM2.g:1614:1: rule__SmartContract__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1618:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1619:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1619:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1620:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            }
            // InternalSM2.g:1621:2: ( RULE_EOLINE )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==RULE_EOLINE) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalSM2.g:1621:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__4__Impl"


    // $ANTLR start "rule__SmartContract__Group__5"
    // InternalSM2.g:1629:1: rule__SmartContract__Group__5 : rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 ;
    public final void rule__SmartContract__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1633:1: ( rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6 )
            // InternalSM2.g:1634:2: rule__SmartContract__Group__5__Impl rule__SmartContract__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5"


    // $ANTLR start "rule__SmartContract__Group__5__Impl"
    // InternalSM2.g:1641:1: rule__SmartContract__Group__5__Impl : ( ( rule__SmartContract__ImportsAssignment_5 )* ) ;
    public final void rule__SmartContract__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1645:1: ( ( ( rule__SmartContract__ImportsAssignment_5 )* ) )
            // InternalSM2.g:1646:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            {
            // InternalSM2.g:1646:1: ( ( rule__SmartContract__ImportsAssignment_5 )* )
            // InternalSM2.g:1647:2: ( rule__SmartContract__ImportsAssignment_5 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            }
            // InternalSM2.g:1648:2: ( rule__SmartContract__ImportsAssignment_5 )*
            loop25:
            do {
                int alt25=2;
                int LA25_0 = input.LA(1);

                if ( (LA25_0==64) ) {
                    alt25=1;
                }


                switch (alt25) {
            	case 1 :
            	    // InternalSM2.g:1648:3: rule__SmartContract__ImportsAssignment_5
            	    {
            	    pushFollow(FOLLOW_7);
            	    rule__SmartContract__ImportsAssignment_5();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop25;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getImportsAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__5__Impl"


    // $ANTLR start "rule__SmartContract__Group__6"
    // InternalSM2.g:1656:1: rule__SmartContract__Group__6 : rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 ;
    public final void rule__SmartContract__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1660:1: ( rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7 )
            // InternalSM2.g:1661:2: rule__SmartContract__Group__6__Impl rule__SmartContract__Group__7
            {
            pushFollow(FOLLOW_6);
            rule__SmartContract__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6"


    // $ANTLR start "rule__SmartContract__Group__6__Impl"
    // InternalSM2.g:1668:1: rule__SmartContract__Group__6__Impl : ( ( rule__SmartContract__InterfacesAssignment_6 )* ) ;
    public final void rule__SmartContract__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1672:1: ( ( ( rule__SmartContract__InterfacesAssignment_6 )* ) )
            // InternalSM2.g:1673:1: ( ( rule__SmartContract__InterfacesAssignment_6 )* )
            {
            // InternalSM2.g:1673:1: ( ( rule__SmartContract__InterfacesAssignment_6 )* )
            // InternalSM2.g:1674:2: ( rule__SmartContract__InterfacesAssignment_6 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getInterfacesAssignment_6()); 
            }
            // InternalSM2.g:1675:2: ( rule__SmartContract__InterfacesAssignment_6 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==66) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalSM2.g:1675:3: rule__SmartContract__InterfacesAssignment_6
            	    {
            	    pushFollow(FOLLOW_8);
            	    rule__SmartContract__InterfacesAssignment_6();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getInterfacesAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__6__Impl"


    // $ANTLR start "rule__SmartContract__Group__7"
    // InternalSM2.g:1683:1: rule__SmartContract__Group__7 : rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 ;
    public final void rule__SmartContract__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1687:1: ( rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8 )
            // InternalSM2.g:1688:2: rule__SmartContract__Group__7__Impl rule__SmartContract__Group__8
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7"


    // $ANTLR start "rule__SmartContract__Group__7__Impl"
    // InternalSM2.g:1695:1: rule__SmartContract__Group__7__Impl : ( ( rule__SmartContract__ContractAssignment_7 ) ) ;
    public final void rule__SmartContract__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1699:1: ( ( ( rule__SmartContract__ContractAssignment_7 ) ) )
            // InternalSM2.g:1700:1: ( ( rule__SmartContract__ContractAssignment_7 ) )
            {
            // InternalSM2.g:1700:1: ( ( rule__SmartContract__ContractAssignment_7 ) )
            // InternalSM2.g:1701:2: ( rule__SmartContract__ContractAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractAssignment_7()); 
            }
            // InternalSM2.g:1702:2: ( rule__SmartContract__ContractAssignment_7 )
            // InternalSM2.g:1702:3: rule__SmartContract__ContractAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__ContractAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__7__Impl"


    // $ANTLR start "rule__SmartContract__Group__8"
    // InternalSM2.g:1710:1: rule__SmartContract__Group__8 : rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 ;
    public final void rule__SmartContract__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1714:1: ( rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9 )
            // InternalSM2.g:1715:2: rule__SmartContract__Group__8__Impl rule__SmartContract__Group__9
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8"


    // $ANTLR start "rule__SmartContract__Group__8__Impl"
    // InternalSM2.g:1722:1: rule__SmartContract__Group__8__Impl : ( ( rule__SmartContract__NameContractAssignment_8 ) ) ;
    public final void rule__SmartContract__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1726:1: ( ( ( rule__SmartContract__NameContractAssignment_8 ) ) )
            // InternalSM2.g:1727:1: ( ( rule__SmartContract__NameContractAssignment_8 ) )
            {
            // InternalSM2.g:1727:1: ( ( rule__SmartContract__NameContractAssignment_8 ) )
            // InternalSM2.g:1728:2: ( rule__SmartContract__NameContractAssignment_8 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractAssignment_8()); 
            }
            // InternalSM2.g:1729:2: ( rule__SmartContract__NameContractAssignment_8 )
            // InternalSM2.g:1729:3: rule__SmartContract__NameContractAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractAssignment_8();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractAssignment_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__8__Impl"


    // $ANTLR start "rule__SmartContract__Group__9"
    // InternalSM2.g:1737:1: rule__SmartContract__Group__9 : rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 ;
    public final void rule__SmartContract__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1741:1: ( rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10 )
            // InternalSM2.g:1742:2: rule__SmartContract__Group__9__Impl rule__SmartContract__Group__10
            {
            pushFollow(FOLLOW_10);
            rule__SmartContract__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9"


    // $ANTLR start "rule__SmartContract__Group__9__Impl"
    // InternalSM2.g:1749:1: rule__SmartContract__Group__9__Impl : ( ( rule__SmartContract__Group_9__0 )? ) ;
    public final void rule__SmartContract__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1753:1: ( ( ( rule__SmartContract__Group_9__0 )? ) )
            // InternalSM2.g:1754:1: ( ( rule__SmartContract__Group_9__0 )? )
            {
            // InternalSM2.g:1754:1: ( ( rule__SmartContract__Group_9__0 )? )
            // InternalSM2.g:1755:2: ( rule__SmartContract__Group_9__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getGroup_9()); 
            }
            // InternalSM2.g:1756:2: ( rule__SmartContract__Group_9__0 )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==63) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalSM2.g:1756:3: rule__SmartContract__Group_9__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__Group_9__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getGroup_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__9__Impl"


    // $ANTLR start "rule__SmartContract__Group__10"
    // InternalSM2.g:1764:1: rule__SmartContract__Group__10 : rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 ;
    public final void rule__SmartContract__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1768:1: ( rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11 )
            // InternalSM2.g:1769:2: rule__SmartContract__Group__10__Impl rule__SmartContract__Group__11
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10"


    // $ANTLR start "rule__SmartContract__Group__10__Impl"
    // InternalSM2.g:1776:1: rule__SmartContract__Group__10__Impl : ( RULE_OPENKEY ) ;
    public final void rule__SmartContract__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1780:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:1781:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:1781:1: ( RULE_OPENKEY )
            // InternalSM2.g:1782:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_10()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getOPENKEYTerminalRuleCall_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__10__Impl"


    // $ANTLR start "rule__SmartContract__Group__11"
    // InternalSM2.g:1791:1: rule__SmartContract__Group__11 : rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 ;
    public final void rule__SmartContract__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1795:1: ( rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12 )
            // InternalSM2.g:1796:2: rule__SmartContract__Group__11__Impl rule__SmartContract__Group__12
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11"


    // $ANTLR start "rule__SmartContract__Group__11__Impl"
    // InternalSM2.g:1803:1: rule__SmartContract__Group__11__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__SmartContract__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1807:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:1808:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:1808:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:1809:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_11()); 
            }
            // InternalSM2.g:1810:2: ( RULE_EOLINE )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==RULE_EOLINE) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalSM2.g:1810:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEOLINETerminalRuleCall_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__11__Impl"


    // $ANTLR start "rule__SmartContract__Group__12"
    // InternalSM2.g:1818:1: rule__SmartContract__Group__12 : rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 ;
    public final void rule__SmartContract__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1822:1: ( rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13 )
            // InternalSM2.g:1823:2: rule__SmartContract__Group__12__Impl rule__SmartContract__Group__13
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__13();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12"


    // $ANTLR start "rule__SmartContract__Group__12__Impl"
    // InternalSM2.g:1830:1: rule__SmartContract__Group__12__Impl : ( ( rule__SmartContract__AttributesAssignment_12 )* ) ;
    public final void rule__SmartContract__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1834:1: ( ( ( rule__SmartContract__AttributesAssignment_12 )* ) )
            // InternalSM2.g:1835:1: ( ( rule__SmartContract__AttributesAssignment_12 )* )
            {
            // InternalSM2.g:1835:1: ( ( rule__SmartContract__AttributesAssignment_12 )* )
            // InternalSM2.g:1836:2: ( rule__SmartContract__AttributesAssignment_12 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getAttributesAssignment_12()); 
            }
            // InternalSM2.g:1837:2: ( rule__SmartContract__AttributesAssignment_12 )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==RULE_ID||(LA29_0>=35 && LA29_0<=45)||LA29_0==72||LA29_0==74||LA29_0==76) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // InternalSM2.g:1837:3: rule__SmartContract__AttributesAssignment_12
            	    {
            	    pushFollow(FOLLOW_12);
            	    rule__SmartContract__AttributesAssignment_12();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getAttributesAssignment_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__12__Impl"


    // $ANTLR start "rule__SmartContract__Group__13"
    // InternalSM2.g:1845:1: rule__SmartContract__Group__13 : rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 ;
    public final void rule__SmartContract__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1849:1: ( rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14 )
            // InternalSM2.g:1850:2: rule__SmartContract__Group__13__Impl rule__SmartContract__Group__14
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__13__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__14();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13"


    // $ANTLR start "rule__SmartContract__Group__13__Impl"
    // InternalSM2.g:1857:1: rule__SmartContract__Group__13__Impl : ( ( rule__SmartContract__ConstructorAssignment_13 )? ) ;
    public final void rule__SmartContract__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1861:1: ( ( ( rule__SmartContract__ConstructorAssignment_13 )? ) )
            // InternalSM2.g:1862:1: ( ( rule__SmartContract__ConstructorAssignment_13 )? )
            {
            // InternalSM2.g:1862:1: ( ( rule__SmartContract__ConstructorAssignment_13 )? )
            // InternalSM2.g:1863:2: ( rule__SmartContract__ConstructorAssignment_13 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getConstructorAssignment_13()); 
            }
            // InternalSM2.g:1864:2: ( rule__SmartContract__ConstructorAssignment_13 )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( (LA30_0==67) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalSM2.g:1864:3: rule__SmartContract__ConstructorAssignment_13
                    {
                    pushFollow(FOLLOW_2);
                    rule__SmartContract__ConstructorAssignment_13();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getConstructorAssignment_13()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__13__Impl"


    // $ANTLR start "rule__SmartContract__Group__14"
    // InternalSM2.g:1872:1: rule__SmartContract__Group__14 : rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 ;
    public final void rule__SmartContract__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1876:1: ( rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15 )
            // InternalSM2.g:1877:2: rule__SmartContract__Group__14__Impl rule__SmartContract__Group__15
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__14__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__15();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14"


    // $ANTLR start "rule__SmartContract__Group__14__Impl"
    // InternalSM2.g:1884:1: rule__SmartContract__Group__14__Impl : ( ( rule__SmartContract__EventsAssignment_14 )* ) ;
    public final void rule__SmartContract__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1888:1: ( ( ( rule__SmartContract__EventsAssignment_14 )* ) )
            // InternalSM2.g:1889:1: ( ( rule__SmartContract__EventsAssignment_14 )* )
            {
            // InternalSM2.g:1889:1: ( ( rule__SmartContract__EventsAssignment_14 )* )
            // InternalSM2.g:1890:2: ( rule__SmartContract__EventsAssignment_14 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEventsAssignment_14()); 
            }
            // InternalSM2.g:1891:2: ( rule__SmartContract__EventsAssignment_14 )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==69) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalSM2.g:1891:3: rule__SmartContract__EventsAssignment_14
            	    {
            	    pushFollow(FOLLOW_13);
            	    rule__SmartContract__EventsAssignment_14();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEventsAssignment_14()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__14__Impl"


    // $ANTLR start "rule__SmartContract__Group__15"
    // InternalSM2.g:1899:1: rule__SmartContract__Group__15 : rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 ;
    public final void rule__SmartContract__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1903:1: ( rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16 )
            // InternalSM2.g:1904:2: rule__SmartContract__Group__15__Impl rule__SmartContract__Group__16
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__15__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__16();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15"


    // $ANTLR start "rule__SmartContract__Group__15__Impl"
    // InternalSM2.g:1911:1: rule__SmartContract__Group__15__Impl : ( ( rule__SmartContract__ModifierAssignment_15 )* ) ;
    public final void rule__SmartContract__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1915:1: ( ( ( rule__SmartContract__ModifierAssignment_15 )* ) )
            // InternalSM2.g:1916:1: ( ( rule__SmartContract__ModifierAssignment_15 )* )
            {
            // InternalSM2.g:1916:1: ( ( rule__SmartContract__ModifierAssignment_15 )* )
            // InternalSM2.g:1917:2: ( rule__SmartContract__ModifierAssignment_15 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getModifierAssignment_15()); 
            }
            // InternalSM2.g:1918:2: ( rule__SmartContract__ModifierAssignment_15 )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( (LA32_0==70) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalSM2.g:1918:3: rule__SmartContract__ModifierAssignment_15
            	    {
            	    pushFollow(FOLLOW_14);
            	    rule__SmartContract__ModifierAssignment_15();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getModifierAssignment_15()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__15__Impl"


    // $ANTLR start "rule__SmartContract__Group__16"
    // InternalSM2.g:1926:1: rule__SmartContract__Group__16 : rule__SmartContract__Group__16__Impl rule__SmartContract__Group__17 ;
    public final void rule__SmartContract__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1930:1: ( rule__SmartContract__Group__16__Impl rule__SmartContract__Group__17 )
            // InternalSM2.g:1931:2: rule__SmartContract__Group__16__Impl rule__SmartContract__Group__17
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__16__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__17();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16"


    // $ANTLR start "rule__SmartContract__Group__16__Impl"
    // InternalSM2.g:1938:1: rule__SmartContract__Group__16__Impl : ( ( rule__SmartContract__ClausesAssignment_16 )* ) ;
    public final void rule__SmartContract__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1942:1: ( ( ( rule__SmartContract__ClausesAssignment_16 )* ) )
            // InternalSM2.g:1943:1: ( ( rule__SmartContract__ClausesAssignment_16 )* )
            {
            // InternalSM2.g:1943:1: ( ( rule__SmartContract__ClausesAssignment_16 )* )
            // InternalSM2.g:1944:2: ( rule__SmartContract__ClausesAssignment_16 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getClausesAssignment_16()); 
            }
            // InternalSM2.g:1945:2: ( rule__SmartContract__ClausesAssignment_16 )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==78) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalSM2.g:1945:3: rule__SmartContract__ClausesAssignment_16
            	    {
            	    pushFollow(FOLLOW_15);
            	    rule__SmartContract__ClausesAssignment_16();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getClausesAssignment_16()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__16__Impl"


    // $ANTLR start "rule__SmartContract__Group__17"
    // InternalSM2.g:1953:1: rule__SmartContract__Group__17 : rule__SmartContract__Group__17__Impl rule__SmartContract__Group__18 ;
    public final void rule__SmartContract__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1957:1: ( rule__SmartContract__Group__17__Impl rule__SmartContract__Group__18 )
            // InternalSM2.g:1958:2: rule__SmartContract__Group__17__Impl rule__SmartContract__Group__18
            {
            pushFollow(FOLLOW_11);
            rule__SmartContract__Group__17__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__18();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__17"


    // $ANTLR start "rule__SmartContract__Group__17__Impl"
    // InternalSM2.g:1965:1: rule__SmartContract__Group__17__Impl : ( ( rule__SmartContract__CommentsAssignment_17 )* ) ;
    public final void rule__SmartContract__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1969:1: ( ( ( rule__SmartContract__CommentsAssignment_17 )* ) )
            // InternalSM2.g:1970:1: ( ( rule__SmartContract__CommentsAssignment_17 )* )
            {
            // InternalSM2.g:1970:1: ( ( rule__SmartContract__CommentsAssignment_17 )* )
            // InternalSM2.g:1971:2: ( rule__SmartContract__CommentsAssignment_17 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCommentsAssignment_17()); 
            }
            // InternalSM2.g:1972:2: ( rule__SmartContract__CommentsAssignment_17 )*
            loop34:
            do {
                int alt34=2;
                int LA34_0 = input.LA(1);

                if ( ((LA34_0>=79 && LA34_0<=80)) ) {
                    alt34=1;
                }


                switch (alt34) {
            	case 1 :
            	    // InternalSM2.g:1972:3: rule__SmartContract__CommentsAssignment_17
            	    {
            	    pushFollow(FOLLOW_16);
            	    rule__SmartContract__CommentsAssignment_17();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop34;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCommentsAssignment_17()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__17__Impl"


    // $ANTLR start "rule__SmartContract__Group__18"
    // InternalSM2.g:1980:1: rule__SmartContract__Group__18 : rule__SmartContract__Group__18__Impl ;
    public final void rule__SmartContract__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1984:1: ( rule__SmartContract__Group__18__Impl )
            // InternalSM2.g:1985:2: rule__SmartContract__Group__18__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group__18__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__18"


    // $ANTLR start "rule__SmartContract__Group__18__Impl"
    // InternalSM2.g:1991:1: rule__SmartContract__Group__18__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__SmartContract__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:1995:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:1996:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:1996:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:1997:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_18()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCLOSEKEYTerminalRuleCall_18()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group__18__Impl"


    // $ANTLR start "rule__SmartContract__Group_9__0"
    // InternalSM2.g:2007:1: rule__SmartContract__Group_9__0 : rule__SmartContract__Group_9__0__Impl rule__SmartContract__Group_9__1 ;
    public final void rule__SmartContract__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2011:1: ( rule__SmartContract__Group_9__0__Impl rule__SmartContract__Group_9__1 )
            // InternalSM2.g:2012:2: rule__SmartContract__Group_9__0__Impl rule__SmartContract__Group_9__1
            {
            pushFollow(FOLLOW_9);
            rule__SmartContract__Group_9__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_9__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_9__0"


    // $ANTLR start "rule__SmartContract__Group_9__0__Impl"
    // InternalSM2.g:2019:1: rule__SmartContract__Group_9__0__Impl : ( 'is' ) ;
    public final void rule__SmartContract__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2023:1: ( ( 'is' ) )
            // InternalSM2.g:2024:1: ( 'is' )
            {
            // InternalSM2.g:2024:1: ( 'is' )
            // InternalSM2.g:2025:2: 'is'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getIsKeyword_9_0()); 
            }
            match(input,63,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getIsKeyword_9_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_9__0__Impl"


    // $ANTLR start "rule__SmartContract__Group_9__1"
    // InternalSM2.g:2034:1: rule__SmartContract__Group_9__1 : rule__SmartContract__Group_9__1__Impl ;
    public final void rule__SmartContract__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2038:1: ( rule__SmartContract__Group_9__1__Impl )
            // InternalSM2.g:2039:2: rule__SmartContract__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__Group_9__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_9__1"


    // $ANTLR start "rule__SmartContract__Group_9__1__Impl"
    // InternalSM2.g:2045:1: rule__SmartContract__Group_9__1__Impl : ( ( rule__SmartContract__NameContractFatherAssignment_9_1 ) ) ;
    public final void rule__SmartContract__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2049:1: ( ( ( rule__SmartContract__NameContractFatherAssignment_9_1 ) ) )
            // InternalSM2.g:2050:1: ( ( rule__SmartContract__NameContractFatherAssignment_9_1 ) )
            {
            // InternalSM2.g:2050:1: ( ( rule__SmartContract__NameContractFatherAssignment_9_1 ) )
            // InternalSM2.g:2051:2: ( rule__SmartContract__NameContractFatherAssignment_9_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_9_1()); 
            }
            // InternalSM2.g:2052:2: ( rule__SmartContract__NameContractFatherAssignment_9_1 )
            // InternalSM2.g:2052:3: rule__SmartContract__NameContractFatherAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__SmartContract__NameContractFatherAssignment_9_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractFatherAssignment_9_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__Group_9__1__Impl"


    // $ANTLR start "rule__Version__Group_0__0"
    // InternalSM2.g:2061:1: rule__Version__Group_0__0 : rule__Version__Group_0__0__Impl rule__Version__Group_0__1 ;
    public final void rule__Version__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2065:1: ( rule__Version__Group_0__0__Impl rule__Version__Group_0__1 )
            // InternalSM2.g:2066:2: rule__Version__Group_0__0__Impl rule__Version__Group_0__1
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0"


    // $ANTLR start "rule__Version__Group_0__0__Impl"
    // InternalSM2.g:2073:1: rule__Version__Group_0__0__Impl : ( ( rule__Version__SymbolAssignment_0_0 ) ) ;
    public final void rule__Version__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2077:1: ( ( ( rule__Version__SymbolAssignment_0_0 ) ) )
            // InternalSM2.g:2078:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            {
            // InternalSM2.g:2078:1: ( ( rule__Version__SymbolAssignment_0_0 ) )
            // InternalSM2.g:2079:2: ( rule__Version__SymbolAssignment_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 
            }
            // InternalSM2.g:2080:2: ( rule__Version__SymbolAssignment_0_0 )
            // InternalSM2.g:2080:3: rule__Version__SymbolAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAssignment_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__0__Impl"


    // $ANTLR start "rule__Version__Group_0__1"
    // InternalSM2.g:2088:1: rule__Version__Group_0__1 : rule__Version__Group_0__1__Impl rule__Version__Group_0__2 ;
    public final void rule__Version__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2092:1: ( rule__Version__Group_0__1__Impl rule__Version__Group_0__2 )
            // InternalSM2.g:2093:2: rule__Version__Group_0__1__Impl rule__Version__Group_0__2
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1"


    // $ANTLR start "rule__Version__Group_0__1__Impl"
    // InternalSM2.g:2100:1: rule__Version__Group_0__1__Impl : ( ( rule__Version__NumberVersionAssignment_0_1 ) ) ;
    public final void rule__Version__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2104:1: ( ( ( rule__Version__NumberVersionAssignment_0_1 ) ) )
            // InternalSM2.g:2105:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            {
            // InternalSM2.g:2105:1: ( ( rule__Version__NumberVersionAssignment_0_1 ) )
            // InternalSM2.g:2106:2: ( rule__Version__NumberVersionAssignment_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 
            }
            // InternalSM2.g:2107:2: ( rule__Version__NumberVersionAssignment_0_1 )
            // InternalSM2.g:2107:3: rule__Version__NumberVersionAssignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionAssignment_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__1__Impl"


    // $ANTLR start "rule__Version__Group_0__2"
    // InternalSM2.g:2115:1: rule__Version__Group_0__2 : rule__Version__Group_0__2__Impl rule__Version__Group_0__3 ;
    public final void rule__Version__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2119:1: ( rule__Version__Group_0__2__Impl rule__Version__Group_0__3 )
            // InternalSM2.g:2120:2: rule__Version__Group_0__2__Impl rule__Version__Group_0__3
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2"


    // $ANTLR start "rule__Version__Group_0__2__Impl"
    // InternalSM2.g:2127:1: rule__Version__Group_0__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2131:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2132:1: ( RULE_DOT )
            {
            // InternalSM2.g:2132:1: ( RULE_DOT )
            // InternalSM2.g:2133:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__2__Impl"


    // $ANTLR start "rule__Version__Group_0__3"
    // InternalSM2.g:2142:1: rule__Version__Group_0__3 : rule__Version__Group_0__3__Impl rule__Version__Group_0__4 ;
    public final void rule__Version__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2146:1: ( rule__Version__Group_0__3__Impl rule__Version__Group_0__4 )
            // InternalSM2.g:2147:2: rule__Version__Group_0__3__Impl rule__Version__Group_0__4
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_0__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3"


    // $ANTLR start "rule__Version__Group_0__3__Impl"
    // InternalSM2.g:2154:1: rule__Version__Group_0__3__Impl : ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) ;
    public final void rule__Version__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2158:1: ( ( ( rule__Version__NumberVersion2Assignment_0_3 ) ) )
            // InternalSM2.g:2159:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            {
            // InternalSM2.g:2159:1: ( ( rule__Version__NumberVersion2Assignment_0_3 ) )
            // InternalSM2.g:2160:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 
            }
            // InternalSM2.g:2161:2: ( rule__Version__NumberVersion2Assignment_0_3 )
            // InternalSM2.g:2161:3: rule__Version__NumberVersion2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_0_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_0_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__3__Impl"


    // $ANTLR start "rule__Version__Group_0__4"
    // InternalSM2.g:2169:1: rule__Version__Group_0__4 : rule__Version__Group_0__4__Impl rule__Version__Group_0__5 ;
    public final void rule__Version__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2173:1: ( rule__Version__Group_0__4__Impl rule__Version__Group_0__5 )
            // InternalSM2.g:2174:2: rule__Version__Group_0__4__Impl rule__Version__Group_0__5
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_0__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4"


    // $ANTLR start "rule__Version__Group_0__4__Impl"
    // InternalSM2.g:2181:1: rule__Version__Group_0__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2185:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2186:1: ( RULE_DOT )
            {
            // InternalSM2.g:2186:1: ( RULE_DOT )
            // InternalSM2.g:2187:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_0_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__4__Impl"


    // $ANTLR start "rule__Version__Group_0__5"
    // InternalSM2.g:2196:1: rule__Version__Group_0__5 : rule__Version__Group_0__5__Impl ;
    public final void rule__Version__Group_0__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2200:1: ( rule__Version__Group_0__5__Impl )
            // InternalSM2.g:2201:2: rule__Version__Group_0__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_0__5__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5"


    // $ANTLR start "rule__Version__Group_0__5__Impl"
    // InternalSM2.g:2207:1: rule__Version__Group_0__5__Impl : ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) ;
    public final void rule__Version__Group_0__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2211:1: ( ( ( rule__Version__NumberVersion3Assignment_0_5 ) ) )
            // InternalSM2.g:2212:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            {
            // InternalSM2.g:2212:1: ( ( rule__Version__NumberVersion3Assignment_0_5 ) )
            // InternalSM2.g:2213:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 
            }
            // InternalSM2.g:2214:2: ( rule__Version__NumberVersion3Assignment_0_5 )
            // InternalSM2.g:2214:3: rule__Version__NumberVersion3Assignment_0_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_0_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_0_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_0__5__Impl"


    // $ANTLR start "rule__Version__Group_1__0"
    // InternalSM2.g:2223:1: rule__Version__Group_1__0 : rule__Version__Group_1__0__Impl rule__Version__Group_1__1 ;
    public final void rule__Version__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2227:1: ( rule__Version__Group_1__0__Impl rule__Version__Group_1__1 )
            // InternalSM2.g:2228:2: rule__Version__Group_1__0__Impl rule__Version__Group_1__1
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0"


    // $ANTLR start "rule__Version__Group_1__0__Impl"
    // InternalSM2.g:2235:1: rule__Version__Group_1__0__Impl : ( ( rule__Version__SymbolAssignment_1_0 ) ) ;
    public final void rule__Version__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2239:1: ( ( ( rule__Version__SymbolAssignment_1_0 ) ) )
            // InternalSM2.g:2240:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            {
            // InternalSM2.g:2240:1: ( ( rule__Version__SymbolAssignment_1_0 ) )
            // InternalSM2.g:2241:2: ( rule__Version__SymbolAssignment_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 
            }
            // InternalSM2.g:2242:2: ( rule__Version__SymbolAssignment_1_0 )
            // InternalSM2.g:2242:3: rule__Version__SymbolAssignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAssignment_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAssignment_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__0__Impl"


    // $ANTLR start "rule__Version__Group_1__1"
    // InternalSM2.g:2250:1: rule__Version__Group_1__1 : rule__Version__Group_1__1__Impl rule__Version__Group_1__2 ;
    public final void rule__Version__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2254:1: ( rule__Version__Group_1__1__Impl rule__Version__Group_1__2 )
            // InternalSM2.g:2255:2: rule__Version__Group_1__1__Impl rule__Version__Group_1__2
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1"


    // $ANTLR start "rule__Version__Group_1__1__Impl"
    // InternalSM2.g:2262:1: rule__Version__Group_1__1__Impl : ( ( rule__Version__NumberVersionAssignment_1_1 ) ) ;
    public final void rule__Version__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2266:1: ( ( ( rule__Version__NumberVersionAssignment_1_1 ) ) )
            // InternalSM2.g:2267:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            {
            // InternalSM2.g:2267:1: ( ( rule__Version__NumberVersionAssignment_1_1 ) )
            // InternalSM2.g:2268:2: ( rule__Version__NumberVersionAssignment_1_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 
            }
            // InternalSM2.g:2269:2: ( rule__Version__NumberVersionAssignment_1_1 )
            // InternalSM2.g:2269:3: rule__Version__NumberVersionAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionAssignment_1_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionAssignment_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__1__Impl"


    // $ANTLR start "rule__Version__Group_1__2"
    // InternalSM2.g:2277:1: rule__Version__Group_1__2 : rule__Version__Group_1__2__Impl rule__Version__Group_1__3 ;
    public final void rule__Version__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2281:1: ( rule__Version__Group_1__2__Impl rule__Version__Group_1__3 )
            // InternalSM2.g:2282:2: rule__Version__Group_1__2__Impl rule__Version__Group_1__3
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2"


    // $ANTLR start "rule__Version__Group_1__2__Impl"
    // InternalSM2.g:2289:1: rule__Version__Group_1__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2293:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2294:1: ( RULE_DOT )
            {
            // InternalSM2.g:2294:1: ( RULE_DOT )
            // InternalSM2.g:2295:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__2__Impl"


    // $ANTLR start "rule__Version__Group_1__3"
    // InternalSM2.g:2304:1: rule__Version__Group_1__3 : rule__Version__Group_1__3__Impl rule__Version__Group_1__4 ;
    public final void rule__Version__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2308:1: ( rule__Version__Group_1__3__Impl rule__Version__Group_1__4 )
            // InternalSM2.g:2309:2: rule__Version__Group_1__3__Impl rule__Version__Group_1__4
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3"


    // $ANTLR start "rule__Version__Group_1__3__Impl"
    // InternalSM2.g:2316:1: rule__Version__Group_1__3__Impl : ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) ;
    public final void rule__Version__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2320:1: ( ( ( rule__Version__NumberVersion2Assignment_1_3 ) ) )
            // InternalSM2.g:2321:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            {
            // InternalSM2.g:2321:1: ( ( rule__Version__NumberVersion2Assignment_1_3 ) )
            // InternalSM2.g:2322:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 
            }
            // InternalSM2.g:2323:2: ( rule__Version__NumberVersion2Assignment_1_3 )
            // InternalSM2.g:2323:3: rule__Version__NumberVersion2Assignment_1_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion2Assignment_1_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2Assignment_1_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__3__Impl"


    // $ANTLR start "rule__Version__Group_1__4"
    // InternalSM2.g:2331:1: rule__Version__Group_1__4 : rule__Version__Group_1__4__Impl rule__Version__Group_1__5 ;
    public final void rule__Version__Group_1__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2335:1: ( rule__Version__Group_1__4__Impl rule__Version__Group_1__5 )
            // InternalSM2.g:2336:2: rule__Version__Group_1__4__Impl rule__Version__Group_1__5
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4"


    // $ANTLR start "rule__Version__Group_1__4__Impl"
    // InternalSM2.g:2343:1: rule__Version__Group_1__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2347:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2348:1: ( RULE_DOT )
            {
            // InternalSM2.g:2348:1: ( RULE_DOT )
            // InternalSM2.g:2349:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__4__Impl"


    // $ANTLR start "rule__Version__Group_1__5"
    // InternalSM2.g:2358:1: rule__Version__Group_1__5 : rule__Version__Group_1__5__Impl rule__Version__Group_1__6 ;
    public final void rule__Version__Group_1__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2362:1: ( rule__Version__Group_1__5__Impl rule__Version__Group_1__6 )
            // InternalSM2.g:2363:2: rule__Version__Group_1__5__Impl rule__Version__Group_1__6
            {
            pushFollow(FOLLOW_19);
            rule__Version__Group_1__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5"


    // $ANTLR start "rule__Version__Group_1__5__Impl"
    // InternalSM2.g:2370:1: rule__Version__Group_1__5__Impl : ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) ;
    public final void rule__Version__Group_1__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2374:1: ( ( ( rule__Version__NumberVersion3Assignment_1_5 ) ) )
            // InternalSM2.g:2375:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            {
            // InternalSM2.g:2375:1: ( ( rule__Version__NumberVersion3Assignment_1_5 ) )
            // InternalSM2.g:2376:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 
            }
            // InternalSM2.g:2377:2: ( rule__Version__NumberVersion3Assignment_1_5 )
            // InternalSM2.g:2377:3: rule__Version__NumberVersion3Assignment_1_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersion3Assignment_1_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3Assignment_1_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__5__Impl"


    // $ANTLR start "rule__Version__Group_1__6"
    // InternalSM2.g:2385:1: rule__Version__Group_1__6 : rule__Version__Group_1__6__Impl ;
    public final void rule__Version__Group_1__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2389:1: ( rule__Version__Group_1__6__Impl )
            // InternalSM2.g:2390:2: rule__Version__Group_1__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6"


    // $ANTLR start "rule__Version__Group_1__6__Impl"
    // InternalSM2.g:2396:1: rule__Version__Group_1__6__Impl : ( ( rule__Version__Group_1_6__0 )? ) ;
    public final void rule__Version__Group_1__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2400:1: ( ( ( rule__Version__Group_1_6__0 )? ) )
            // InternalSM2.g:2401:1: ( ( rule__Version__Group_1_6__0 )? )
            {
            // InternalSM2.g:2401:1: ( ( rule__Version__Group_1_6__0 )? )
            // InternalSM2.g:2402:2: ( rule__Version__Group_1_6__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getGroup_1_6()); 
            }
            // InternalSM2.g:2403:2: ( rule__Version__Group_1_6__0 )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( ((LA35_0>=30 && LA35_0<=31)) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalSM2.g:2403:3: rule__Version__Group_1_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Version__Group_1_6__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getGroup_1_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1__6__Impl"


    // $ANTLR start "rule__Version__Group_1_6__0"
    // InternalSM2.g:2412:1: rule__Version__Group_1_6__0 : rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 ;
    public final void rule__Version__Group_1_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2416:1: ( rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1 )
            // InternalSM2.g:2417:2: rule__Version__Group_1_6__0__Impl rule__Version__Group_1_6__1
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0"


    // $ANTLR start "rule__Version__Group_1_6__0__Impl"
    // InternalSM2.g:2424:1: rule__Version__Group_1_6__0__Impl : ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) ;
    public final void rule__Version__Group_1_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2428:1: ( ( ( rule__Version__Symbol2Assignment_1_6_0 ) ) )
            // InternalSM2.g:2429:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            {
            // InternalSM2.g:2429:1: ( ( rule__Version__Symbol2Assignment_1_6_0 ) )
            // InternalSM2.g:2430:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 
            }
            // InternalSM2.g:2431:2: ( rule__Version__Symbol2Assignment_1_6_0 )
            // InternalSM2.g:2431:3: rule__Version__Symbol2Assignment_1_6_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Assignment_1_6_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbol2Assignment_1_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__0__Impl"


    // $ANTLR start "rule__Version__Group_1_6__1"
    // InternalSM2.g:2439:1: rule__Version__Group_1_6__1 : rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 ;
    public final void rule__Version__Group_1_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2443:1: ( rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2 )
            // InternalSM2.g:2444:2: rule__Version__Group_1_6__1__Impl rule__Version__Group_1_6__2
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1_6__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1"


    // $ANTLR start "rule__Version__Group_1_6__1__Impl"
    // InternalSM2.g:2451:1: rule__Version__Group_1_6__1__Impl : ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) ;
    public final void rule__Version__Group_1_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2455:1: ( ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) ) )
            // InternalSM2.g:2456:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            {
            // InternalSM2.g:2456:1: ( ( rule__Version__NumberVersionOptionalAssignment_1_6_1 ) )
            // InternalSM2.g:2457:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 
            }
            // InternalSM2.g:2458:2: ( rule__Version__NumberVersionOptionalAssignment_1_6_1 )
            // InternalSM2.g:2458:3: rule__Version__NumberVersionOptionalAssignment_1_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptionalAssignment_1_6_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptionalAssignment_1_6_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__1__Impl"


    // $ANTLR start "rule__Version__Group_1_6__2"
    // InternalSM2.g:2466:1: rule__Version__Group_1_6__2 : rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 ;
    public final void rule__Version__Group_1_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2470:1: ( rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3 )
            // InternalSM2.g:2471:2: rule__Version__Group_1_6__2__Impl rule__Version__Group_1_6__3
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2"


    // $ANTLR start "rule__Version__Group_1_6__2__Impl"
    // InternalSM2.g:2478:1: rule__Version__Group_1_6__2__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2482:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2483:1: ( RULE_DOT )
            {
            // InternalSM2.g:2483:1: ( RULE_DOT )
            // InternalSM2.g:2484:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__2__Impl"


    // $ANTLR start "rule__Version__Group_1_6__3"
    // InternalSM2.g:2493:1: rule__Version__Group_1_6__3 : rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 ;
    public final void rule__Version__Group_1_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2497:1: ( rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4 )
            // InternalSM2.g:2498:2: rule__Version__Group_1_6__3__Impl rule__Version__Group_1_6__4
            {
            pushFollow(FOLLOW_18);
            rule__Version__Group_1_6__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3"


    // $ANTLR start "rule__Version__Group_1_6__3__Impl"
    // InternalSM2.g:2505:1: rule__Version__Group_1_6__3__Impl : ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) ;
    public final void rule__Version__Group_1_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2509:1: ( ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) ) )
            // InternalSM2.g:2510:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            {
            // InternalSM2.g:2510:1: ( ( rule__Version__NumberVersionOptional2Assignment_1_6_3 ) )
            // InternalSM2.g:2511:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 
            }
            // InternalSM2.g:2512:2: ( rule__Version__NumberVersionOptional2Assignment_1_6_3 )
            // InternalSM2.g:2512:3: rule__Version__NumberVersionOptional2Assignment_1_6_3
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional2Assignment_1_6_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional2Assignment_1_6_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__3__Impl"


    // $ANTLR start "rule__Version__Group_1_6__4"
    // InternalSM2.g:2520:1: rule__Version__Group_1_6__4 : rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 ;
    public final void rule__Version__Group_1_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2524:1: ( rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5 )
            // InternalSM2.g:2525:2: rule__Version__Group_1_6__4__Impl rule__Version__Group_1_6__5
            {
            pushFollow(FOLLOW_17);
            rule__Version__Group_1_6__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4"


    // $ANTLR start "rule__Version__Group_1_6__4__Impl"
    // InternalSM2.g:2532:1: rule__Version__Group_1_6__4__Impl : ( RULE_DOT ) ;
    public final void rule__Version__Group_1_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2536:1: ( ( RULE_DOT ) )
            // InternalSM2.g:2537:1: ( RULE_DOT )
            {
            // InternalSM2.g:2537:1: ( RULE_DOT )
            // InternalSM2.g:2538:2: RULE_DOT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 
            }
            match(input,RULE_DOT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getDOTTerminalRuleCall_1_6_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__4__Impl"


    // $ANTLR start "rule__Version__Group_1_6__5"
    // InternalSM2.g:2547:1: rule__Version__Group_1_6__5 : rule__Version__Group_1_6__5__Impl ;
    public final void rule__Version__Group_1_6__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2551:1: ( rule__Version__Group_1_6__5__Impl )
            // InternalSM2.g:2552:2: rule__Version__Group_1_6__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Version__Group_1_6__5__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5"


    // $ANTLR start "rule__Version__Group_1_6__5__Impl"
    // InternalSM2.g:2558:1: rule__Version__Group_1_6__5__Impl : ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) ;
    public final void rule__Version__Group_1_6__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2562:1: ( ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) ) )
            // InternalSM2.g:2563:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            {
            // InternalSM2.g:2563:1: ( ( rule__Version__NumberVersionOptional3Assignment_1_6_5 ) )
            // InternalSM2.g:2564:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 
            }
            // InternalSM2.g:2565:2: ( rule__Version__NumberVersionOptional3Assignment_1_6_5 )
            // InternalSM2.g:2565:3: rule__Version__NumberVersionOptional3Assignment_1_6_5
            {
            pushFollow(FOLLOW_2);
            rule__Version__NumberVersionOptional3Assignment_1_6_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional3Assignment_1_6_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Group_1_6__5__Impl"


    // $ANTLR start "rule__Import__Group__0"
    // InternalSM2.g:2574:1: rule__Import__Group__0 : rule__Import__Group__0__Impl rule__Import__Group__1 ;
    public final void rule__Import__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2578:1: ( rule__Import__Group__0__Impl rule__Import__Group__1 )
            // InternalSM2.g:2579:2: rule__Import__Group__0__Impl rule__Import__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Import__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0"


    // $ANTLR start "rule__Import__Group__0__Impl"
    // InternalSM2.g:2586:1: rule__Import__Group__0__Impl : ( 'import' ) ;
    public final void rule__Import__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2590:1: ( ( 'import' ) )
            // InternalSM2.g:2591:1: ( 'import' )
            {
            // InternalSM2.g:2591:1: ( 'import' )
            // InternalSM2.g:2592:2: 'import'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getImportKeyword_0()); 
            }
            match(input,64,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getImportKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__0__Impl"


    // $ANTLR start "rule__Import__Group__1"
    // InternalSM2.g:2601:1: rule__Import__Group__1 : rule__Import__Group__1__Impl rule__Import__Group__2 ;
    public final void rule__Import__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2605:1: ( rule__Import__Group__1__Impl rule__Import__Group__2 )
            // InternalSM2.g:2606:2: rule__Import__Group__1__Impl rule__Import__Group__2
            {
            pushFollow(FOLLOW_20);
            rule__Import__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1"


    // $ANTLR start "rule__Import__Group__1__Impl"
    // InternalSM2.g:2613:1: rule__Import__Group__1__Impl : ( ( rule__Import__NameLibraryAssignment_1 ) ) ;
    public final void rule__Import__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2617:1: ( ( ( rule__Import__NameLibraryAssignment_1 ) ) )
            // InternalSM2.g:2618:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            {
            // InternalSM2.g:2618:1: ( ( rule__Import__NameLibraryAssignment_1 ) )
            // InternalSM2.g:2619:2: ( rule__Import__NameLibraryAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            }
            // InternalSM2.g:2620:2: ( rule__Import__NameLibraryAssignment_1 )
            // InternalSM2.g:2620:3: rule__Import__NameLibraryAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__NameLibraryAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getNameLibraryAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__1__Impl"


    // $ANTLR start "rule__Import__Group__2"
    // InternalSM2.g:2628:1: rule__Import__Group__2 : rule__Import__Group__2__Impl rule__Import__Group__3 ;
    public final void rule__Import__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2632:1: ( rule__Import__Group__2__Impl rule__Import__Group__3 )
            // InternalSM2.g:2633:2: rule__Import__Group__2__Impl rule__Import__Group__3
            {
            pushFollow(FOLLOW_20);
            rule__Import__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2"


    // $ANTLR start "rule__Import__Group__2__Impl"
    // InternalSM2.g:2640:1: rule__Import__Group__2__Impl : ( ( rule__Import__Group_2__0 )? ) ;
    public final void rule__Import__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2644:1: ( ( ( rule__Import__Group_2__0 )? ) )
            // InternalSM2.g:2645:1: ( ( rule__Import__Group_2__0 )? )
            {
            // InternalSM2.g:2645:1: ( ( rule__Import__Group_2__0 )? )
            // InternalSM2.g:2646:2: ( rule__Import__Group_2__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getGroup_2()); 
            }
            // InternalSM2.g:2647:2: ( rule__Import__Group_2__0 )?
            int alt36=2;
            int LA36_0 = input.LA(1);

            if ( (LA36_0==65) ) {
                alt36=1;
            }
            switch (alt36) {
                case 1 :
                    // InternalSM2.g:2647:3: rule__Import__Group_2__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Import__Group_2__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getGroup_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__2__Impl"


    // $ANTLR start "rule__Import__Group__3"
    // InternalSM2.g:2655:1: rule__Import__Group__3 : rule__Import__Group__3__Impl rule__Import__Group__4 ;
    public final void rule__Import__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2659:1: ( rule__Import__Group__3__Impl rule__Import__Group__4 )
            // InternalSM2.g:2660:2: rule__Import__Group__3__Impl rule__Import__Group__4
            {
            pushFollow(FOLLOW_21);
            rule__Import__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3"


    // $ANTLR start "rule__Import__Group__3__Impl"
    // InternalSM2.g:2667:1: rule__Import__Group__3__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Import__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2671:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:2672:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:2672:1: ( RULE_SEMICOLON )
            // InternalSM2.g:2673:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getSEMICOLONTerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__3__Impl"


    // $ANTLR start "rule__Import__Group__4"
    // InternalSM2.g:2682:1: rule__Import__Group__4 : rule__Import__Group__4__Impl ;
    public final void rule__Import__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2686:1: ( rule__Import__Group__4__Impl )
            // InternalSM2.g:2687:2: rule__Import__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4"


    // $ANTLR start "rule__Import__Group__4__Impl"
    // InternalSM2.g:2693:1: rule__Import__Group__4__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Import__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2697:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:2698:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:2698:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:2699:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            }
            // InternalSM2.g:2700:2: ( RULE_EOLINE )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==RULE_EOLINE) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalSM2.g:2700:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getEOLINETerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group__4__Impl"


    // $ANTLR start "rule__Import__Group_2__0"
    // InternalSM2.g:2709:1: rule__Import__Group_2__0 : rule__Import__Group_2__0__Impl rule__Import__Group_2__1 ;
    public final void rule__Import__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2713:1: ( rule__Import__Group_2__0__Impl rule__Import__Group_2__1 )
            // InternalSM2.g:2714:2: rule__Import__Group_2__0__Impl rule__Import__Group_2__1
            {
            pushFollow(FOLLOW_9);
            rule__Import__Group_2__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0"


    // $ANTLR start "rule__Import__Group_2__0__Impl"
    // InternalSM2.g:2721:1: rule__Import__Group_2__0__Impl : ( 'as' ) ;
    public final void rule__Import__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2725:1: ( ( 'as' ) )
            // InternalSM2.g:2726:1: ( 'as' )
            {
            // InternalSM2.g:2726:1: ( 'as' )
            // InternalSM2.g:2727:2: 'as'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            }
            match(input,65,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAsKeyword_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__0__Impl"


    // $ANTLR start "rule__Import__Group_2__1"
    // InternalSM2.g:2736:1: rule__Import__Group_2__1 : rule__Import__Group_2__1__Impl ;
    public final void rule__Import__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2740:1: ( rule__Import__Group_2__1__Impl )
            // InternalSM2.g:2741:2: rule__Import__Group_2__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Import__Group_2__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1"


    // $ANTLR start "rule__Import__Group_2__1__Impl"
    // InternalSM2.g:2747:1: rule__Import__Group_2__1__Impl : ( ( rule__Import__AliasAssignment_2_1 ) ) ;
    public final void rule__Import__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2751:1: ( ( ( rule__Import__AliasAssignment_2_1 ) ) )
            // InternalSM2.g:2752:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            {
            // InternalSM2.g:2752:1: ( ( rule__Import__AliasAssignment_2_1 ) )
            // InternalSM2.g:2753:2: ( rule__Import__AliasAssignment_2_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            }
            // InternalSM2.g:2754:2: ( rule__Import__AliasAssignment_2_1 )
            // InternalSM2.g:2754:3: rule__Import__AliasAssignment_2_1
            {
            pushFollow(FOLLOW_2);
            rule__Import__AliasAssignment_2_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAliasAssignment_2_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__Group_2__1__Impl"


    // $ANTLR start "rule__Interface__Group__0"
    // InternalSM2.g:2763:1: rule__Interface__Group__0 : rule__Interface__Group__0__Impl rule__Interface__Group__1 ;
    public final void rule__Interface__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2767:1: ( rule__Interface__Group__0__Impl rule__Interface__Group__1 )
            // InternalSM2.g:2768:2: rule__Interface__Group__0__Impl rule__Interface__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Interface__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__0"


    // $ANTLR start "rule__Interface__Group__0__Impl"
    // InternalSM2.g:2775:1: rule__Interface__Group__0__Impl : ( 'inteface' ) ;
    public final void rule__Interface__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2779:1: ( ( 'inteface' ) )
            // InternalSM2.g:2780:1: ( 'inteface' )
            {
            // InternalSM2.g:2780:1: ( 'inteface' )
            // InternalSM2.g:2781:2: 'inteface'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getIntefaceKeyword_0()); 
            }
            match(input,66,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getIntefaceKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__0__Impl"


    // $ANTLR start "rule__Interface__Group__1"
    // InternalSM2.g:2790:1: rule__Interface__Group__1 : rule__Interface__Group__1__Impl rule__Interface__Group__2 ;
    public final void rule__Interface__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2794:1: ( rule__Interface__Group__1__Impl rule__Interface__Group__2 )
            // InternalSM2.g:2795:2: rule__Interface__Group__1__Impl rule__Interface__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__Interface__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__1"


    // $ANTLR start "rule__Interface__Group__1__Impl"
    // InternalSM2.g:2802:1: rule__Interface__Group__1__Impl : ( ( rule__Interface__NameInterfaceAssignment_1 ) ) ;
    public final void rule__Interface__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2806:1: ( ( ( rule__Interface__NameInterfaceAssignment_1 ) ) )
            // InternalSM2.g:2807:1: ( ( rule__Interface__NameInterfaceAssignment_1 ) )
            {
            // InternalSM2.g:2807:1: ( ( rule__Interface__NameInterfaceAssignment_1 ) )
            // InternalSM2.g:2808:2: ( rule__Interface__NameInterfaceAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getNameInterfaceAssignment_1()); 
            }
            // InternalSM2.g:2809:2: ( rule__Interface__NameInterfaceAssignment_1 )
            // InternalSM2.g:2809:3: rule__Interface__NameInterfaceAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Interface__NameInterfaceAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getNameInterfaceAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__1__Impl"


    // $ANTLR start "rule__Interface__Group__2"
    // InternalSM2.g:2817:1: rule__Interface__Group__2 : rule__Interface__Group__2__Impl rule__Interface__Group__3 ;
    public final void rule__Interface__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2821:1: ( rule__Interface__Group__2__Impl rule__Interface__Group__3 )
            // InternalSM2.g:2822:2: rule__Interface__Group__2__Impl rule__Interface__Group__3
            {
            pushFollow(FOLLOW_21);
            rule__Interface__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__2"


    // $ANTLR start "rule__Interface__Group__2__Impl"
    // InternalSM2.g:2829:1: rule__Interface__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Interface__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2833:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:2834:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:2834:1: ( RULE_OPENKEY )
            // InternalSM2.g:2835:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__2__Impl"


    // $ANTLR start "rule__Interface__Group__3"
    // InternalSM2.g:2844:1: rule__Interface__Group__3 : rule__Interface__Group__3__Impl rule__Interface__Group__4 ;
    public final void rule__Interface__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2848:1: ( rule__Interface__Group__3__Impl rule__Interface__Group__4 )
            // InternalSM2.g:2849:2: rule__Interface__Group__3__Impl rule__Interface__Group__4
            {
            pushFollow(FOLLOW_23);
            rule__Interface__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__3"


    // $ANTLR start "rule__Interface__Group__3__Impl"
    // InternalSM2.g:2856:1: rule__Interface__Group__3__Impl : ( RULE_EOLINE ) ;
    public final void rule__Interface__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2860:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:2861:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:2861:1: ( RULE_EOLINE )
            // InternalSM2.g:2862:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__3__Impl"


    // $ANTLR start "rule__Interface__Group__4"
    // InternalSM2.g:2871:1: rule__Interface__Group__4 : rule__Interface__Group__4__Impl rule__Interface__Group__5 ;
    public final void rule__Interface__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2875:1: ( rule__Interface__Group__4__Impl rule__Interface__Group__5 )
            // InternalSM2.g:2876:2: rule__Interface__Group__4__Impl rule__Interface__Group__5
            {
            pushFollow(FOLLOW_23);
            rule__Interface__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__4"


    // $ANTLR start "rule__Interface__Group__4__Impl"
    // InternalSM2.g:2883:1: rule__Interface__Group__4__Impl : ( ( rule__Interface__EnumsAssignment_4 )* ) ;
    public final void rule__Interface__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2887:1: ( ( ( rule__Interface__EnumsAssignment_4 )* ) )
            // InternalSM2.g:2888:1: ( ( rule__Interface__EnumsAssignment_4 )* )
            {
            // InternalSM2.g:2888:1: ( ( rule__Interface__EnumsAssignment_4 )* )
            // InternalSM2.g:2889:2: ( rule__Interface__EnumsAssignment_4 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEnumsAssignment_4()); 
            }
            // InternalSM2.g:2890:2: ( rule__Interface__EnumsAssignment_4 )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==76) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // InternalSM2.g:2890:3: rule__Interface__EnumsAssignment_4
            	    {
            	    pushFollow(FOLLOW_24);
            	    rule__Interface__EnumsAssignment_4();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEnumsAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__4__Impl"


    // $ANTLR start "rule__Interface__Group__5"
    // InternalSM2.g:2898:1: rule__Interface__Group__5 : rule__Interface__Group__5__Impl rule__Interface__Group__6 ;
    public final void rule__Interface__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2902:1: ( rule__Interface__Group__5__Impl rule__Interface__Group__6 )
            // InternalSM2.g:2903:2: rule__Interface__Group__5__Impl rule__Interface__Group__6
            {
            pushFollow(FOLLOW_25);
            rule__Interface__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__5"


    // $ANTLR start "rule__Interface__Group__5__Impl"
    // InternalSM2.g:2910:1: rule__Interface__Group__5__Impl : ( RULE_EOLINE ) ;
    public final void rule__Interface__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2914:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:2915:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:2915:1: ( RULE_EOLINE )
            // InternalSM2.g:2916:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_5()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__5__Impl"


    // $ANTLR start "rule__Interface__Group__6"
    // InternalSM2.g:2925:1: rule__Interface__Group__6 : rule__Interface__Group__6__Impl rule__Interface__Group__7 ;
    public final void rule__Interface__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2929:1: ( rule__Interface__Group__6__Impl rule__Interface__Group__7 )
            // InternalSM2.g:2930:2: rule__Interface__Group__6__Impl rule__Interface__Group__7
            {
            pushFollow(FOLLOW_25);
            rule__Interface__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__6"


    // $ANTLR start "rule__Interface__Group__6__Impl"
    // InternalSM2.g:2937:1: rule__Interface__Group__6__Impl : ( ( rule__Interface__StructsAssignment_6 )* ) ;
    public final void rule__Interface__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2941:1: ( ( ( rule__Interface__StructsAssignment_6 )* ) )
            // InternalSM2.g:2942:1: ( ( rule__Interface__StructsAssignment_6 )* )
            {
            // InternalSM2.g:2942:1: ( ( rule__Interface__StructsAssignment_6 )* )
            // InternalSM2.g:2943:2: ( rule__Interface__StructsAssignment_6 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getStructsAssignment_6()); 
            }
            // InternalSM2.g:2944:2: ( rule__Interface__StructsAssignment_6 )*
            loop39:
            do {
                int alt39=2;
                int LA39_0 = input.LA(1);

                if ( (LA39_0==74) ) {
                    alt39=1;
                }


                switch (alt39) {
            	case 1 :
            	    // InternalSM2.g:2944:3: rule__Interface__StructsAssignment_6
            	    {
            	    pushFollow(FOLLOW_26);
            	    rule__Interface__StructsAssignment_6();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop39;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getStructsAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__6__Impl"


    // $ANTLR start "rule__Interface__Group__7"
    // InternalSM2.g:2952:1: rule__Interface__Group__7 : rule__Interface__Group__7__Impl rule__Interface__Group__8 ;
    public final void rule__Interface__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2956:1: ( rule__Interface__Group__7__Impl rule__Interface__Group__8 )
            // InternalSM2.g:2957:2: rule__Interface__Group__7__Impl rule__Interface__Group__8
            {
            pushFollow(FOLLOW_27);
            rule__Interface__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__7"


    // $ANTLR start "rule__Interface__Group__7__Impl"
    // InternalSM2.g:2964:1: rule__Interface__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Interface__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2968:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:2969:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:2969:1: ( RULE_EOLINE )
            // InternalSM2.g:2970:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__7__Impl"


    // $ANTLR start "rule__Interface__Group__8"
    // InternalSM2.g:2979:1: rule__Interface__Group__8 : rule__Interface__Group__8__Impl rule__Interface__Group__9 ;
    public final void rule__Interface__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2983:1: ( rule__Interface__Group__8__Impl rule__Interface__Group__9 )
            // InternalSM2.g:2984:2: rule__Interface__Group__8__Impl rule__Interface__Group__9
            {
            pushFollow(FOLLOW_27);
            rule__Interface__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__8"


    // $ANTLR start "rule__Interface__Group__8__Impl"
    // InternalSM2.g:2991:1: rule__Interface__Group__8__Impl : ( ( rule__Interface__ClausesAssignment_8 )* ) ;
    public final void rule__Interface__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:2995:1: ( ( ( rule__Interface__ClausesAssignment_8 )* ) )
            // InternalSM2.g:2996:1: ( ( rule__Interface__ClausesAssignment_8 )* )
            {
            // InternalSM2.g:2996:1: ( ( rule__Interface__ClausesAssignment_8 )* )
            // InternalSM2.g:2997:2: ( rule__Interface__ClausesAssignment_8 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getClausesAssignment_8()); 
            }
            // InternalSM2.g:2998:2: ( rule__Interface__ClausesAssignment_8 )*
            loop40:
            do {
                int alt40=2;
                int LA40_0 = input.LA(1);

                if ( (LA40_0==78) ) {
                    alt40=1;
                }


                switch (alt40) {
            	case 1 :
            	    // InternalSM2.g:2998:3: rule__Interface__ClausesAssignment_8
            	    {
            	    pushFollow(FOLLOW_15);
            	    rule__Interface__ClausesAssignment_8();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop40;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getClausesAssignment_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__8__Impl"


    // $ANTLR start "rule__Interface__Group__9"
    // InternalSM2.g:3006:1: rule__Interface__Group__9 : rule__Interface__Group__9__Impl rule__Interface__Group__10 ;
    public final void rule__Interface__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3010:1: ( rule__Interface__Group__9__Impl rule__Interface__Group__10 )
            // InternalSM2.g:3011:2: rule__Interface__Group__9__Impl rule__Interface__Group__10
            {
            pushFollow(FOLLOW_21);
            rule__Interface__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__9"


    // $ANTLR start "rule__Interface__Group__9__Impl"
    // InternalSM2.g:3018:1: rule__Interface__Group__9__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Interface__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3022:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3023:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3023:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3024:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_9()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getSEMICOLONTerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__9__Impl"


    // $ANTLR start "rule__Interface__Group__10"
    // InternalSM2.g:3033:1: rule__Interface__Group__10 : rule__Interface__Group__10__Impl rule__Interface__Group__11 ;
    public final void rule__Interface__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3037:1: ( rule__Interface__Group__10__Impl rule__Interface__Group__11 )
            // InternalSM2.g:3038:2: rule__Interface__Group__10__Impl rule__Interface__Group__11
            {
            pushFollow(FOLLOW_28);
            rule__Interface__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__10"


    // $ANTLR start "rule__Interface__Group__10__Impl"
    // InternalSM2.g:3045:1: rule__Interface__Group__10__Impl : ( RULE_EOLINE ) ;
    public final void rule__Interface__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3049:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3050:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3050:1: ( RULE_EOLINE )
            // InternalSM2.g:3051:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_10()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__10__Impl"


    // $ANTLR start "rule__Interface__Group__11"
    // InternalSM2.g:3060:1: rule__Interface__Group__11 : rule__Interface__Group__11__Impl rule__Interface__Group__12 ;
    public final void rule__Interface__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3064:1: ( rule__Interface__Group__11__Impl rule__Interface__Group__12 )
            // InternalSM2.g:3065:2: rule__Interface__Group__11__Impl rule__Interface__Group__12
            {
            pushFollow(FOLLOW_21);
            rule__Interface__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Interface__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__11"


    // $ANTLR start "rule__Interface__Group__11__Impl"
    // InternalSM2.g:3072:1: rule__Interface__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Interface__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3076:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3077:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3077:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3078:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__11__Impl"


    // $ANTLR start "rule__Interface__Group__12"
    // InternalSM2.g:3087:1: rule__Interface__Group__12 : rule__Interface__Group__12__Impl ;
    public final void rule__Interface__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3091:1: ( rule__Interface__Group__12__Impl )
            // InternalSM2.g:3092:2: rule__Interface__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Interface__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__12"


    // $ANTLR start "rule__Interface__Group__12__Impl"
    // InternalSM2.g:3098:1: rule__Interface__Group__12__Impl : ( RULE_EOLINE ) ;
    public final void rule__Interface__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3102:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:3103:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:3103:1: ( RULE_EOLINE )
            // InternalSM2.g:3104:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_12()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEOLINETerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__Group__12__Impl"


    // $ANTLR start "rule__Constructor__Group__0"
    // InternalSM2.g:3114:1: rule__Constructor__Group__0 : rule__Constructor__Group__0__Impl rule__Constructor__Group__1 ;
    public final void rule__Constructor__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3118:1: ( rule__Constructor__Group__0__Impl rule__Constructor__Group__1 )
            // InternalSM2.g:3119:2: rule__Constructor__Group__0__Impl rule__Constructor__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__Constructor__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__0"


    // $ANTLR start "rule__Constructor__Group__0__Impl"
    // InternalSM2.g:3126:1: rule__Constructor__Group__0__Impl : ( 'constructor' ) ;
    public final void rule__Constructor__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3130:1: ( ( 'constructor' ) )
            // InternalSM2.g:3131:1: ( 'constructor' )
            {
            // InternalSM2.g:3131:1: ( 'constructor' )
            // InternalSM2.g:3132:2: 'constructor'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getConstructorKeyword_0()); 
            }
            match(input,67,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getConstructorKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__0__Impl"


    // $ANTLR start "rule__Constructor__Group__1"
    // InternalSM2.g:3141:1: rule__Constructor__Group__1 : rule__Constructor__Group__1__Impl rule__Constructor__Group__2 ;
    public final void rule__Constructor__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3145:1: ( rule__Constructor__Group__1__Impl rule__Constructor__Group__2 )
            // InternalSM2.g:3146:2: rule__Constructor__Group__1__Impl rule__Constructor__Group__2
            {
            pushFollow(FOLLOW_9);
            rule__Constructor__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__1"


    // $ANTLR start "rule__Constructor__Group__1__Impl"
    // InternalSM2.g:3153:1: rule__Constructor__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Constructor__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3157:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3158:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3158:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3159:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__1__Impl"


    // $ANTLR start "rule__Constructor__Group__2"
    // InternalSM2.g:3168:1: rule__Constructor__Group__2 : rule__Constructor__Group__2__Impl rule__Constructor__Group__3 ;
    public final void rule__Constructor__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3172:1: ( rule__Constructor__Group__2__Impl rule__Constructor__Group__3 )
            // InternalSM2.g:3173:2: rule__Constructor__Group__2__Impl rule__Constructor__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__Constructor__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__2"


    // $ANTLR start "rule__Constructor__Group__2__Impl"
    // InternalSM2.g:3180:1: rule__Constructor__Group__2__Impl : ( ( rule__Constructor__InputParamsAssignment_2 ) ) ;
    public final void rule__Constructor__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3184:1: ( ( ( rule__Constructor__InputParamsAssignment_2 ) ) )
            // InternalSM2.g:3185:1: ( ( rule__Constructor__InputParamsAssignment_2 ) )
            {
            // InternalSM2.g:3185:1: ( ( rule__Constructor__InputParamsAssignment_2 ) )
            // InternalSM2.g:3186:2: ( rule__Constructor__InputParamsAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getInputParamsAssignment_2()); 
            }
            // InternalSM2.g:3187:2: ( rule__Constructor__InputParamsAssignment_2 )
            // InternalSM2.g:3187:3: rule__Constructor__InputParamsAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__InputParamsAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getInputParamsAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__2__Impl"


    // $ANTLR start "rule__Constructor__Group__3"
    // InternalSM2.g:3195:1: rule__Constructor__Group__3 : rule__Constructor__Group__3__Impl rule__Constructor__Group__4 ;
    public final void rule__Constructor__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3199:1: ( rule__Constructor__Group__3__Impl rule__Constructor__Group__4 )
            // InternalSM2.g:3200:2: rule__Constructor__Group__3__Impl rule__Constructor__Group__4
            {
            pushFollow(FOLLOW_31);
            rule__Constructor__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__3"


    // $ANTLR start "rule__Constructor__Group__3__Impl"
    // InternalSM2.g:3207:1: rule__Constructor__Group__3__Impl : ( ( rule__Constructor__TypeAssignment_3 ) ) ;
    public final void rule__Constructor__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3211:1: ( ( ( rule__Constructor__TypeAssignment_3 ) ) )
            // InternalSM2.g:3212:1: ( ( rule__Constructor__TypeAssignment_3 ) )
            {
            // InternalSM2.g:3212:1: ( ( rule__Constructor__TypeAssignment_3 ) )
            // InternalSM2.g:3213:2: ( rule__Constructor__TypeAssignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getTypeAssignment_3()); 
            }
            // InternalSM2.g:3214:2: ( rule__Constructor__TypeAssignment_3 )
            // InternalSM2.g:3214:3: rule__Constructor__TypeAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__TypeAssignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getTypeAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__3__Impl"


    // $ANTLR start "rule__Constructor__Group__4"
    // InternalSM2.g:3222:1: rule__Constructor__Group__4 : rule__Constructor__Group__4__Impl rule__Constructor__Group__5 ;
    public final void rule__Constructor__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3226:1: ( rule__Constructor__Group__4__Impl rule__Constructor__Group__5 )
            // InternalSM2.g:3227:2: rule__Constructor__Group__4__Impl rule__Constructor__Group__5
            {
            pushFollow(FOLLOW_22);
            rule__Constructor__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__4"


    // $ANTLR start "rule__Constructor__Group__4__Impl"
    // InternalSM2.g:3234:1: rule__Constructor__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Constructor__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3238:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3239:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3239:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3240:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__4__Impl"


    // $ANTLR start "rule__Constructor__Group__5"
    // InternalSM2.g:3249:1: rule__Constructor__Group__5 : rule__Constructor__Group__5__Impl rule__Constructor__Group__6 ;
    public final void rule__Constructor__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3253:1: ( rule__Constructor__Group__5__Impl rule__Constructor__Group__6 )
            // InternalSM2.g:3254:2: rule__Constructor__Group__5__Impl rule__Constructor__Group__6
            {
            pushFollow(FOLLOW_32);
            rule__Constructor__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__5"


    // $ANTLR start "rule__Constructor__Group__5__Impl"
    // InternalSM2.g:3261:1: rule__Constructor__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Constructor__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3265:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3266:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3266:1: ( RULE_OPENKEY )
            // InternalSM2.g:3267:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getOPENKEYTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__5__Impl"


    // $ANTLR start "rule__Constructor__Group__6"
    // InternalSM2.g:3276:1: rule__Constructor__Group__6 : rule__Constructor__Group__6__Impl rule__Constructor__Group__7 ;
    public final void rule__Constructor__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3280:1: ( rule__Constructor__Group__6__Impl rule__Constructor__Group__7 )
            // InternalSM2.g:3281:2: rule__Constructor__Group__6__Impl rule__Constructor__Group__7
            {
            pushFollow(FOLLOW_32);
            rule__Constructor__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__6"


    // $ANTLR start "rule__Constructor__Group__6__Impl"
    // InternalSM2.g:3288:1: rule__Constructor__Group__6__Impl : ( ( rule__Constructor__AttributesAssignment_6 )* ) ;
    public final void rule__Constructor__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3292:1: ( ( ( rule__Constructor__AttributesAssignment_6 )* ) )
            // InternalSM2.g:3293:1: ( ( rule__Constructor__AttributesAssignment_6 )* )
            {
            // InternalSM2.g:3293:1: ( ( rule__Constructor__AttributesAssignment_6 )* )
            // InternalSM2.g:3294:2: ( rule__Constructor__AttributesAssignment_6 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getAttributesAssignment_6()); 
            }
            // InternalSM2.g:3295:2: ( rule__Constructor__AttributesAssignment_6 )*
            loop41:
            do {
                int alt41=2;
                int LA41_0 = input.LA(1);

                if ( (LA41_0==RULE_ID) ) {
                    alt41=1;
                }


                switch (alt41) {
            	case 1 :
            	    // InternalSM2.g:3295:3: rule__Constructor__AttributesAssignment_6
            	    {
            	    pushFollow(FOLLOW_33);
            	    rule__Constructor__AttributesAssignment_6();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop41;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getAttributesAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__6__Impl"


    // $ANTLR start "rule__Constructor__Group__7"
    // InternalSM2.g:3303:1: rule__Constructor__Group__7 : rule__Constructor__Group__7__Impl rule__Constructor__Group__8 ;
    public final void rule__Constructor__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3307:1: ( rule__Constructor__Group__7__Impl rule__Constructor__Group__8 )
            // InternalSM2.g:3308:2: rule__Constructor__Group__7__Impl rule__Constructor__Group__8
            {
            pushFollow(FOLLOW_34);
            rule__Constructor__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__7"


    // $ANTLR start "rule__Constructor__Group__7__Impl"
    // InternalSM2.g:3315:1: rule__Constructor__Group__7__Impl : ( '=' ) ;
    public final void rule__Constructor__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3319:1: ( ( '=' ) )
            // InternalSM2.g:3320:1: ( '=' )
            {
            // InternalSM2.g:3320:1: ( '=' )
            // InternalSM2.g:3321:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getEqualsSignKeyword_7()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getEqualsSignKeyword_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__7__Impl"


    // $ANTLR start "rule__Constructor__Group__8"
    // InternalSM2.g:3330:1: rule__Constructor__Group__8 : rule__Constructor__Group__8__Impl rule__Constructor__Group__9 ;
    public final void rule__Constructor__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3334:1: ( rule__Constructor__Group__8__Impl rule__Constructor__Group__9 )
            // InternalSM2.g:3335:2: rule__Constructor__Group__8__Impl rule__Constructor__Group__9
            {
            pushFollow(FOLLOW_28);
            rule__Constructor__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__8"


    // $ANTLR start "rule__Constructor__Group__8__Impl"
    // InternalSM2.g:3342:1: rule__Constructor__Group__8__Impl : ( ( rule__Constructor__ValueAssignment_8 ) ) ;
    public final void rule__Constructor__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3346:1: ( ( ( rule__Constructor__ValueAssignment_8 ) ) )
            // InternalSM2.g:3347:1: ( ( rule__Constructor__ValueAssignment_8 ) )
            {
            // InternalSM2.g:3347:1: ( ( rule__Constructor__ValueAssignment_8 ) )
            // InternalSM2.g:3348:2: ( rule__Constructor__ValueAssignment_8 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getValueAssignment_8()); 
            }
            // InternalSM2.g:3349:2: ( rule__Constructor__ValueAssignment_8 )
            // InternalSM2.g:3349:3: rule__Constructor__ValueAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__ValueAssignment_8();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getValueAssignment_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__8__Impl"


    // $ANTLR start "rule__Constructor__Group__9"
    // InternalSM2.g:3357:1: rule__Constructor__Group__9 : rule__Constructor__Group__9__Impl ;
    public final void rule__Constructor__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3361:1: ( rule__Constructor__Group__9__Impl )
            // InternalSM2.g:3362:2: rule__Constructor__Group__9__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__9"


    // $ANTLR start "rule__Constructor__Group__9__Impl"
    // InternalSM2.g:3368:1: rule__Constructor__Group__9__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Constructor__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3372:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3373:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3373:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3374:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_9()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getCLOSEKEYTerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__Group__9__Impl"


    // $ANTLR start "rule__Event__Group__0"
    // InternalSM2.g:3384:1: rule__Event__Group__0 : rule__Event__Group__0__Impl rule__Event__Group__1 ;
    public final void rule__Event__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3388:1: ( rule__Event__Group__0__Impl rule__Event__Group__1 )
            // InternalSM2.g:3389:2: rule__Event__Group__0__Impl rule__Event__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Event__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0"


    // $ANTLR start "rule__Event__Group__0__Impl"
    // InternalSM2.g:3396:1: rule__Event__Group__0__Impl : ( 'event' ) ;
    public final void rule__Event__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3400:1: ( ( 'event' ) )
            // InternalSM2.g:3401:1: ( 'event' )
            {
            // InternalSM2.g:3401:1: ( 'event' )
            // InternalSM2.g:3402:2: 'event'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getEventKeyword_0()); 
            }
            match(input,69,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getEventKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__0__Impl"


    // $ANTLR start "rule__Event__Group__1"
    // InternalSM2.g:3411:1: rule__Event__Group__1 : rule__Event__Group__1__Impl rule__Event__Group__2 ;
    public final void rule__Event__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3415:1: ( rule__Event__Group__1__Impl rule__Event__Group__2 )
            // InternalSM2.g:3416:2: rule__Event__Group__1__Impl rule__Event__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__Event__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1"


    // $ANTLR start "rule__Event__Group__1__Impl"
    // InternalSM2.g:3423:1: rule__Event__Group__1__Impl : ( ( rule__Event__NameEventAssignment_1 ) ) ;
    public final void rule__Event__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3427:1: ( ( ( rule__Event__NameEventAssignment_1 ) ) )
            // InternalSM2.g:3428:1: ( ( rule__Event__NameEventAssignment_1 ) )
            {
            // InternalSM2.g:3428:1: ( ( rule__Event__NameEventAssignment_1 ) )
            // InternalSM2.g:3429:2: ( rule__Event__NameEventAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            }
            // InternalSM2.g:3430:2: ( rule__Event__NameEventAssignment_1 )
            // InternalSM2.g:3430:3: rule__Event__NameEventAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Event__NameEventAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getNameEventAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__1__Impl"


    // $ANTLR start "rule__Event__Group__2"
    // InternalSM2.g:3438:1: rule__Event__Group__2 : rule__Event__Group__2__Impl rule__Event__Group__3 ;
    public final void rule__Event__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3442:1: ( rule__Event__Group__2__Impl rule__Event__Group__3 )
            // InternalSM2.g:3443:2: rule__Event__Group__2__Impl rule__Event__Group__3
            {
            pushFollow(FOLLOW_35);
            rule__Event__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2"


    // $ANTLR start "rule__Event__Group__2__Impl"
    // InternalSM2.g:3450:1: rule__Event__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Event__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3454:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3455:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3455:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3456:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__2__Impl"


    // $ANTLR start "rule__Event__Group__3"
    // InternalSM2.g:3465:1: rule__Event__Group__3 : rule__Event__Group__3__Impl rule__Event__Group__4 ;
    public final void rule__Event__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3469:1: ( rule__Event__Group__3__Impl rule__Event__Group__4 )
            // InternalSM2.g:3470:2: rule__Event__Group__3__Impl rule__Event__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__Event__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3"


    // $ANTLR start "rule__Event__Group__3__Impl"
    // InternalSM2.g:3477:1: rule__Event__Group__3__Impl : ( ( rule__Event__InputParamsAssignment_3 )* ) ;
    public final void rule__Event__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3481:1: ( ( ( rule__Event__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:3482:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:3482:1: ( ( rule__Event__InputParamsAssignment_3 )* )
            // InternalSM2.g:3483:2: ( rule__Event__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:3484:2: ( rule__Event__InputParamsAssignment_3 )*
            loop42:
            do {
                int alt42=2;
                int LA42_0 = input.LA(1);

                if ( ((LA42_0>=35 && LA42_0<=45)) ) {
                    alt42=1;
                }


                switch (alt42) {
            	case 1 :
            	    // InternalSM2.g:3484:3: rule__Event__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_36);
            	    rule__Event__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop42;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__3__Impl"


    // $ANTLR start "rule__Event__Group__4"
    // InternalSM2.g:3492:1: rule__Event__Group__4 : rule__Event__Group__4__Impl rule__Event__Group__5 ;
    public final void rule__Event__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3496:1: ( rule__Event__Group__4__Impl rule__Event__Group__5 )
            // InternalSM2.g:3497:2: rule__Event__Group__4__Impl rule__Event__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Event__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4"


    // $ANTLR start "rule__Event__Group__4__Impl"
    // InternalSM2.g:3504:1: rule__Event__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Event__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3508:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3509:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3509:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3510:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__4__Impl"


    // $ANTLR start "rule__Event__Group__5"
    // InternalSM2.g:3519:1: rule__Event__Group__5 : rule__Event__Group__5__Impl rule__Event__Group__6 ;
    public final void rule__Event__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3523:1: ( rule__Event__Group__5__Impl rule__Event__Group__6 )
            // InternalSM2.g:3524:2: rule__Event__Group__5__Impl rule__Event__Group__6
            {
            pushFollow(FOLLOW_21);
            rule__Event__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Event__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5"


    // $ANTLR start "rule__Event__Group__5__Impl"
    // InternalSM2.g:3531:1: rule__Event__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Event__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3535:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3536:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3536:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3537:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__5__Impl"


    // $ANTLR start "rule__Event__Group__6"
    // InternalSM2.g:3546:1: rule__Event__Group__6 : rule__Event__Group__6__Impl ;
    public final void rule__Event__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3550:1: ( rule__Event__Group__6__Impl )
            // InternalSM2.g:3551:2: rule__Event__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Event__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6"


    // $ANTLR start "rule__Event__Group__6__Impl"
    // InternalSM2.g:3557:1: rule__Event__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Event__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3561:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3562:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3562:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3563:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:3564:2: ( RULE_EOLINE )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_EOLINE) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalSM2.g:3564:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__0"
    // InternalSM2.g:3573:1: rule__Modifier__Group__0 : rule__Modifier__Group__0__Impl rule__Modifier__Group__1 ;
    public final void rule__Modifier__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3577:1: ( rule__Modifier__Group__0__Impl rule__Modifier__Group__1 )
            // InternalSM2.g:3578:2: rule__Modifier__Group__0__Impl rule__Modifier__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Modifier__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0"


    // $ANTLR start "rule__Modifier__Group__0__Impl"
    // InternalSM2.g:3585:1: rule__Modifier__Group__0__Impl : ( 'modifier' ) ;
    public final void rule__Modifier__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3589:1: ( ( 'modifier' ) )
            // InternalSM2.g:3590:1: ( 'modifier' )
            {
            // InternalSM2.g:3590:1: ( 'modifier' )
            // InternalSM2.g:3591:2: 'modifier'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            }
            match(input,70,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getModifierKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__0__Impl"


    // $ANTLR start "rule__Modifier__Group__1"
    // InternalSM2.g:3600:1: rule__Modifier__Group__1 : rule__Modifier__Group__1__Impl rule__Modifier__Group__2 ;
    public final void rule__Modifier__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3604:1: ( rule__Modifier__Group__1__Impl rule__Modifier__Group__2 )
            // InternalSM2.g:3605:2: rule__Modifier__Group__1__Impl rule__Modifier__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__Modifier__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1"


    // $ANTLR start "rule__Modifier__Group__1__Impl"
    // InternalSM2.g:3612:1: rule__Modifier__Group__1__Impl : ( ( rule__Modifier__NameModifierAssignment_1 ) ) ;
    public final void rule__Modifier__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3616:1: ( ( ( rule__Modifier__NameModifierAssignment_1 ) ) )
            // InternalSM2.g:3617:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            {
            // InternalSM2.g:3617:1: ( ( rule__Modifier__NameModifierAssignment_1 ) )
            // InternalSM2.g:3618:2: ( rule__Modifier__NameModifierAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            }
            // InternalSM2.g:3619:2: ( rule__Modifier__NameModifierAssignment_1 )
            // InternalSM2.g:3619:3: rule__Modifier__NameModifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__NameModifierAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getNameModifierAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__1__Impl"


    // $ANTLR start "rule__Modifier__Group__2"
    // InternalSM2.g:3627:1: rule__Modifier__Group__2 : rule__Modifier__Group__2__Impl rule__Modifier__Group__3 ;
    public final void rule__Modifier__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3631:1: ( rule__Modifier__Group__2__Impl rule__Modifier__Group__3 )
            // InternalSM2.g:3632:2: rule__Modifier__Group__2__Impl rule__Modifier__Group__3
            {
            pushFollow(FOLLOW_35);
            rule__Modifier__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2"


    // $ANTLR start "rule__Modifier__Group__2__Impl"
    // InternalSM2.g:3639:1: rule__Modifier__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Modifier__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3643:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3644:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3644:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3645:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__2__Impl"


    // $ANTLR start "rule__Modifier__Group__3"
    // InternalSM2.g:3654:1: rule__Modifier__Group__3 : rule__Modifier__Group__3__Impl rule__Modifier__Group__4 ;
    public final void rule__Modifier__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3658:1: ( rule__Modifier__Group__3__Impl rule__Modifier__Group__4 )
            // InternalSM2.g:3659:2: rule__Modifier__Group__3__Impl rule__Modifier__Group__4
            {
            pushFollow(FOLLOW_35);
            rule__Modifier__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3"


    // $ANTLR start "rule__Modifier__Group__3__Impl"
    // InternalSM2.g:3666:1: rule__Modifier__Group__3__Impl : ( ( rule__Modifier__InputParamsAssignment_3 )* ) ;
    public final void rule__Modifier__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3670:1: ( ( ( rule__Modifier__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:3671:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:3671:1: ( ( rule__Modifier__InputParamsAssignment_3 )* )
            // InternalSM2.g:3672:2: ( rule__Modifier__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:3673:2: ( rule__Modifier__InputParamsAssignment_3 )*
            loop44:
            do {
                int alt44=2;
                int LA44_0 = input.LA(1);

                if ( ((LA44_0>=35 && LA44_0<=45)) ) {
                    alt44=1;
                }


                switch (alt44) {
            	case 1 :
            	    // InternalSM2.g:3673:3: rule__Modifier__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_36);
            	    rule__Modifier__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop44;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__3__Impl"


    // $ANTLR start "rule__Modifier__Group__4"
    // InternalSM2.g:3681:1: rule__Modifier__Group__4 : rule__Modifier__Group__4__Impl rule__Modifier__Group__5 ;
    public final void rule__Modifier__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3685:1: ( rule__Modifier__Group__4__Impl rule__Modifier__Group__5 )
            // InternalSM2.g:3686:2: rule__Modifier__Group__4__Impl rule__Modifier__Group__5
            {
            pushFollow(FOLLOW_22);
            rule__Modifier__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4"


    // $ANTLR start "rule__Modifier__Group__4__Impl"
    // InternalSM2.g:3693:1: rule__Modifier__Group__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Modifier__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3697:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:3698:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:3698:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:3699:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getCLOSEPARENTHESISTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__4__Impl"


    // $ANTLR start "rule__Modifier__Group__5"
    // InternalSM2.g:3708:1: rule__Modifier__Group__5 : rule__Modifier__Group__5__Impl rule__Modifier__Group__6 ;
    public final void rule__Modifier__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3712:1: ( rule__Modifier__Group__5__Impl rule__Modifier__Group__6 )
            // InternalSM2.g:3713:2: rule__Modifier__Group__5__Impl rule__Modifier__Group__6
            {
            pushFollow(FOLLOW_37);
            rule__Modifier__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5"


    // $ANTLR start "rule__Modifier__Group__5__Impl"
    // InternalSM2.g:3720:1: rule__Modifier__Group__5__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Modifier__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3724:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:3725:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:3725:1: ( RULE_OPENKEY )
            // InternalSM2.g:3726:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getOPENKEYTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__5__Impl"


    // $ANTLR start "rule__Modifier__Group__6"
    // InternalSM2.g:3735:1: rule__Modifier__Group__6 : rule__Modifier__Group__6__Impl rule__Modifier__Group__7 ;
    public final void rule__Modifier__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3739:1: ( rule__Modifier__Group__6__Impl rule__Modifier__Group__7 )
            // InternalSM2.g:3740:2: rule__Modifier__Group__6__Impl rule__Modifier__Group__7
            {
            pushFollow(FOLLOW_37);
            rule__Modifier__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6"


    // $ANTLR start "rule__Modifier__Group__6__Impl"
    // InternalSM2.g:3747:1: rule__Modifier__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3751:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3752:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3752:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3753:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:3754:2: ( RULE_EOLINE )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_EOLINE) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalSM2.g:3754:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__6__Impl"


    // $ANTLR start "rule__Modifier__Group__7"
    // InternalSM2.g:3762:1: rule__Modifier__Group__7 : rule__Modifier__Group__7__Impl rule__Modifier__Group__8 ;
    public final void rule__Modifier__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3766:1: ( rule__Modifier__Group__7__Impl rule__Modifier__Group__8 )
            // InternalSM2.g:3767:2: rule__Modifier__Group__7__Impl rule__Modifier__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Modifier__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7"


    // $ANTLR start "rule__Modifier__Group__7__Impl"
    // InternalSM2.g:3774:1: rule__Modifier__Group__7__Impl : ( ( rule__Modifier__ExprAssignment_7 ) ) ;
    public final void rule__Modifier__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3778:1: ( ( ( rule__Modifier__ExprAssignment_7 ) ) )
            // InternalSM2.g:3779:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            {
            // InternalSM2.g:3779:1: ( ( rule__Modifier__ExprAssignment_7 ) )
            // InternalSM2.g:3780:2: ( rule__Modifier__ExprAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            }
            // InternalSM2.g:3781:2: ( rule__Modifier__ExprAssignment_7 )
            // InternalSM2.g:3781:3: rule__Modifier__ExprAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__ExprAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getExprAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__7__Impl"


    // $ANTLR start "rule__Modifier__Group__8"
    // InternalSM2.g:3789:1: rule__Modifier__Group__8 : rule__Modifier__Group__8__Impl rule__Modifier__Group__9 ;
    public final void rule__Modifier__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3793:1: ( rule__Modifier__Group__8__Impl rule__Modifier__Group__9 )
            // InternalSM2.g:3794:2: rule__Modifier__Group__8__Impl rule__Modifier__Group__9
            {
            pushFollow(FOLLOW_38);
            rule__Modifier__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8"


    // $ANTLR start "rule__Modifier__Group__8__Impl"
    // InternalSM2.g:3801:1: rule__Modifier__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Modifier__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3805:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:3806:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:3806:1: ( RULE_SEMICOLON )
            // InternalSM2.g:3807:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getSEMICOLONTerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__8__Impl"


    // $ANTLR start "rule__Modifier__Group__9"
    // InternalSM2.g:3816:1: rule__Modifier__Group__9 : rule__Modifier__Group__9__Impl rule__Modifier__Group__10 ;
    public final void rule__Modifier__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3820:1: ( rule__Modifier__Group__9__Impl rule__Modifier__Group__10 )
            // InternalSM2.g:3821:2: rule__Modifier__Group__9__Impl rule__Modifier__Group__10
            {
            pushFollow(FOLLOW_38);
            rule__Modifier__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9"


    // $ANTLR start "rule__Modifier__Group__9__Impl"
    // InternalSM2.g:3828:1: rule__Modifier__Group__9__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3832:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3833:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3833:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3834:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            }
            // InternalSM2.g:3835:2: ( RULE_EOLINE )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==RULE_EOLINE) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalSM2.g:3835:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__9__Impl"


    // $ANTLR start "rule__Modifier__Group__10"
    // InternalSM2.g:3843:1: rule__Modifier__Group__10 : rule__Modifier__Group__10__Impl rule__Modifier__Group__11 ;
    public final void rule__Modifier__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3847:1: ( rule__Modifier__Group__10__Impl rule__Modifier__Group__11 )
            // InternalSM2.g:3848:2: rule__Modifier__Group__10__Impl rule__Modifier__Group__11
            {
            pushFollow(FOLLOW_28);
            rule__Modifier__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10"


    // $ANTLR start "rule__Modifier__Group__10__Impl"
    // InternalSM2.g:3855:1: rule__Modifier__Group__10__Impl : ( '_;' ) ;
    public final void rule__Modifier__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3859:1: ( ( '_;' ) )
            // InternalSM2.g:3860:1: ( '_;' )
            {
            // InternalSM2.g:3860:1: ( '_;' )
            // InternalSM2.g:3861:2: '_;'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().get_Keyword_10()); 
            }
            match(input,71,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().get_Keyword_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__10__Impl"


    // $ANTLR start "rule__Modifier__Group__11"
    // InternalSM2.g:3870:1: rule__Modifier__Group__11 : rule__Modifier__Group__11__Impl rule__Modifier__Group__12 ;
    public final void rule__Modifier__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3874:1: ( rule__Modifier__Group__11__Impl rule__Modifier__Group__12 )
            // InternalSM2.g:3875:2: rule__Modifier__Group__11__Impl rule__Modifier__Group__12
            {
            pushFollow(FOLLOW_21);
            rule__Modifier__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11"


    // $ANTLR start "rule__Modifier__Group__11__Impl"
    // InternalSM2.g:3882:1: rule__Modifier__Group__11__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Modifier__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3886:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:3887:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:3887:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:3888:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getCLOSEKEYTerminalRuleCall_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__11__Impl"


    // $ANTLR start "rule__Modifier__Group__12"
    // InternalSM2.g:3897:1: rule__Modifier__Group__12 : rule__Modifier__Group__12__Impl ;
    public final void rule__Modifier__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3901:1: ( rule__Modifier__Group__12__Impl )
            // InternalSM2.g:3902:2: rule__Modifier__Group__12__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Modifier__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12"


    // $ANTLR start "rule__Modifier__Group__12__Impl"
    // InternalSM2.g:3908:1: rule__Modifier__Group__12__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Modifier__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3912:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:3913:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:3913:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:3914:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            }
            // InternalSM2.g:3915:2: ( RULE_EOLINE )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_EOLINE) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalSM2.g:3915:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getEOLINETerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__Group__12__Impl"


    // $ANTLR start "rule__Mapping__Group__0"
    // InternalSM2.g:3924:1: rule__Mapping__Group__0 : rule__Mapping__Group__0__Impl rule__Mapping__Group__1 ;
    public final void rule__Mapping__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3928:1: ( rule__Mapping__Group__0__Impl rule__Mapping__Group__1 )
            // InternalSM2.g:3929:2: rule__Mapping__Group__0__Impl rule__Mapping__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__Mapping__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0"


    // $ANTLR start "rule__Mapping__Group__0__Impl"
    // InternalSM2.g:3936:1: rule__Mapping__Group__0__Impl : ( 'mapping' ) ;
    public final void rule__Mapping__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3940:1: ( ( 'mapping' ) )
            // InternalSM2.g:3941:1: ( 'mapping' )
            {
            // InternalSM2.g:3941:1: ( 'mapping' )
            // InternalSM2.g:3942:2: 'mapping'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            }
            match(input,72,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getMappingKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__0__Impl"


    // $ANTLR start "rule__Mapping__Group__1"
    // InternalSM2.g:3951:1: rule__Mapping__Group__1 : rule__Mapping__Group__1__Impl rule__Mapping__Group__2 ;
    public final void rule__Mapping__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3955:1: ( rule__Mapping__Group__1__Impl rule__Mapping__Group__2 )
            // InternalSM2.g:3956:2: rule__Mapping__Group__1__Impl rule__Mapping__Group__2
            {
            pushFollow(FOLLOW_39);
            rule__Mapping__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1"


    // $ANTLR start "rule__Mapping__Group__1__Impl"
    // InternalSM2.g:3963:1: rule__Mapping__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Mapping__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3967:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:3968:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:3968:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:3969:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__1__Impl"


    // $ANTLR start "rule__Mapping__Group__2"
    // InternalSM2.g:3978:1: rule__Mapping__Group__2 : rule__Mapping__Group__2__Impl rule__Mapping__Group__3 ;
    public final void rule__Mapping__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3982:1: ( rule__Mapping__Group__2__Impl rule__Mapping__Group__3 )
            // InternalSM2.g:3983:2: rule__Mapping__Group__2__Impl rule__Mapping__Group__3
            {
            pushFollow(FOLLOW_40);
            rule__Mapping__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2"


    // $ANTLR start "rule__Mapping__Group__2__Impl"
    // InternalSM2.g:3990:1: rule__Mapping__Group__2__Impl : ( ( rule__Mapping__TypeAssignment_2 ) ) ;
    public final void rule__Mapping__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:3994:1: ( ( ( rule__Mapping__TypeAssignment_2 ) ) )
            // InternalSM2.g:3995:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            {
            // InternalSM2.g:3995:1: ( ( rule__Mapping__TypeAssignment_2 ) )
            // InternalSM2.g:3996:2: ( rule__Mapping__TypeAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            }
            // InternalSM2.g:3997:2: ( rule__Mapping__TypeAssignment_2 )
            // InternalSM2.g:3997:3: rule__Mapping__TypeAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__TypeAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getTypeAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__2__Impl"


    // $ANTLR start "rule__Mapping__Group__3"
    // InternalSM2.g:4005:1: rule__Mapping__Group__3 : rule__Mapping__Group__3__Impl rule__Mapping__Group__4 ;
    public final void rule__Mapping__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4009:1: ( rule__Mapping__Group__3__Impl rule__Mapping__Group__4 )
            // InternalSM2.g:4010:2: rule__Mapping__Group__3__Impl rule__Mapping__Group__4
            {
            pushFollow(FOLLOW_41);
            rule__Mapping__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3"


    // $ANTLR start "rule__Mapping__Group__3__Impl"
    // InternalSM2.g:4017:1: rule__Mapping__Group__3__Impl : ( '=>' ) ;
    public final void rule__Mapping__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4021:1: ( ( '=>' ) )
            // InternalSM2.g:4022:1: ( '=>' )
            {
            // InternalSM2.g:4022:1: ( '=>' )
            // InternalSM2.g:4023:2: '=>'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            }
            match(input,73,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__3__Impl"


    // $ANTLR start "rule__Mapping__Group__4"
    // InternalSM2.g:4032:1: rule__Mapping__Group__4 : rule__Mapping__Group__4__Impl rule__Mapping__Group__5 ;
    public final void rule__Mapping__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4036:1: ( rule__Mapping__Group__4__Impl rule__Mapping__Group__5 )
            // InternalSM2.g:4037:2: rule__Mapping__Group__4__Impl rule__Mapping__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Mapping__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4"


    // $ANTLR start "rule__Mapping__Group__4__Impl"
    // InternalSM2.g:4044:1: rule__Mapping__Group__4__Impl : ( ( rule__Mapping__ExprAssignment_4 ) ) ;
    public final void rule__Mapping__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4048:1: ( ( ( rule__Mapping__ExprAssignment_4 ) ) )
            // InternalSM2.g:4049:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            {
            // InternalSM2.g:4049:1: ( ( rule__Mapping__ExprAssignment_4 ) )
            // InternalSM2.g:4050:2: ( rule__Mapping__ExprAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            }
            // InternalSM2.g:4051:2: ( rule__Mapping__ExprAssignment_4 )
            // InternalSM2.g:4051:3: rule__Mapping__ExprAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__ExprAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getExprAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__4__Impl"


    // $ANTLR start "rule__Mapping__Group__5"
    // InternalSM2.g:4059:1: rule__Mapping__Group__5 : rule__Mapping__Group__5__Impl rule__Mapping__Group__6 ;
    public final void rule__Mapping__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4063:1: ( rule__Mapping__Group__5__Impl rule__Mapping__Group__6 )
            // InternalSM2.g:4064:2: rule__Mapping__Group__5__Impl rule__Mapping__Group__6
            {
            pushFollow(FOLLOW_42);
            rule__Mapping__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5"


    // $ANTLR start "rule__Mapping__Group__5__Impl"
    // InternalSM2.g:4071:1: rule__Mapping__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Mapping__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4075:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:4076:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:4076:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:4077:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__5__Impl"


    // $ANTLR start "rule__Mapping__Group__6"
    // InternalSM2.g:4086:1: rule__Mapping__Group__6 : rule__Mapping__Group__6__Impl rule__Mapping__Group__7 ;
    public final void rule__Mapping__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4090:1: ( rule__Mapping__Group__6__Impl rule__Mapping__Group__7 )
            // InternalSM2.g:4091:2: rule__Mapping__Group__6__Impl rule__Mapping__Group__7
            {
            pushFollow(FOLLOW_42);
            rule__Mapping__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6"


    // $ANTLR start "rule__Mapping__Group__6__Impl"
    // InternalSM2.g:4098:1: rule__Mapping__Group__6__Impl : ( ( rule__Mapping__VisibilityAssignment_6 )? ) ;
    public final void rule__Mapping__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4102:1: ( ( ( rule__Mapping__VisibilityAssignment_6 )? ) )
            // InternalSM2.g:4103:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            {
            // InternalSM2.g:4103:1: ( ( rule__Mapping__VisibilityAssignment_6 )? )
            // InternalSM2.g:4104:2: ( rule__Mapping__VisibilityAssignment_6 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            }
            // InternalSM2.g:4105:2: ( rule__Mapping__VisibilityAssignment_6 )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( ((LA48_0>=32 && LA48_0<=33)||(LA48_0>=46 && LA48_0<=47)) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalSM2.g:4105:3: rule__Mapping__VisibilityAssignment_6
                    {
                    pushFollow(FOLLOW_2);
                    rule__Mapping__VisibilityAssignment_6();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getVisibilityAssignment_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__6__Impl"


    // $ANTLR start "rule__Mapping__Group__7"
    // InternalSM2.g:4113:1: rule__Mapping__Group__7 : rule__Mapping__Group__7__Impl rule__Mapping__Group__8 ;
    public final void rule__Mapping__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4117:1: ( rule__Mapping__Group__7__Impl rule__Mapping__Group__8 )
            // InternalSM2.g:4118:2: rule__Mapping__Group__7__Impl rule__Mapping__Group__8
            {
            pushFollow(FOLLOW_5);
            rule__Mapping__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7"


    // $ANTLR start "rule__Mapping__Group__7__Impl"
    // InternalSM2.g:4125:1: rule__Mapping__Group__7__Impl : ( ( rule__Mapping__NameMappingAssignment_7 ) ) ;
    public final void rule__Mapping__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4129:1: ( ( ( rule__Mapping__NameMappingAssignment_7 ) ) )
            // InternalSM2.g:4130:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            {
            // InternalSM2.g:4130:1: ( ( rule__Mapping__NameMappingAssignment_7 ) )
            // InternalSM2.g:4131:2: ( rule__Mapping__NameMappingAssignment_7 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            }
            // InternalSM2.g:4132:2: ( rule__Mapping__NameMappingAssignment_7 )
            // InternalSM2.g:4132:3: rule__Mapping__NameMappingAssignment_7
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__NameMappingAssignment_7();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getNameMappingAssignment_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__7__Impl"


    // $ANTLR start "rule__Mapping__Group__8"
    // InternalSM2.g:4140:1: rule__Mapping__Group__8 : rule__Mapping__Group__8__Impl ;
    public final void rule__Mapping__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4144:1: ( rule__Mapping__Group__8__Impl )
            // InternalSM2.g:4145:2: rule__Mapping__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Mapping__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8"


    // $ANTLR start "rule__Mapping__Group__8__Impl"
    // InternalSM2.g:4151:1: rule__Mapping__Group__8__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Mapping__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4155:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4156:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4156:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4157:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getSEMICOLONTerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__Group__8__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__0"
    // InternalSM2.g:4167:1: rule__PersonalizedStruct__Group__0 : rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 ;
    public final void rule__PersonalizedStruct__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4171:1: ( rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1 )
            // InternalSM2.g:4172:2: rule__PersonalizedStruct__Group__0__Impl rule__PersonalizedStruct__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__PersonalizedStruct__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0"


    // $ANTLR start "rule__PersonalizedStruct__Group__0__Impl"
    // InternalSM2.g:4179:1: rule__PersonalizedStruct__Group__0__Impl : ( 'struct' ) ;
    public final void rule__PersonalizedStruct__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4183:1: ( ( 'struct' ) )
            // InternalSM2.g:4184:1: ( 'struct' )
            {
            // InternalSM2.g:4184:1: ( 'struct' )
            // InternalSM2.g:4185:2: 'struct'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 
            }
            match(input,74,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getStructKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__0__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__1"
    // InternalSM2.g:4194:1: rule__PersonalizedStruct__Group__1 : rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 ;
    public final void rule__PersonalizedStruct__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4198:1: ( rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2 )
            // InternalSM2.g:4199:2: rule__PersonalizedStruct__Group__1__Impl rule__PersonalizedStruct__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__PersonalizedStruct__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1"


    // $ANTLR start "rule__PersonalizedStruct__Group__1__Impl"
    // InternalSM2.g:4206:1: rule__PersonalizedStruct__Group__1__Impl : ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) ;
    public final void rule__PersonalizedStruct__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4210:1: ( ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) ) )
            // InternalSM2.g:4211:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:4211:1: ( ( rule__PersonalizedStruct__NameStructAssignment_1 ) )
            // InternalSM2.g:4212:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 
            }
            // InternalSM2.g:4213:2: ( rule__PersonalizedStruct__NameStructAssignment_1 )
            // InternalSM2.g:4213:3: rule__PersonalizedStruct__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__NameStructAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getNameStructAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__1__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__2"
    // InternalSM2.g:4221:1: rule__PersonalizedStruct__Group__2 : rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 ;
    public final void rule__PersonalizedStruct__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4225:1: ( rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3 )
            // InternalSM2.g:4226:2: rule__PersonalizedStruct__Group__2__Impl rule__PersonalizedStruct__Group__3
            {
            pushFollow(FOLLOW_43);
            rule__PersonalizedStruct__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2"


    // $ANTLR start "rule__PersonalizedStruct__Group__2__Impl"
    // InternalSM2.g:4233:1: rule__PersonalizedStruct__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__PersonalizedStruct__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4237:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4238:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4238:1: ( RULE_OPENKEY )
            // InternalSM2.g:4239:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__2__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__3"
    // InternalSM2.g:4248:1: rule__PersonalizedStruct__Group__3 : rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 ;
    public final void rule__PersonalizedStruct__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4252:1: ( rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4 )
            // InternalSM2.g:4253:2: rule__PersonalizedStruct__Group__3__Impl rule__PersonalizedStruct__Group__4
            {
            pushFollow(FOLLOW_43);
            rule__PersonalizedStruct__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3"


    // $ANTLR start "rule__PersonalizedStruct__Group__3__Impl"
    // InternalSM2.g:4260:1: rule__PersonalizedStruct__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4264:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4265:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4265:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4266:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 
            }
            // InternalSM2.g:4267:2: ( RULE_EOLINE )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_EOLINE) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalSM2.g:4267:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__3__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__4"
    // InternalSM2.g:4275:1: rule__PersonalizedStruct__Group__4 : rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 ;
    public final void rule__PersonalizedStruct__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4279:1: ( rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5 )
            // InternalSM2.g:4280:2: rule__PersonalizedStruct__Group__4__Impl rule__PersonalizedStruct__Group__5
            {
            pushFollow(FOLLOW_28);
            rule__PersonalizedStruct__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4"


    // $ANTLR start "rule__PersonalizedStruct__Group__4__Impl"
    // InternalSM2.g:4287:1: rule__PersonalizedStruct__Group__4__Impl : ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) ) ;
    public final void rule__PersonalizedStruct__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4291:1: ( ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) ) )
            // InternalSM2.g:4292:1: ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) )
            {
            // InternalSM2.g:4292:1: ( ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* ) )
            // InternalSM2.g:4293:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) ) ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* )
            {
            // InternalSM2.g:4293:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 ) )
            // InternalSM2.g:4294:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }
            // InternalSM2.g:4295:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )
            // InternalSM2.g:4295:4: rule__PersonalizedStruct__PropertiesAssignment_4
            {
            pushFollow(FOLLOW_44);
            rule__PersonalizedStruct__PropertiesAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }

            }

            // InternalSM2.g:4298:2: ( ( rule__PersonalizedStruct__PropertiesAssignment_4 )* )
            // InternalSM2.g:4299:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }
            // InternalSM2.g:4300:3: ( rule__PersonalizedStruct__PropertiesAssignment_4 )*
            loop50:
            do {
                int alt50=2;
                int LA50_0 = input.LA(1);

                if ( ((LA50_0>=35 && LA50_0<=45)) ) {
                    alt50=1;
                }


                switch (alt50) {
            	case 1 :
            	    // InternalSM2.g:4300:4: rule__PersonalizedStruct__PropertiesAssignment_4
            	    {
            	    pushFollow(FOLLOW_44);
            	    rule__PersonalizedStruct__PropertiesAssignment_4();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop50;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesAssignment_4()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__4__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__5"
    // InternalSM2.g:4309:1: rule__PersonalizedStruct__Group__5 : rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 ;
    public final void rule__PersonalizedStruct__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4313:1: ( rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6 )
            // InternalSM2.g:4314:2: rule__PersonalizedStruct__Group__5__Impl rule__PersonalizedStruct__Group__6
            {
            pushFollow(FOLLOW_21);
            rule__PersonalizedStruct__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5"


    // $ANTLR start "rule__PersonalizedStruct__Group__5__Impl"
    // InternalSM2.g:4321:1: rule__PersonalizedStruct__Group__5__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__PersonalizedStruct__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4325:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:4326:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:4326:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:4327:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getCLOSEKEYTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__5__Impl"


    // $ANTLR start "rule__PersonalizedStruct__Group__6"
    // InternalSM2.g:4336:1: rule__PersonalizedStruct__Group__6 : rule__PersonalizedStruct__Group__6__Impl ;
    public final void rule__PersonalizedStruct__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4340:1: ( rule__PersonalizedStruct__Group__6__Impl )
            // InternalSM2.g:4341:2: rule__PersonalizedStruct__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__PersonalizedStruct__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6"


    // $ANTLR start "rule__PersonalizedStruct__Group__6__Impl"
    // InternalSM2.g:4347:1: rule__PersonalizedStruct__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__PersonalizedStruct__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4351:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4352:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4352:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4353:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:4354:2: ( RULE_EOLINE )?
            int alt51=2;
            alt51 = dfa51.predict(input);
            switch (alt51) {
                case 1 :
                    // InternalSM2.g:4354:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__Group__6__Impl"


    // $ANTLR start "rule__User__Group__0"
    // InternalSM2.g:4363:1: rule__User__Group__0 : rule__User__Group__0__Impl rule__User__Group__1 ;
    public final void rule__User__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4367:1: ( rule__User__Group__0__Impl rule__User__Group__1 )
            // InternalSM2.g:4368:2: rule__User__Group__0__Impl rule__User__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__User__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0"


    // $ANTLR start "rule__User__Group__0__Impl"
    // InternalSM2.g:4375:1: rule__User__Group__0__Impl : ( 'struct' ) ;
    public final void rule__User__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4379:1: ( ( 'struct' ) )
            // InternalSM2.g:4380:1: ( 'struct' )
            {
            // InternalSM2.g:4380:1: ( 'struct' )
            // InternalSM2.g:4381:2: 'struct'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStructKeyword_0()); 
            }
            match(input,74,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStructKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__0__Impl"


    // $ANTLR start "rule__User__Group__1"
    // InternalSM2.g:4390:1: rule__User__Group__1 : rule__User__Group__1__Impl rule__User__Group__2 ;
    public final void rule__User__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4394:1: ( rule__User__Group__1__Impl rule__User__Group__2 )
            // InternalSM2.g:4395:2: rule__User__Group__1__Impl rule__User__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__User__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1"


    // $ANTLR start "rule__User__Group__1__Impl"
    // InternalSM2.g:4402:1: rule__User__Group__1__Impl : ( ( rule__User__NameStructAssignment_1 ) ) ;
    public final void rule__User__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4406:1: ( ( ( rule__User__NameStructAssignment_1 ) ) )
            // InternalSM2.g:4407:1: ( ( rule__User__NameStructAssignment_1 ) )
            {
            // InternalSM2.g:4407:1: ( ( rule__User__NameStructAssignment_1 ) )
            // InternalSM2.g:4408:2: ( rule__User__NameStructAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameStructAssignment_1()); 
            }
            // InternalSM2.g:4409:2: ( rule__User__NameStructAssignment_1 )
            // InternalSM2.g:4409:3: rule__User__NameStructAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__User__NameStructAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameStructAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__1__Impl"


    // $ANTLR start "rule__User__Group__2"
    // InternalSM2.g:4417:1: rule__User__Group__2 : rule__User__Group__2__Impl rule__User__Group__3 ;
    public final void rule__User__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4421:1: ( rule__User__Group__2__Impl rule__User__Group__3 )
            // InternalSM2.g:4422:2: rule__User__Group__2__Impl rule__User__Group__3
            {
            pushFollow(FOLLOW_45);
            rule__User__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2"


    // $ANTLR start "rule__User__Group__2__Impl"
    // InternalSM2.g:4429:1: rule__User__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__User__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4433:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:4434:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:4434:1: ( RULE_OPENKEY )
            // InternalSM2.g:4435:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__2__Impl"


    // $ANTLR start "rule__User__Group__3"
    // InternalSM2.g:4444:1: rule__User__Group__3 : rule__User__Group__3__Impl rule__User__Group__4 ;
    public final void rule__User__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4448:1: ( rule__User__Group__3__Impl rule__User__Group__4 )
            // InternalSM2.g:4449:2: rule__User__Group__3__Impl rule__User__Group__4
            {
            pushFollow(FOLLOW_45);
            rule__User__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3"


    // $ANTLR start "rule__User__Group__3__Impl"
    // InternalSM2.g:4456:1: rule__User__Group__3__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4460:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4461:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4461:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4462:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 
            }
            // InternalSM2.g:4463:2: ( RULE_EOLINE )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( (LA52_0==RULE_EOLINE) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalSM2.g:4463:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__3__Impl"


    // $ANTLR start "rule__User__Group__4"
    // InternalSM2.g:4471:1: rule__User__Group__4 : rule__User__Group__4__Impl rule__User__Group__5 ;
    public final void rule__User__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4475:1: ( rule__User__Group__4__Impl rule__User__Group__5 )
            // InternalSM2.g:4476:2: rule__User__Group__4__Impl rule__User__Group__5
            {
            pushFollow(FOLLOW_9);
            rule__User__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4"


    // $ANTLR start "rule__User__Group__4__Impl"
    // InternalSM2.g:4483:1: rule__User__Group__4__Impl : ( 'address' ) ;
    public final void rule__User__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4487:1: ( ( 'address' ) )
            // InternalSM2.g:4488:1: ( 'address' )
            {
            // InternalSM2.g:4488:1: ( 'address' )
            // InternalSM2.g:4489:2: 'address'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAddressKeyword_4()); 
            }
            match(input,40,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAddressKeyword_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__4__Impl"


    // $ANTLR start "rule__User__Group__5"
    // InternalSM2.g:4498:1: rule__User__Group__5 : rule__User__Group__5__Impl rule__User__Group__6 ;
    public final void rule__User__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4502:1: ( rule__User__Group__5__Impl rule__User__Group__6 )
            // InternalSM2.g:4503:2: rule__User__Group__5__Impl rule__User__Group__6
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5"


    // $ANTLR start "rule__User__Group__5__Impl"
    // InternalSM2.g:4510:1: rule__User__Group__5__Impl : ( ( rule__User__IdAdressAssignment_5 ) ) ;
    public final void rule__User__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4514:1: ( ( ( rule__User__IdAdressAssignment_5 ) ) )
            // InternalSM2.g:4515:1: ( ( rule__User__IdAdressAssignment_5 ) )
            {
            // InternalSM2.g:4515:1: ( ( rule__User__IdAdressAssignment_5 ) )
            // InternalSM2.g:4516:2: ( rule__User__IdAdressAssignment_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getIdAdressAssignment_5()); 
            }
            // InternalSM2.g:4517:2: ( rule__User__IdAdressAssignment_5 )
            // InternalSM2.g:4517:3: rule__User__IdAdressAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__User__IdAdressAssignment_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getIdAdressAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__5__Impl"


    // $ANTLR start "rule__User__Group__6"
    // InternalSM2.g:4525:1: rule__User__Group__6 : rule__User__Group__6__Impl rule__User__Group__7 ;
    public final void rule__User__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4529:1: ( rule__User__Group__6__Impl rule__User__Group__7 )
            // InternalSM2.g:4530:2: rule__User__Group__6__Impl rule__User__Group__7
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6"


    // $ANTLR start "rule__User__Group__6__Impl"
    // InternalSM2.g:4537:1: rule__User__Group__6__Impl : ( ( rule__User__Group_6__0 )? ) ;
    public final void rule__User__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4541:1: ( ( ( rule__User__Group_6__0 )? ) )
            // InternalSM2.g:4542:1: ( ( rule__User__Group_6__0 )? )
            {
            // InternalSM2.g:4542:1: ( ( rule__User__Group_6__0 )? )
            // InternalSM2.g:4543:2: ( rule__User__Group_6__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_6()); 
            }
            // InternalSM2.g:4544:2: ( rule__User__Group_6__0 )?
            int alt53=2;
            int LA53_0 = input.LA(1);

            if ( (LA53_0==68) ) {
                alt53=1;
            }
            switch (alt53) {
                case 1 :
                    // InternalSM2.g:4544:3: rule__User__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_6__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__6__Impl"


    // $ANTLR start "rule__User__Group__7"
    // InternalSM2.g:4552:1: rule__User__Group__7 : rule__User__Group__7__Impl rule__User__Group__8 ;
    public final void rule__User__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4556:1: ( rule__User__Group__7__Impl rule__User__Group__8 )
            // InternalSM2.g:4557:2: rule__User__Group__7__Impl rule__User__Group__8
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7"


    // $ANTLR start "rule__User__Group__7__Impl"
    // InternalSM2.g:4564:1: rule__User__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4568:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4569:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4569:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4570:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__7__Impl"


    // $ANTLR start "rule__User__Group__8"
    // InternalSM2.g:4579:1: rule__User__Group__8 : rule__User__Group__8__Impl rule__User__Group__9 ;
    public final void rule__User__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4583:1: ( rule__User__Group__8__Impl rule__User__Group__9 )
            // InternalSM2.g:4584:2: rule__User__Group__8__Impl rule__User__Group__9
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8"


    // $ANTLR start "rule__User__Group__8__Impl"
    // InternalSM2.g:4591:1: rule__User__Group__8__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4595:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4596:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4596:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4597:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8()); 
            }
            // InternalSM2.g:4598:2: ( RULE_EOLINE )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==RULE_EOLINE) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalSM2.g:4598:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__8__Impl"


    // $ANTLR start "rule__User__Group__9"
    // InternalSM2.g:4606:1: rule__User__Group__9 : rule__User__Group__9__Impl rule__User__Group__10 ;
    public final void rule__User__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4610:1: ( rule__User__Group__9__Impl rule__User__Group__10 )
            // InternalSM2.g:4611:2: rule__User__Group__9__Impl rule__User__Group__10
            {
            pushFollow(FOLLOW_41);
            rule__User__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__10();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9"


    // $ANTLR start "rule__User__Group__9__Impl"
    // InternalSM2.g:4618:1: rule__User__Group__9__Impl : ( 'string' ) ;
    public final void rule__User__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4622:1: ( ( 'string' ) )
            // InternalSM2.g:4623:1: ( 'string' )
            {
            // InternalSM2.g:4623:1: ( 'string' )
            // InternalSM2.g:4624:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_9()); 
            }
            match(input,39,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__9__Impl"


    // $ANTLR start "rule__User__Group__10"
    // InternalSM2.g:4633:1: rule__User__Group__10 : rule__User__Group__10__Impl rule__User__Group__11 ;
    public final void rule__User__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4637:1: ( rule__User__Group__10__Impl rule__User__Group__11 )
            // InternalSM2.g:4638:2: rule__User__Group__10__Impl rule__User__Group__11
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__10__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__11();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10"


    // $ANTLR start "rule__User__Group__10__Impl"
    // InternalSM2.g:4645:1: rule__User__Group__10__Impl : ( ( rule__User__NameUserAssignment_10 ) ) ;
    public final void rule__User__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4649:1: ( ( ( rule__User__NameUserAssignment_10 ) ) )
            // InternalSM2.g:4650:1: ( ( rule__User__NameUserAssignment_10 ) )
            {
            // InternalSM2.g:4650:1: ( ( rule__User__NameUserAssignment_10 ) )
            // InternalSM2.g:4651:2: ( rule__User__NameUserAssignment_10 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameUserAssignment_10()); 
            }
            // InternalSM2.g:4652:2: ( rule__User__NameUserAssignment_10 )
            // InternalSM2.g:4652:3: rule__User__NameUserAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__User__NameUserAssignment_10();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameUserAssignment_10()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__10__Impl"


    // $ANTLR start "rule__User__Group__11"
    // InternalSM2.g:4660:1: rule__User__Group__11 : rule__User__Group__11__Impl rule__User__Group__12 ;
    public final void rule__User__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4664:1: ( rule__User__Group__11__Impl rule__User__Group__12 )
            // InternalSM2.g:4665:2: rule__User__Group__11__Impl rule__User__Group__12
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__11__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__12();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11"


    // $ANTLR start "rule__User__Group__11__Impl"
    // InternalSM2.g:4672:1: rule__User__Group__11__Impl : ( ( rule__User__Group_11__0 )? ) ;
    public final void rule__User__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4676:1: ( ( ( rule__User__Group_11__0 )? ) )
            // InternalSM2.g:4677:1: ( ( rule__User__Group_11__0 )? )
            {
            // InternalSM2.g:4677:1: ( ( rule__User__Group_11__0 )? )
            // InternalSM2.g:4678:2: ( rule__User__Group_11__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_11()); 
            }
            // InternalSM2.g:4679:2: ( rule__User__Group_11__0 )?
            int alt55=2;
            int LA55_0 = input.LA(1);

            if ( (LA55_0==68) ) {
                alt55=1;
            }
            switch (alt55) {
                case 1 :
                    // InternalSM2.g:4679:3: rule__User__Group_11__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_11__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_11()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__11__Impl"


    // $ANTLR start "rule__User__Group__12"
    // InternalSM2.g:4687:1: rule__User__Group__12 : rule__User__Group__12__Impl rule__User__Group__13 ;
    public final void rule__User__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4691:1: ( rule__User__Group__12__Impl rule__User__Group__13 )
            // InternalSM2.g:4692:2: rule__User__Group__12__Impl rule__User__Group__13
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__12__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__13();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12"


    // $ANTLR start "rule__User__Group__12__Impl"
    // InternalSM2.g:4699:1: rule__User__Group__12__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4703:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4704:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4704:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4705:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_12()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__12__Impl"


    // $ANTLR start "rule__User__Group__13"
    // InternalSM2.g:4714:1: rule__User__Group__13 : rule__User__Group__13__Impl rule__User__Group__14 ;
    public final void rule__User__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4718:1: ( rule__User__Group__13__Impl rule__User__Group__14 )
            // InternalSM2.g:4719:2: rule__User__Group__13__Impl rule__User__Group__14
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__13__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__14();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13"


    // $ANTLR start "rule__User__Group__13__Impl"
    // InternalSM2.g:4726:1: rule__User__Group__13__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4730:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4731:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4731:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4732:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13()); 
            }
            // InternalSM2.g:4733:2: ( RULE_EOLINE )?
            int alt56=2;
            int LA56_0 = input.LA(1);

            if ( (LA56_0==RULE_EOLINE) ) {
                alt56=1;
            }
            switch (alt56) {
                case 1 :
                    // InternalSM2.g:4733:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_13()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__13__Impl"


    // $ANTLR start "rule__User__Group__14"
    // InternalSM2.g:4741:1: rule__User__Group__14 : rule__User__Group__14__Impl rule__User__Group__15 ;
    public final void rule__User__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4745:1: ( rule__User__Group__14__Impl rule__User__Group__15 )
            // InternalSM2.g:4746:2: rule__User__Group__14__Impl rule__User__Group__15
            {
            pushFollow(FOLLOW_41);
            rule__User__Group__14__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__15();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14"


    // $ANTLR start "rule__User__Group__14__Impl"
    // InternalSM2.g:4753:1: rule__User__Group__14__Impl : ( 'string' ) ;
    public final void rule__User__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4757:1: ( ( 'string' ) )
            // InternalSM2.g:4758:1: ( 'string' )
            {
            // InternalSM2.g:4758:1: ( 'string' )
            // InternalSM2.g:4759:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_14()); 
            }
            match(input,39,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_14()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__14__Impl"


    // $ANTLR start "rule__User__Group__15"
    // InternalSM2.g:4768:1: rule__User__Group__15 : rule__User__Group__15__Impl rule__User__Group__16 ;
    public final void rule__User__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4772:1: ( rule__User__Group__15__Impl rule__User__Group__16 )
            // InternalSM2.g:4773:2: rule__User__Group__15__Impl rule__User__Group__16
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__15__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__16();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15"


    // $ANTLR start "rule__User__Group__15__Impl"
    // InternalSM2.g:4780:1: rule__User__Group__15__Impl : ( ( rule__User__SurnameAssignment_15 ) ) ;
    public final void rule__User__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4784:1: ( ( ( rule__User__SurnameAssignment_15 ) ) )
            // InternalSM2.g:4785:1: ( ( rule__User__SurnameAssignment_15 ) )
            {
            // InternalSM2.g:4785:1: ( ( rule__User__SurnameAssignment_15 ) )
            // InternalSM2.g:4786:2: ( rule__User__SurnameAssignment_15 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSurnameAssignment_15()); 
            }
            // InternalSM2.g:4787:2: ( rule__User__SurnameAssignment_15 )
            // InternalSM2.g:4787:3: rule__User__SurnameAssignment_15
            {
            pushFollow(FOLLOW_2);
            rule__User__SurnameAssignment_15();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSurnameAssignment_15()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__15__Impl"


    // $ANTLR start "rule__User__Group__16"
    // InternalSM2.g:4795:1: rule__User__Group__16 : rule__User__Group__16__Impl rule__User__Group__17 ;
    public final void rule__User__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4799:1: ( rule__User__Group__16__Impl rule__User__Group__17 )
            // InternalSM2.g:4800:2: rule__User__Group__16__Impl rule__User__Group__17
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__16__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__17();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__16"


    // $ANTLR start "rule__User__Group__16__Impl"
    // InternalSM2.g:4807:1: rule__User__Group__16__Impl : ( ( rule__User__Group_16__0 )? ) ;
    public final void rule__User__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4811:1: ( ( ( rule__User__Group_16__0 )? ) )
            // InternalSM2.g:4812:1: ( ( rule__User__Group_16__0 )? )
            {
            // InternalSM2.g:4812:1: ( ( rule__User__Group_16__0 )? )
            // InternalSM2.g:4813:2: ( rule__User__Group_16__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_16()); 
            }
            // InternalSM2.g:4814:2: ( rule__User__Group_16__0 )?
            int alt57=2;
            int LA57_0 = input.LA(1);

            if ( (LA57_0==68) ) {
                alt57=1;
            }
            switch (alt57) {
                case 1 :
                    // InternalSM2.g:4814:3: rule__User__Group_16__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_16__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_16()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__16__Impl"


    // $ANTLR start "rule__User__Group__17"
    // InternalSM2.g:4822:1: rule__User__Group__17 : rule__User__Group__17__Impl rule__User__Group__18 ;
    public final void rule__User__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4826:1: ( rule__User__Group__17__Impl rule__User__Group__18 )
            // InternalSM2.g:4827:2: rule__User__Group__17__Impl rule__User__Group__18
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__17__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__18();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__17"


    // $ANTLR start "rule__User__Group__17__Impl"
    // InternalSM2.g:4834:1: rule__User__Group__17__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4838:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4839:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4839:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4840:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_17()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__17__Impl"


    // $ANTLR start "rule__User__Group__18"
    // InternalSM2.g:4849:1: rule__User__Group__18 : rule__User__Group__18__Impl rule__User__Group__19 ;
    public final void rule__User__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4853:1: ( rule__User__Group__18__Impl rule__User__Group__19 )
            // InternalSM2.g:4854:2: rule__User__Group__18__Impl rule__User__Group__19
            {
            pushFollow(FOLLOW_47);
            rule__User__Group__18__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__19();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__18"


    // $ANTLR start "rule__User__Group__18__Impl"
    // InternalSM2.g:4861:1: rule__User__Group__18__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4865:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:4866:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:4866:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:4867:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18()); 
            }
            // InternalSM2.g:4868:2: ( RULE_EOLINE )?
            int alt58=2;
            int LA58_0 = input.LA(1);

            if ( (LA58_0==RULE_EOLINE) ) {
                alt58=1;
            }
            switch (alt58) {
                case 1 :
                    // InternalSM2.g:4868:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_18()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__18__Impl"


    // $ANTLR start "rule__User__Group__19"
    // InternalSM2.g:4876:1: rule__User__Group__19 : rule__User__Group__19__Impl rule__User__Group__20 ;
    public final void rule__User__Group__19() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4880:1: ( rule__User__Group__19__Impl rule__User__Group__20 )
            // InternalSM2.g:4881:2: rule__User__Group__19__Impl rule__User__Group__20
            {
            pushFollow(FOLLOW_41);
            rule__User__Group__19__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__20();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__19"


    // $ANTLR start "rule__User__Group__19__Impl"
    // InternalSM2.g:4888:1: rule__User__Group__19__Impl : ( 'string' ) ;
    public final void rule__User__Group__19__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4892:1: ( ( 'string' ) )
            // InternalSM2.g:4893:1: ( 'string' )
            {
            // InternalSM2.g:4893:1: ( 'string' )
            // InternalSM2.g:4894:2: 'string'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getStringKeyword_19()); 
            }
            match(input,39,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getStringKeyword_19()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__19__Impl"


    // $ANTLR start "rule__User__Group__20"
    // InternalSM2.g:4903:1: rule__User__Group__20 : rule__User__Group__20__Impl rule__User__Group__21 ;
    public final void rule__User__Group__20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4907:1: ( rule__User__Group__20__Impl rule__User__Group__21 )
            // InternalSM2.g:4908:2: rule__User__Group__20__Impl rule__User__Group__21
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__20__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__21();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__20"


    // $ANTLR start "rule__User__Group__20__Impl"
    // InternalSM2.g:4915:1: rule__User__Group__20__Impl : ( ( rule__User__EmailAssignment_20 ) ) ;
    public final void rule__User__Group__20__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4919:1: ( ( ( rule__User__EmailAssignment_20 ) ) )
            // InternalSM2.g:4920:1: ( ( rule__User__EmailAssignment_20 ) )
            {
            // InternalSM2.g:4920:1: ( ( rule__User__EmailAssignment_20 ) )
            // InternalSM2.g:4921:2: ( rule__User__EmailAssignment_20 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEmailAssignment_20()); 
            }
            // InternalSM2.g:4922:2: ( rule__User__EmailAssignment_20 )
            // InternalSM2.g:4922:3: rule__User__EmailAssignment_20
            {
            pushFollow(FOLLOW_2);
            rule__User__EmailAssignment_20();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEmailAssignment_20()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__20__Impl"


    // $ANTLR start "rule__User__Group__21"
    // InternalSM2.g:4930:1: rule__User__Group__21 : rule__User__Group__21__Impl rule__User__Group__22 ;
    public final void rule__User__Group__21() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4934:1: ( rule__User__Group__21__Impl rule__User__Group__22 )
            // InternalSM2.g:4935:2: rule__User__Group__21__Impl rule__User__Group__22
            {
            pushFollow(FOLLOW_46);
            rule__User__Group__21__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__22();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__21"


    // $ANTLR start "rule__User__Group__21__Impl"
    // InternalSM2.g:4942:1: rule__User__Group__21__Impl : ( ( rule__User__Group_21__0 )? ) ;
    public final void rule__User__Group__21__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4946:1: ( ( ( rule__User__Group_21__0 )? ) )
            // InternalSM2.g:4947:1: ( ( rule__User__Group_21__0 )? )
            {
            // InternalSM2.g:4947:1: ( ( rule__User__Group_21__0 )? )
            // InternalSM2.g:4948:2: ( rule__User__Group_21__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getGroup_21()); 
            }
            // InternalSM2.g:4949:2: ( rule__User__Group_21__0 )?
            int alt59=2;
            int LA59_0 = input.LA(1);

            if ( (LA59_0==68) ) {
                alt59=1;
            }
            switch (alt59) {
                case 1 :
                    // InternalSM2.g:4949:3: rule__User__Group_21__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Group_21__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getGroup_21()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__21__Impl"


    // $ANTLR start "rule__User__Group__22"
    // InternalSM2.g:4957:1: rule__User__Group__22 : rule__User__Group__22__Impl rule__User__Group__23 ;
    public final void rule__User__Group__22() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4961:1: ( rule__User__Group__22__Impl rule__User__Group__23 )
            // InternalSM2.g:4962:2: rule__User__Group__22__Impl rule__User__Group__23
            {
            pushFollow(FOLLOW_48);
            rule__User__Group__22__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__23();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__22"


    // $ANTLR start "rule__User__Group__22__Impl"
    // InternalSM2.g:4969:1: rule__User__Group__22__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__22__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4973:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:4974:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:4974:1: ( RULE_SEMICOLON )
            // InternalSM2.g:4975:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_22()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__22__Impl"


    // $ANTLR start "rule__User__Group__23"
    // InternalSM2.g:4984:1: rule__User__Group__23 : rule__User__Group__23__Impl rule__User__Group__24 ;
    public final void rule__User__Group__23() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:4988:1: ( rule__User__Group__23__Impl rule__User__Group__24 )
            // InternalSM2.g:4989:2: rule__User__Group__23__Impl rule__User__Group__24
            {
            pushFollow(FOLLOW_48);
            rule__User__Group__23__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__24();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__23"


    // $ANTLR start "rule__User__Group__23__Impl"
    // InternalSM2.g:4996:1: rule__User__Group__23__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__23__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5000:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5001:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5001:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5002:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23()); 
            }
            // InternalSM2.g:5003:2: ( RULE_EOLINE )?
            int alt60=2;
            int LA60_0 = input.LA(1);

            if ( (LA60_0==RULE_EOLINE) ) {
                alt60=1;
            }
            switch (alt60) {
                case 1 :
                    // InternalSM2.g:5003:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_23()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__23__Impl"


    // $ANTLR start "rule__User__Group__24"
    // InternalSM2.g:5011:1: rule__User__Group__24 : rule__User__Group__24__Impl rule__User__Group__25 ;
    public final void rule__User__Group__24() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5015:1: ( rule__User__Group__24__Impl rule__User__Group__25 )
            // InternalSM2.g:5016:2: rule__User__Group__24__Impl rule__User__Group__25
            {
            pushFollow(FOLLOW_49);
            rule__User__Group__24__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__25();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__24"


    // $ANTLR start "rule__User__Group__24__Impl"
    // InternalSM2.g:5023:1: rule__User__Group__24__Impl : ( 'uint' ) ;
    public final void rule__User__Group__24__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5027:1: ( ( 'uint' ) )
            // InternalSM2.g:5028:1: ( 'uint' )
            {
            // InternalSM2.g:5028:1: ( 'uint' )
            // InternalSM2.g:5029:2: 'uint'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getUintKeyword_24()); 
            }
            match(input,36,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getUintKeyword_24()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__24__Impl"


    // $ANTLR start "rule__User__Group__25"
    // InternalSM2.g:5038:1: rule__User__Group__25 : rule__User__Group__25__Impl rule__User__Group__26 ;
    public final void rule__User__Group__25() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5042:1: ( rule__User__Group__25__Impl rule__User__Group__26 )
            // InternalSM2.g:5043:2: rule__User__Group__25__Impl rule__User__Group__26
            {
            pushFollow(FOLLOW_50);
            rule__User__Group__25__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__26();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__25"


    // $ANTLR start "rule__User__Group__25__Impl"
    // InternalSM2.g:5050:1: rule__User__Group__25__Impl : ( 'amountAccount' ) ;
    public final void rule__User__Group__25__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5054:1: ( ( 'amountAccount' ) )
            // InternalSM2.g:5055:1: ( 'amountAccount' )
            {
            // InternalSM2.g:5055:1: ( 'amountAccount' )
            // InternalSM2.g:5056:2: 'amountAccount'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAmountAccountKeyword_25()); 
            }
            match(input,75,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAmountAccountKeyword_25()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__25__Impl"


    // $ANTLR start "rule__User__Group__26"
    // InternalSM2.g:5065:1: rule__User__Group__26 : rule__User__Group__26__Impl rule__User__Group__27 ;
    public final void rule__User__Group__26() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5069:1: ( rule__User__Group__26__Impl rule__User__Group__27 )
            // InternalSM2.g:5070:2: rule__User__Group__26__Impl rule__User__Group__27
            {
            pushFollow(FOLLOW_50);
            rule__User__Group__26__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__27();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__26"


    // $ANTLR start "rule__User__Group__26__Impl"
    // InternalSM2.g:5077:1: rule__User__Group__26__Impl : ( ( rule__User__Alternatives_26 )? ) ;
    public final void rule__User__Group__26__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5081:1: ( ( ( rule__User__Alternatives_26 )? ) )
            // InternalSM2.g:5082:1: ( ( rule__User__Alternatives_26 )? )
            {
            // InternalSM2.g:5082:1: ( ( rule__User__Alternatives_26 )? )
            // InternalSM2.g:5083:2: ( rule__User__Alternatives_26 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAlternatives_26()); 
            }
            // InternalSM2.g:5084:2: ( rule__User__Alternatives_26 )?
            int alt61=2;
            int LA61_0 = input.LA(1);

            if ( (LA61_0==RULE_INTEGER||LA61_0==68) ) {
                alt61=1;
            }
            switch (alt61) {
                case 1 :
                    // InternalSM2.g:5084:3: rule__User__Alternatives_26
                    {
                    pushFollow(FOLLOW_2);
                    rule__User__Alternatives_26();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAlternatives_26()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__26__Impl"


    // $ANTLR start "rule__User__Group__27"
    // InternalSM2.g:5092:1: rule__User__Group__27 : rule__User__Group__27__Impl rule__User__Group__28 ;
    public final void rule__User__Group__27() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5096:1: ( rule__User__Group__27__Impl rule__User__Group__28 )
            // InternalSM2.g:5097:2: rule__User__Group__27__Impl rule__User__Group__28
            {
            pushFollow(FOLLOW_51);
            rule__User__Group__27__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__28();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__27"


    // $ANTLR start "rule__User__Group__27__Impl"
    // InternalSM2.g:5104:1: rule__User__Group__27__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__User__Group__27__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5108:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5109:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5109:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5110:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSEMICOLONTerminalRuleCall_27()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__27__Impl"


    // $ANTLR start "rule__User__Group__28"
    // InternalSM2.g:5119:1: rule__User__Group__28 : rule__User__Group__28__Impl rule__User__Group__29 ;
    public final void rule__User__Group__28() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5123:1: ( rule__User__Group__28__Impl rule__User__Group__29 )
            // InternalSM2.g:5124:2: rule__User__Group__28__Impl rule__User__Group__29
            {
            pushFollow(FOLLOW_51);
            rule__User__Group__28__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__29();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__28"


    // $ANTLR start "rule__User__Group__28__Impl"
    // InternalSM2.g:5131:1: rule__User__Group__28__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__28__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5135:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5136:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5136:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5137:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28()); 
            }
            // InternalSM2.g:5138:2: ( RULE_EOLINE )?
            int alt62=2;
            int LA62_0 = input.LA(1);

            if ( (LA62_0==RULE_EOLINE) ) {
                alt62=1;
            }
            switch (alt62) {
                case 1 :
                    // InternalSM2.g:5138:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_28()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__28__Impl"


    // $ANTLR start "rule__User__Group__29"
    // InternalSM2.g:5146:1: rule__User__Group__29 : rule__User__Group__29__Impl rule__User__Group__30 ;
    public final void rule__User__Group__29() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5150:1: ( rule__User__Group__29__Impl rule__User__Group__30 )
            // InternalSM2.g:5151:2: rule__User__Group__29__Impl rule__User__Group__30
            {
            pushFollow(FOLLOW_21);
            rule__User__Group__29__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group__30();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__29"


    // $ANTLR start "rule__User__Group__29__Impl"
    // InternalSM2.g:5158:1: rule__User__Group__29__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__User__Group__29__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5162:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:5163:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:5163:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:5164:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getCLOSEKEYTerminalRuleCall_29()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__29__Impl"


    // $ANTLR start "rule__User__Group__30"
    // InternalSM2.g:5173:1: rule__User__Group__30 : rule__User__Group__30__Impl ;
    public final void rule__User__Group__30() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5177:1: ( rule__User__Group__30__Impl )
            // InternalSM2.g:5178:2: rule__User__Group__30__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group__30__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__30"


    // $ANTLR start "rule__User__Group__30__Impl"
    // InternalSM2.g:5184:1: rule__User__Group__30__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__User__Group__30__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5188:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5189:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5189:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5190:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30()); 
            }
            // InternalSM2.g:5191:2: ( RULE_EOLINE )?
            int alt63=2;
            alt63 = dfa63.predict(input);
            switch (alt63) {
                case 1 :
                    // InternalSM2.g:5191:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEOLINETerminalRuleCall_30()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group__30__Impl"


    // $ANTLR start "rule__User__Group_6__0"
    // InternalSM2.g:5200:1: rule__User__Group_6__0 : rule__User__Group_6__0__Impl rule__User__Group_6__1 ;
    public final void rule__User__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5204:1: ( rule__User__Group_6__0__Impl rule__User__Group_6__1 )
            // InternalSM2.g:5205:2: rule__User__Group_6__0__Impl rule__User__Group_6__1
            {
            pushFollow(FOLLOW_41);
            rule__User__Group_6__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_6__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__0"


    // $ANTLR start "rule__User__Group_6__0__Impl"
    // InternalSM2.g:5212:1: rule__User__Group_6__0__Impl : ( '=' ) ;
    public final void rule__User__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5216:1: ( ( '=' ) )
            // InternalSM2.g:5217:1: ( '=' )
            {
            // InternalSM2.g:5217:1: ( '=' )
            // InternalSM2.g:5218:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_6_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__0__Impl"


    // $ANTLR start "rule__User__Group_6__1"
    // InternalSM2.g:5227:1: rule__User__Group_6__1 : rule__User__Group_6__1__Impl ;
    public final void rule__User__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5231:1: ( rule__User__Group_6__1__Impl )
            // InternalSM2.g:5232:2: rule__User__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_6__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__1"


    // $ANTLR start "rule__User__Group_6__1__Impl"
    // InternalSM2.g:5238:1: rule__User__Group_6__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5242:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5243:1: ( RULE_STRING )
            {
            // InternalSM2.g:5243:1: ( RULE_STRING )
            // InternalSM2.g:5244:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_6_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_6__1__Impl"


    // $ANTLR start "rule__User__Group_11__0"
    // InternalSM2.g:5254:1: rule__User__Group_11__0 : rule__User__Group_11__0__Impl rule__User__Group_11__1 ;
    public final void rule__User__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5258:1: ( rule__User__Group_11__0__Impl rule__User__Group_11__1 )
            // InternalSM2.g:5259:2: rule__User__Group_11__0__Impl rule__User__Group_11__1
            {
            pushFollow(FOLLOW_41);
            rule__User__Group_11__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_11__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__0"


    // $ANTLR start "rule__User__Group_11__0__Impl"
    // InternalSM2.g:5266:1: rule__User__Group_11__0__Impl : ( '=' ) ;
    public final void rule__User__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5270:1: ( ( '=' ) )
            // InternalSM2.g:5271:1: ( '=' )
            {
            // InternalSM2.g:5271:1: ( '=' )
            // InternalSM2.g:5272:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_11_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_11_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__0__Impl"


    // $ANTLR start "rule__User__Group_11__1"
    // InternalSM2.g:5281:1: rule__User__Group_11__1 : rule__User__Group_11__1__Impl ;
    public final void rule__User__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5285:1: ( rule__User__Group_11__1__Impl )
            // InternalSM2.g:5286:2: rule__User__Group_11__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_11__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__1"


    // $ANTLR start "rule__User__Group_11__1__Impl"
    // InternalSM2.g:5292:1: rule__User__Group_11__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5296:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5297:1: ( RULE_STRING )
            {
            // InternalSM2.g:5297:1: ( RULE_STRING )
            // InternalSM2.g:5298:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_11_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_11__1__Impl"


    // $ANTLR start "rule__User__Group_16__0"
    // InternalSM2.g:5308:1: rule__User__Group_16__0 : rule__User__Group_16__0__Impl rule__User__Group_16__1 ;
    public final void rule__User__Group_16__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5312:1: ( rule__User__Group_16__0__Impl rule__User__Group_16__1 )
            // InternalSM2.g:5313:2: rule__User__Group_16__0__Impl rule__User__Group_16__1
            {
            pushFollow(FOLLOW_41);
            rule__User__Group_16__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_16__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__0"


    // $ANTLR start "rule__User__Group_16__0__Impl"
    // InternalSM2.g:5320:1: rule__User__Group_16__0__Impl : ( '=' ) ;
    public final void rule__User__Group_16__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5324:1: ( ( '=' ) )
            // InternalSM2.g:5325:1: ( '=' )
            {
            // InternalSM2.g:5325:1: ( '=' )
            // InternalSM2.g:5326:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_16_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_16_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__0__Impl"


    // $ANTLR start "rule__User__Group_16__1"
    // InternalSM2.g:5335:1: rule__User__Group_16__1 : rule__User__Group_16__1__Impl ;
    public final void rule__User__Group_16__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5339:1: ( rule__User__Group_16__1__Impl )
            // InternalSM2.g:5340:2: rule__User__Group_16__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_16__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__1"


    // $ANTLR start "rule__User__Group_16__1__Impl"
    // InternalSM2.g:5346:1: rule__User__Group_16__1__Impl : ( RULE_STRING ) ;
    public final void rule__User__Group_16__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5350:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5351:1: ( RULE_STRING )
            {
            // InternalSM2.g:5351:1: ( RULE_STRING )
            // InternalSM2.g:5352:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSTRINGTerminalRuleCall_16_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_16__1__Impl"


    // $ANTLR start "rule__User__Group_21__0"
    // InternalSM2.g:5362:1: rule__User__Group_21__0 : rule__User__Group_21__0__Impl rule__User__Group_21__1 ;
    public final void rule__User__Group_21__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5366:1: ( rule__User__Group_21__0__Impl rule__User__Group_21__1 )
            // InternalSM2.g:5367:2: rule__User__Group_21__0__Impl rule__User__Group_21__1
            {
            pushFollow(FOLLOW_52);
            rule__User__Group_21__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_21__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__0"


    // $ANTLR start "rule__User__Group_21__0__Impl"
    // InternalSM2.g:5374:1: rule__User__Group_21__0__Impl : ( '=' ) ;
    public final void rule__User__Group_21__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5378:1: ( ( '=' ) )
            // InternalSM2.g:5379:1: ( '=' )
            {
            // InternalSM2.g:5379:1: ( '=' )
            // InternalSM2.g:5380:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_21_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_21_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__0__Impl"


    // $ANTLR start "rule__User__Group_21__1"
    // InternalSM2.g:5389:1: rule__User__Group_21__1 : rule__User__Group_21__1__Impl ;
    public final void rule__User__Group_21__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5393:1: ( rule__User__Group_21__1__Impl )
            // InternalSM2.g:5394:2: rule__User__Group_21__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_21__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__1"


    // $ANTLR start "rule__User__Group_21__1__Impl"
    // InternalSM2.g:5400:1: rule__User__Group_21__1__Impl : ( RULE_EMAIL ) ;
    public final void rule__User__Group_21__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5404:1: ( ( RULE_EMAIL ) )
            // InternalSM2.g:5405:1: ( RULE_EMAIL )
            {
            // InternalSM2.g:5405:1: ( RULE_EMAIL )
            // InternalSM2.g:5406:2: RULE_EMAIL
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1()); 
            }
            match(input,RULE_EMAIL,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEMAILTerminalRuleCall_21_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_21__1__Impl"


    // $ANTLR start "rule__User__Group_26_0__0"
    // InternalSM2.g:5416:1: rule__User__Group_26_0__0 : rule__User__Group_26_0__0__Impl rule__User__Group_26_0__1 ;
    public final void rule__User__Group_26_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5420:1: ( rule__User__Group_26_0__0__Impl rule__User__Group_26_0__1 )
            // InternalSM2.g:5421:2: rule__User__Group_26_0__0__Impl rule__User__Group_26_0__1
            {
            pushFollow(FOLLOW_53);
            rule__User__Group_26_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__User__Group_26_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26_0__0"


    // $ANTLR start "rule__User__Group_26_0__0__Impl"
    // InternalSM2.g:5428:1: rule__User__Group_26_0__0__Impl : ( '=' ) ;
    public final void rule__User__Group_26_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5432:1: ( ( '=' ) )
            // InternalSM2.g:5433:1: ( '=' )
            {
            // InternalSM2.g:5433:1: ( '=' )
            // InternalSM2.g:5434:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEqualsSignKeyword_26_0_0()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEqualsSignKeyword_26_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26_0__0__Impl"


    // $ANTLR start "rule__User__Group_26_0__1"
    // InternalSM2.g:5443:1: rule__User__Group_26_0__1 : rule__User__Group_26_0__1__Impl ;
    public final void rule__User__Group_26_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5447:1: ( rule__User__Group_26_0__1__Impl )
            // InternalSM2.g:5448:2: rule__User__Group_26_0__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__User__Group_26_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26_0__1"


    // $ANTLR start "rule__User__Group_26_0__1__Impl"
    // InternalSM2.g:5454:1: rule__User__Group_26_0__1__Impl : ( ( rule__User__AmountAssignment_26_0_1 ) ) ;
    public final void rule__User__Group_26_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5458:1: ( ( ( rule__User__AmountAssignment_26_0_1 ) ) )
            // InternalSM2.g:5459:1: ( ( rule__User__AmountAssignment_26_0_1 ) )
            {
            // InternalSM2.g:5459:1: ( ( rule__User__AmountAssignment_26_0_1 ) )
            // InternalSM2.g:5460:2: ( rule__User__AmountAssignment_26_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAmountAssignment_26_0_1()); 
            }
            // InternalSM2.g:5461:2: ( rule__User__AmountAssignment_26_0_1 )
            // InternalSM2.g:5461:3: rule__User__AmountAssignment_26_0_1
            {
            pushFollow(FOLLOW_2);
            rule__User__AmountAssignment_26_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAmountAssignment_26_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__Group_26_0__1__Impl"


    // $ANTLR start "rule__Enum__Group__0"
    // InternalSM2.g:5470:1: rule__Enum__Group__0 : rule__Enum__Group__0__Impl rule__Enum__Group__1 ;
    public final void rule__Enum__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5474:1: ( rule__Enum__Group__0__Impl rule__Enum__Group__1 )
            // InternalSM2.g:5475:2: rule__Enum__Group__0__Impl rule__Enum__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__Enum__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0"


    // $ANTLR start "rule__Enum__Group__0__Impl"
    // InternalSM2.g:5482:1: rule__Enum__Group__0__Impl : ( 'enum' ) ;
    public final void rule__Enum__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5486:1: ( ( 'enum' ) )
            // InternalSM2.g:5487:1: ( 'enum' )
            {
            // InternalSM2.g:5487:1: ( 'enum' )
            // InternalSM2.g:5488:2: 'enum'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            }
            match(input,76,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getEnumKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__0__Impl"


    // $ANTLR start "rule__Enum__Group__1"
    // InternalSM2.g:5497:1: rule__Enum__Group__1 : rule__Enum__Group__1__Impl rule__Enum__Group__2 ;
    public final void rule__Enum__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5501:1: ( rule__Enum__Group__1__Impl rule__Enum__Group__2 )
            // InternalSM2.g:5502:2: rule__Enum__Group__1__Impl rule__Enum__Group__2
            {
            pushFollow(FOLLOW_22);
            rule__Enum__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1"


    // $ANTLR start "rule__Enum__Group__1__Impl"
    // InternalSM2.g:5509:1: rule__Enum__Group__1__Impl : ( ( rule__Enum__NameEnumAssignment_1 ) ) ;
    public final void rule__Enum__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5513:1: ( ( ( rule__Enum__NameEnumAssignment_1 ) ) )
            // InternalSM2.g:5514:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            {
            // InternalSM2.g:5514:1: ( ( rule__Enum__NameEnumAssignment_1 ) )
            // InternalSM2.g:5515:2: ( rule__Enum__NameEnumAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            }
            // InternalSM2.g:5516:2: ( rule__Enum__NameEnumAssignment_1 )
            // InternalSM2.g:5516:3: rule__Enum__NameEnumAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Enum__NameEnumAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getNameEnumAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__1__Impl"


    // $ANTLR start "rule__Enum__Group__2"
    // InternalSM2.g:5524:1: rule__Enum__Group__2 : rule__Enum__Group__2__Impl rule__Enum__Group__3 ;
    public final void rule__Enum__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5528:1: ( rule__Enum__Group__2__Impl rule__Enum__Group__3 )
            // InternalSM2.g:5529:2: rule__Enum__Group__2__Impl rule__Enum__Group__3
            {
            pushFollow(FOLLOW_41);
            rule__Enum__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2"


    // $ANTLR start "rule__Enum__Group__2__Impl"
    // InternalSM2.g:5536:1: rule__Enum__Group__2__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Enum__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5540:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:5541:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:5541:1: ( RULE_OPENKEY )
            // InternalSM2.g:5542:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getOPENKEYTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__2__Impl"


    // $ANTLR start "rule__Enum__Group__3"
    // InternalSM2.g:5551:1: rule__Enum__Group__3 : rule__Enum__Group__3__Impl rule__Enum__Group__4 ;
    public final void rule__Enum__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5555:1: ( rule__Enum__Group__3__Impl rule__Enum__Group__4 )
            // InternalSM2.g:5556:2: rule__Enum__Group__3__Impl rule__Enum__Group__4
            {
            pushFollow(FOLLOW_28);
            rule__Enum__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3"


    // $ANTLR start "rule__Enum__Group__3__Impl"
    // InternalSM2.g:5563:1: rule__Enum__Group__3__Impl : ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) ) ;
    public final void rule__Enum__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5567:1: ( ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) ) )
            // InternalSM2.g:5568:1: ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) )
            {
            // InternalSM2.g:5568:1: ( ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* ) )
            // InternalSM2.g:5569:2: ( ( rule__Enum__Group_3__0 ) ) ( ( rule__Enum__Group_3__0 )* )
            {
            // InternalSM2.g:5569:2: ( ( rule__Enum__Group_3__0 ) )
            // InternalSM2.g:5570:3: ( rule__Enum__Group_3__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup_3()); 
            }
            // InternalSM2.g:5571:3: ( rule__Enum__Group_3__0 )
            // InternalSM2.g:5571:4: rule__Enum__Group_3__0
            {
            pushFollow(FOLLOW_54);
            rule__Enum__Group_3__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup_3()); 
            }

            }

            // InternalSM2.g:5574:2: ( ( rule__Enum__Group_3__0 )* )
            // InternalSM2.g:5575:3: ( rule__Enum__Group_3__0 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getGroup_3()); 
            }
            // InternalSM2.g:5576:3: ( rule__Enum__Group_3__0 )*
            loop64:
            do {
                int alt64=2;
                int LA64_0 = input.LA(1);

                if ( (LA64_0==RULE_STRING) ) {
                    alt64=1;
                }


                switch (alt64) {
            	case 1 :
            	    // InternalSM2.g:5576:4: rule__Enum__Group_3__0
            	    {
            	    pushFollow(FOLLOW_54);
            	    rule__Enum__Group_3__0();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop64;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getGroup_3()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__3__Impl"


    // $ANTLR start "rule__Enum__Group__4"
    // InternalSM2.g:5585:1: rule__Enum__Group__4 : rule__Enum__Group__4__Impl rule__Enum__Group__5 ;
    public final void rule__Enum__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5589:1: ( rule__Enum__Group__4__Impl rule__Enum__Group__5 )
            // InternalSM2.g:5590:2: rule__Enum__Group__4__Impl rule__Enum__Group__5
            {
            pushFollow(FOLLOW_5);
            rule__Enum__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4"


    // $ANTLR start "rule__Enum__Group__4__Impl"
    // InternalSM2.g:5597:1: rule__Enum__Group__4__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Enum__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5601:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:5602:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:5602:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:5603:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getCLOSEKEYTerminalRuleCall_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__4__Impl"


    // $ANTLR start "rule__Enum__Group__5"
    // InternalSM2.g:5612:1: rule__Enum__Group__5 : rule__Enum__Group__5__Impl rule__Enum__Group__6 ;
    public final void rule__Enum__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5616:1: ( rule__Enum__Group__5__Impl rule__Enum__Group__6 )
            // InternalSM2.g:5617:2: rule__Enum__Group__5__Impl rule__Enum__Group__6
            {
            pushFollow(FOLLOW_21);
            rule__Enum__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5"


    // $ANTLR start "rule__Enum__Group__5__Impl"
    // InternalSM2.g:5624:1: rule__Enum__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Enum__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5628:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5629:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5629:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5630:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__5__Impl"


    // $ANTLR start "rule__Enum__Group__6"
    // InternalSM2.g:5639:1: rule__Enum__Group__6 : rule__Enum__Group__6__Impl ;
    public final void rule__Enum__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5643:1: ( rule__Enum__Group__6__Impl )
            // InternalSM2.g:5644:2: rule__Enum__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6"


    // $ANTLR start "rule__Enum__Group__6__Impl"
    // InternalSM2.g:5650:1: rule__Enum__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Enum__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5654:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5655:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5655:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5656:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:5657:2: ( RULE_EOLINE )?
            int alt65=2;
            alt65 = dfa65.predict(input);
            switch (alt65) {
                case 1 :
                    // InternalSM2.g:5657:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group__6__Impl"


    // $ANTLR start "rule__Enum__Group_3__0"
    // InternalSM2.g:5666:1: rule__Enum__Group_3__0 : rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1 ;
    public final void rule__Enum__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5670:1: ( rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1 )
            // InternalSM2.g:5671:2: rule__Enum__Group_3__0__Impl rule__Enum__Group_3__1
            {
            pushFollow(FOLLOW_55);
            rule__Enum__Group_3__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Enum__Group_3__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__0"


    // $ANTLR start "rule__Enum__Group_3__0__Impl"
    // InternalSM2.g:5678:1: rule__Enum__Group_3__0__Impl : ( RULE_STRING ) ;
    public final void rule__Enum__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5682:1: ( ( RULE_STRING ) )
            // InternalSM2.g:5683:1: ( RULE_STRING )
            {
            // InternalSM2.g:5683:1: ( RULE_STRING )
            // InternalSM2.g:5684:2: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getSTRINGTerminalRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__0__Impl"


    // $ANTLR start "rule__Enum__Group_3__1"
    // InternalSM2.g:5693:1: rule__Enum__Group_3__1 : rule__Enum__Group_3__1__Impl ;
    public final void rule__Enum__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5697:1: ( rule__Enum__Group_3__1__Impl )
            // InternalSM2.g:5698:2: rule__Enum__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Enum__Group_3__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__1"


    // $ANTLR start "rule__Enum__Group_3__1__Impl"
    // InternalSM2.g:5704:1: rule__Enum__Group_3__1__Impl : ( ( RULE_COMMA )? ) ;
    public final void rule__Enum__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5708:1: ( ( ( RULE_COMMA )? ) )
            // InternalSM2.g:5709:1: ( ( RULE_COMMA )? )
            {
            // InternalSM2.g:5709:1: ( ( RULE_COMMA )? )
            // InternalSM2.g:5710:2: ( RULE_COMMA )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1()); 
            }
            // InternalSM2.g:5711:2: ( RULE_COMMA )?
            int alt66=2;
            int LA66_0 = input.LA(1);

            if ( (LA66_0==RULE_COMMA) ) {
                alt66=1;
            }
            switch (alt66) {
                case 1 :
                    // InternalSM2.g:5711:3: RULE_COMMA
                    {
                    match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getCOMMATerminalRuleCall_3_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__Group_3__1__Impl"


    // $ANTLR start "rule__Property__Group__0"
    // InternalSM2.g:5720:1: rule__Property__Group__0 : rule__Property__Group__0__Impl rule__Property__Group__1 ;
    public final void rule__Property__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5724:1: ( rule__Property__Group__0__Impl rule__Property__Group__1 )
            // InternalSM2.g:5725:2: rule__Property__Group__0__Impl rule__Property__Group__1
            {
            pushFollow(FOLLOW_42);
            rule__Property__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0"


    // $ANTLR start "rule__Property__Group__0__Impl"
    // InternalSM2.g:5732:1: rule__Property__Group__0__Impl : ( ( rule__Property__TypeAssignment_0 ) ) ;
    public final void rule__Property__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5736:1: ( ( ( rule__Property__TypeAssignment_0 ) ) )
            // InternalSM2.g:5737:1: ( ( rule__Property__TypeAssignment_0 ) )
            {
            // InternalSM2.g:5737:1: ( ( rule__Property__TypeAssignment_0 ) )
            // InternalSM2.g:5738:2: ( rule__Property__TypeAssignment_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            }
            // InternalSM2.g:5739:2: ( rule__Property__TypeAssignment_0 )
            // InternalSM2.g:5739:3: rule__Property__TypeAssignment_0
            {
            pushFollow(FOLLOW_2);
            rule__Property__TypeAssignment_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getTypeAssignment_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__0__Impl"


    // $ANTLR start "rule__Property__Group__1"
    // InternalSM2.g:5747:1: rule__Property__Group__1 : rule__Property__Group__1__Impl rule__Property__Group__2 ;
    public final void rule__Property__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5751:1: ( rule__Property__Group__1__Impl rule__Property__Group__2 )
            // InternalSM2.g:5752:2: rule__Property__Group__1__Impl rule__Property__Group__2
            {
            pushFollow(FOLLOW_42);
            rule__Property__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1"


    // $ANTLR start "rule__Property__Group__1__Impl"
    // InternalSM2.g:5759:1: rule__Property__Group__1__Impl : ( ( rule__Property__VisibilityAssignment_1 )? ) ;
    public final void rule__Property__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5763:1: ( ( ( rule__Property__VisibilityAssignment_1 )? ) )
            // InternalSM2.g:5764:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            {
            // InternalSM2.g:5764:1: ( ( rule__Property__VisibilityAssignment_1 )? )
            // InternalSM2.g:5765:2: ( rule__Property__VisibilityAssignment_1 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            }
            // InternalSM2.g:5766:2: ( rule__Property__VisibilityAssignment_1 )?
            int alt67=2;
            int LA67_0 = input.LA(1);

            if ( ((LA67_0>=32 && LA67_0<=33)||(LA67_0>=46 && LA67_0<=47)) ) {
                alt67=1;
            }
            switch (alt67) {
                case 1 :
                    // InternalSM2.g:5766:3: rule__Property__VisibilityAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__VisibilityAssignment_1();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getVisibilityAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__1__Impl"


    // $ANTLR start "rule__Property__Group__2"
    // InternalSM2.g:5774:1: rule__Property__Group__2 : rule__Property__Group__2__Impl rule__Property__Group__3 ;
    public final void rule__Property__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5778:1: ( rule__Property__Group__2__Impl rule__Property__Group__3 )
            // InternalSM2.g:5779:2: rule__Property__Group__2__Impl rule__Property__Group__3
            {
            pushFollow(FOLLOW_56);
            rule__Property__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2"


    // $ANTLR start "rule__Property__Group__2__Impl"
    // InternalSM2.g:5786:1: rule__Property__Group__2__Impl : ( ( rule__Property__NamePropertyAssignment_2 ) ) ;
    public final void rule__Property__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5790:1: ( ( ( rule__Property__NamePropertyAssignment_2 ) ) )
            // InternalSM2.g:5791:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            {
            // InternalSM2.g:5791:1: ( ( rule__Property__NamePropertyAssignment_2 ) )
            // InternalSM2.g:5792:2: ( rule__Property__NamePropertyAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            }
            // InternalSM2.g:5793:2: ( rule__Property__NamePropertyAssignment_2 )
            // InternalSM2.g:5793:3: rule__Property__NamePropertyAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Property__NamePropertyAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getNamePropertyAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__2__Impl"


    // $ANTLR start "rule__Property__Group__3"
    // InternalSM2.g:5801:1: rule__Property__Group__3 : rule__Property__Group__3__Impl rule__Property__Group__4 ;
    public final void rule__Property__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5805:1: ( rule__Property__Group__3__Impl rule__Property__Group__4 )
            // InternalSM2.g:5806:2: rule__Property__Group__3__Impl rule__Property__Group__4
            {
            pushFollow(FOLLOW_57);
            rule__Property__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3"


    // $ANTLR start "rule__Property__Group__3__Impl"
    // InternalSM2.g:5813:1: rule__Property__Group__3__Impl : ( '=' ) ;
    public final void rule__Property__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5817:1: ( ( '=' ) )
            // InternalSM2.g:5818:1: ( '=' )
            {
            // InternalSM2.g:5818:1: ( '=' )
            // InternalSM2.g:5819:2: '='
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            }
            match(input,68,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getEqualsSignKeyword_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__3__Impl"


    // $ANTLR start "rule__Property__Group__4"
    // InternalSM2.g:5828:1: rule__Property__Group__4 : rule__Property__Group__4__Impl rule__Property__Group__5 ;
    public final void rule__Property__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5832:1: ( rule__Property__Group__4__Impl rule__Property__Group__5 )
            // InternalSM2.g:5833:2: rule__Property__Group__4__Impl rule__Property__Group__5
            {
            pushFollow(FOLLOW_57);
            rule__Property__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4"


    // $ANTLR start "rule__Property__Group__4__Impl"
    // InternalSM2.g:5840:1: rule__Property__Group__4__Impl : ( ( rule__Property__Alternatives_4 )? ) ;
    public final void rule__Property__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5844:1: ( ( ( rule__Property__Alternatives_4 )? ) )
            // InternalSM2.g:5845:1: ( ( rule__Property__Alternatives_4 )? )
            {
            // InternalSM2.g:5845:1: ( ( rule__Property__Alternatives_4 )? )
            // InternalSM2.g:5846:2: ( rule__Property__Alternatives_4 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            }
            // InternalSM2.g:5847:2: ( rule__Property__Alternatives_4 )?
            int alt68=2;
            int LA68_0 = input.LA(1);

            if ( ((LA68_0>=RULE_INTEGER && LA68_0<=RULE_STRING)) ) {
                alt68=1;
            }
            switch (alt68) {
                case 1 :
                    // InternalSM2.g:5847:3: rule__Property__Alternatives_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Property__Alternatives_4();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getAlternatives_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__4__Impl"


    // $ANTLR start "rule__Property__Group__5"
    // InternalSM2.g:5855:1: rule__Property__Group__5 : rule__Property__Group__5__Impl rule__Property__Group__6 ;
    public final void rule__Property__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5859:1: ( rule__Property__Group__5__Impl rule__Property__Group__6 )
            // InternalSM2.g:5860:2: rule__Property__Group__5__Impl rule__Property__Group__6
            {
            pushFollow(FOLLOW_21);
            rule__Property__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Property__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5"


    // $ANTLR start "rule__Property__Group__5__Impl"
    // InternalSM2.g:5867:1: rule__Property__Group__5__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Property__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5871:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:5872:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:5872:1: ( RULE_SEMICOLON )
            // InternalSM2.g:5873:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getSEMICOLONTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__5__Impl"


    // $ANTLR start "rule__Property__Group__6"
    // InternalSM2.g:5882:1: rule__Property__Group__6 : rule__Property__Group__6__Impl ;
    public final void rule__Property__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5886:1: ( rule__Property__Group__6__Impl )
            // InternalSM2.g:5887:2: rule__Property__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Property__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6"


    // $ANTLR start "rule__Property__Group__6__Impl"
    // InternalSM2.g:5893:1: rule__Property__Group__6__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Property__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5897:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:5898:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:5898:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:5899:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            }
            // InternalSM2.g:5900:2: ( RULE_EOLINE )?
            int alt69=2;
            int LA69_0 = input.LA(1);

            if ( (LA69_0==RULE_EOLINE) ) {
                alt69=1;
            }
            switch (alt69) {
                case 1 :
                    // InternalSM2.g:5900:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getEOLINETerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__Group__6__Impl"


    // $ANTLR start "rule__InputParam__Group__0"
    // InternalSM2.g:5909:1: rule__InputParam__Group__0 : rule__InputParam__Group__0__Impl rule__InputParam__Group__1 ;
    public final void rule__InputParam__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5913:1: ( rule__InputParam__Group__0__Impl rule__InputParam__Group__1 )
            // InternalSM2.g:5914:2: rule__InputParam__Group__0__Impl rule__InputParam__Group__1
            {
            pushFollow(FOLLOW_55);
            rule__InputParam__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0"


    // $ANTLR start "rule__InputParam__Group__0__Impl"
    // InternalSM2.g:5921:1: rule__InputParam__Group__0__Impl : ( ( rule__InputParam__Group_0__0 ) ) ;
    public final void rule__InputParam__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5925:1: ( ( ( rule__InputParam__Group_0__0 ) ) )
            // InternalSM2.g:5926:1: ( ( rule__InputParam__Group_0__0 ) )
            {
            // InternalSM2.g:5926:1: ( ( rule__InputParam__Group_0__0 ) )
            // InternalSM2.g:5927:2: ( rule__InputParam__Group_0__0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getGroup_0()); 
            }
            // InternalSM2.g:5928:2: ( rule__InputParam__Group_0__0 )
            // InternalSM2.g:5928:3: rule__InputParam__Group_0__0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getGroup_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__0__Impl"


    // $ANTLR start "rule__InputParam__Group__1"
    // InternalSM2.g:5936:1: rule__InputParam__Group__1 : rule__InputParam__Group__1__Impl ;
    public final void rule__InputParam__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5940:1: ( rule__InputParam__Group__1__Impl )
            // InternalSM2.g:5941:2: rule__InputParam__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1"


    // $ANTLR start "rule__InputParam__Group__1__Impl"
    // InternalSM2.g:5947:1: rule__InputParam__Group__1__Impl : ( ( rule__InputParam__CommaAssignment_1 )? ) ;
    public final void rule__InputParam__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5951:1: ( ( ( rule__InputParam__CommaAssignment_1 )? ) )
            // InternalSM2.g:5952:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            {
            // InternalSM2.g:5952:1: ( ( rule__InputParam__CommaAssignment_1 )? )
            // InternalSM2.g:5953:2: ( rule__InputParam__CommaAssignment_1 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 
            }
            // InternalSM2.g:5954:2: ( rule__InputParam__CommaAssignment_1 )?
            int alt70=2;
            int LA70_0 = input.LA(1);

            if ( (LA70_0==RULE_COMMA) ) {
                alt70=1;
            }
            switch (alt70) {
                case 1 :
                    // InternalSM2.g:5954:3: rule__InputParam__CommaAssignment_1
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__CommaAssignment_1();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getCommaAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__0"
    // InternalSM2.g:5963:1: rule__InputParam__Group_0__0 : rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 ;
    public final void rule__InputParam__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5967:1: ( rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1 )
            // InternalSM2.g:5968:2: rule__InputParam__Group_0__0__Impl rule__InputParam__Group_0__1
            {
            pushFollow(FOLLOW_58);
            rule__InputParam__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0"


    // $ANTLR start "rule__InputParam__Group_0__0__Impl"
    // InternalSM2.g:5975:1: rule__InputParam__Group_0__0__Impl : ( ( rule__InputParam__TypeAssignment_0_0 ) ) ;
    public final void rule__InputParam__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5979:1: ( ( ( rule__InputParam__TypeAssignment_0_0 ) ) )
            // InternalSM2.g:5980:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            {
            // InternalSM2.g:5980:1: ( ( rule__InputParam__TypeAssignment_0_0 ) )
            // InternalSM2.g:5981:2: ( rule__InputParam__TypeAssignment_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            }
            // InternalSM2.g:5982:2: ( rule__InputParam__TypeAssignment_0_0 )
            // InternalSM2.g:5982:3: rule__InputParam__TypeAssignment_0_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__TypeAssignment_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getTypeAssignment_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0__1"
    // InternalSM2.g:5990:1: rule__InputParam__Group_0__1 : rule__InputParam__Group_0__1__Impl rule__InputParam__Group_0__2 ;
    public final void rule__InputParam__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:5994:1: ( rule__InputParam__Group_0__1__Impl rule__InputParam__Group_0__2 )
            // InternalSM2.g:5995:2: rule__InputParam__Group_0__1__Impl rule__InputParam__Group_0__2
            {
            pushFollow(FOLLOW_58);
            rule__InputParam__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1"


    // $ANTLR start "rule__InputParam__Group_0__1__Impl"
    // InternalSM2.g:6002:1: rule__InputParam__Group_0__1__Impl : ( ( rule__InputParam__Group_0_1__0 )? ) ;
    public final void rule__InputParam__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6006:1: ( ( ( rule__InputParam__Group_0_1__0 )? ) )
            // InternalSM2.g:6007:1: ( ( rule__InputParam__Group_0_1__0 )? )
            {
            // InternalSM2.g:6007:1: ( ( rule__InputParam__Group_0_1__0 )? )
            // InternalSM2.g:6008:2: ( rule__InputParam__Group_0_1__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getGroup_0_1()); 
            }
            // InternalSM2.g:6009:2: ( rule__InputParam__Group_0_1__0 )?
            int alt71=2;
            int LA71_0 = input.LA(1);

            if ( (LA71_0==85) ) {
                alt71=1;
            }
            switch (alt71) {
                case 1 :
                    // InternalSM2.g:6009:3: rule__InputParam__Group_0_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__Group_0_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getGroup_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__1__Impl"


    // $ANTLR start "rule__InputParam__Group_0__2"
    // InternalSM2.g:6017:1: rule__InputParam__Group_0__2 : rule__InputParam__Group_0__2__Impl rule__InputParam__Group_0__3 ;
    public final void rule__InputParam__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6021:1: ( rule__InputParam__Group_0__2__Impl rule__InputParam__Group_0__3 )
            // InternalSM2.g:6022:2: rule__InputParam__Group_0__2__Impl rule__InputParam__Group_0__3
            {
            pushFollow(FOLLOW_58);
            rule__InputParam__Group_0__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__2"


    // $ANTLR start "rule__InputParam__Group_0__2__Impl"
    // InternalSM2.g:6029:1: rule__InputParam__Group_0__2__Impl : ( ( rule__InputParam__Alternatives_0_2 )? ) ;
    public final void rule__InputParam__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6033:1: ( ( ( rule__InputParam__Alternatives_0_2 )? ) )
            // InternalSM2.g:6034:1: ( ( rule__InputParam__Alternatives_0_2 )? )
            {
            // InternalSM2.g:6034:1: ( ( rule__InputParam__Alternatives_0_2 )? )
            // InternalSM2.g:6035:2: ( rule__InputParam__Alternatives_0_2 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getAlternatives_0_2()); 
            }
            // InternalSM2.g:6036:2: ( rule__InputParam__Alternatives_0_2 )?
            int alt72=2;
            int LA72_0 = input.LA(1);

            if ( (LA72_0==34||LA72_0==86) ) {
                alt72=1;
            }
            switch (alt72) {
                case 1 :
                    // InternalSM2.g:6036:3: rule__InputParam__Alternatives_0_2
                    {
                    pushFollow(FOLLOW_2);
                    rule__InputParam__Alternatives_0_2();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getAlternatives_0_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__2__Impl"


    // $ANTLR start "rule__InputParam__Group_0__3"
    // InternalSM2.g:6044:1: rule__InputParam__Group_0__3 : rule__InputParam__Group_0__3__Impl ;
    public final void rule__InputParam__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6048:1: ( rule__InputParam__Group_0__3__Impl )
            // InternalSM2.g:6049:2: rule__InputParam__Group_0__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0__3__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__3"


    // $ANTLR start "rule__InputParam__Group_0__3__Impl"
    // InternalSM2.g:6055:1: rule__InputParam__Group_0__3__Impl : ( ( rule__InputParam__NameParamAssignment_0_3 ) ) ;
    public final void rule__InputParam__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6059:1: ( ( ( rule__InputParam__NameParamAssignment_0_3 ) ) )
            // InternalSM2.g:6060:1: ( ( rule__InputParam__NameParamAssignment_0_3 ) )
            {
            // InternalSM2.g:6060:1: ( ( rule__InputParam__NameParamAssignment_0_3 ) )
            // InternalSM2.g:6061:2: ( rule__InputParam__NameParamAssignment_0_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNameParamAssignment_0_3()); 
            }
            // InternalSM2.g:6062:2: ( rule__InputParam__NameParamAssignment_0_3 )
            // InternalSM2.g:6062:3: rule__InputParam__NameParamAssignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__NameParamAssignment_0_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNameParamAssignment_0_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0__3__Impl"


    // $ANTLR start "rule__InputParam__Group_0_1__0"
    // InternalSM2.g:6071:1: rule__InputParam__Group_0_1__0 : rule__InputParam__Group_0_1__0__Impl rule__InputParam__Group_0_1__1 ;
    public final void rule__InputParam__Group_0_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6075:1: ( rule__InputParam__Group_0_1__0__Impl rule__InputParam__Group_0_1__1 )
            // InternalSM2.g:6076:2: rule__InputParam__Group_0_1__0__Impl rule__InputParam__Group_0_1__1
            {
            pushFollow(FOLLOW_59);
            rule__InputParam__Group_0_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0_1__0"


    // $ANTLR start "rule__InputParam__Group_0_1__0__Impl"
    // InternalSM2.g:6083:1: rule__InputParam__Group_0_1__0__Impl : ( ( rule__InputParam__IsArrayAssignment_0_1_0 ) ) ;
    public final void rule__InputParam__Group_0_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6087:1: ( ( ( rule__InputParam__IsArrayAssignment_0_1_0 ) ) )
            // InternalSM2.g:6088:1: ( ( rule__InputParam__IsArrayAssignment_0_1_0 ) )
            {
            // InternalSM2.g:6088:1: ( ( rule__InputParam__IsArrayAssignment_0_1_0 ) )
            // InternalSM2.g:6089:2: ( rule__InputParam__IsArrayAssignment_0_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getIsArrayAssignment_0_1_0()); 
            }
            // InternalSM2.g:6090:2: ( rule__InputParam__IsArrayAssignment_0_1_0 )
            // InternalSM2.g:6090:3: rule__InputParam__IsArrayAssignment_0_1_0
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__IsArrayAssignment_0_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getIsArrayAssignment_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0_1__0__Impl"


    // $ANTLR start "rule__InputParam__Group_0_1__1"
    // InternalSM2.g:6098:1: rule__InputParam__Group_0_1__1 : rule__InputParam__Group_0_1__1__Impl ;
    public final void rule__InputParam__Group_0_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6102:1: ( rule__InputParam__Group_0_1__1__Impl )
            // InternalSM2.g:6103:2: rule__InputParam__Group_0_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__InputParam__Group_0_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0_1__1"


    // $ANTLR start "rule__InputParam__Group_0_1__1__Impl"
    // InternalSM2.g:6109:1: rule__InputParam__Group_0_1__1__Impl : ( ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )* ) ;
    public final void rule__InputParam__Group_0_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6113:1: ( ( ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )* ) )
            // InternalSM2.g:6114:1: ( ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )* )
            {
            // InternalSM2.g:6114:1: ( ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )* )
            // InternalSM2.g:6115:2: ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayAssignment_0_1_1()); 
            }
            // InternalSM2.g:6116:2: ( rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 )*
            loop73:
            do {
                int alt73=2;
                int LA73_0 = input.LA(1);

                if ( (LA73_0==85) ) {
                    alt73=1;
                }


                switch (alt73) {
            	case 1 :
            	    // InternalSM2.g:6116:3: rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1
            	    {
            	    pushFollow(FOLLOW_60);
            	    rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop73;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayAssignment_0_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__Group_0_1__1__Impl"


    // $ANTLR start "rule__Restriction__Group__0"
    // InternalSM2.g:6125:1: rule__Restriction__Group__0 : rule__Restriction__Group__0__Impl rule__Restriction__Group__1 ;
    public final void rule__Restriction__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6129:1: ( rule__Restriction__Group__0__Impl rule__Restriction__Group__1 )
            // InternalSM2.g:6130:2: rule__Restriction__Group__0__Impl rule__Restriction__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__Restriction__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0"


    // $ANTLR start "rule__Restriction__Group__0__Impl"
    // InternalSM2.g:6137:1: rule__Restriction__Group__0__Impl : ( 'require' ) ;
    public final void rule__Restriction__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6141:1: ( ( 'require' ) )
            // InternalSM2.g:6142:1: ( 'require' )
            {
            // InternalSM2.g:6142:1: ( 'require' )
            // InternalSM2.g:6143:2: 'require'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            }
            match(input,77,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getRequireKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__0__Impl"


    // $ANTLR start "rule__Restriction__Group__1"
    // InternalSM2.g:6152:1: rule__Restriction__Group__1 : rule__Restriction__Group__1__Impl rule__Restriction__Group__2 ;
    public final void rule__Restriction__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6156:1: ( rule__Restriction__Group__1__Impl rule__Restriction__Group__2 )
            // InternalSM2.g:6157:2: rule__Restriction__Group__1__Impl rule__Restriction__Group__2
            {
            pushFollow(FOLLOW_34);
            rule__Restriction__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1"


    // $ANTLR start "rule__Restriction__Group__1__Impl"
    // InternalSM2.g:6164:1: rule__Restriction__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__Restriction__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6168:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6169:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6169:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6170:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__1__Impl"


    // $ANTLR start "rule__Restriction__Group__2"
    // InternalSM2.g:6179:1: rule__Restriction__Group__2 : rule__Restriction__Group__2__Impl rule__Restriction__Group__3 ;
    public final void rule__Restriction__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6183:1: ( rule__Restriction__Group__2__Impl rule__Restriction__Group__3 )
            // InternalSM2.g:6184:2: rule__Restriction__Group__2__Impl rule__Restriction__Group__3
            {
            pushFollow(FOLLOW_61);
            rule__Restriction__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2"


    // $ANTLR start "rule__Restriction__Group__2__Impl"
    // InternalSM2.g:6191:1: rule__Restriction__Group__2__Impl : ( ( rule__Restriction__Expr1Assignment_2 ) ) ;
    public final void rule__Restriction__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6195:1: ( ( ( rule__Restriction__Expr1Assignment_2 ) ) )
            // InternalSM2.g:6196:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            {
            // InternalSM2.g:6196:1: ( ( rule__Restriction__Expr1Assignment_2 ) )
            // InternalSM2.g:6197:2: ( rule__Restriction__Expr1Assignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 
            }
            // InternalSM2.g:6198:2: ( rule__Restriction__Expr1Assignment_2 )
            // InternalSM2.g:6198:3: rule__Restriction__Expr1Assignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr1Assignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr1Assignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__2__Impl"


    // $ANTLR start "rule__Restriction__Group__3"
    // InternalSM2.g:6206:1: rule__Restriction__Group__3 : rule__Restriction__Group__3__Impl rule__Restriction__Group__4 ;
    public final void rule__Restriction__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6210:1: ( rule__Restriction__Group__3__Impl rule__Restriction__Group__4 )
            // InternalSM2.g:6211:2: rule__Restriction__Group__3__Impl rule__Restriction__Group__4
            {
            pushFollow(FOLLOW_34);
            rule__Restriction__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3"


    // $ANTLR start "rule__Restriction__Group__3__Impl"
    // InternalSM2.g:6218:1: rule__Restriction__Group__3__Impl : ( ( rule__Restriction__OperatorAssignment_3 ) ) ;
    public final void rule__Restriction__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6222:1: ( ( ( rule__Restriction__OperatorAssignment_3 ) ) )
            // InternalSM2.g:6223:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:6223:1: ( ( rule__Restriction__OperatorAssignment_3 ) )
            // InternalSM2.g:6224:2: ( rule__Restriction__OperatorAssignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            }
            // InternalSM2.g:6225:2: ( rule__Restriction__OperatorAssignment_3 )
            // InternalSM2.g:6225:3: rule__Restriction__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__OperatorAssignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOperatorAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__3__Impl"


    // $ANTLR start "rule__Restriction__Group__4"
    // InternalSM2.g:6233:1: rule__Restriction__Group__4 : rule__Restriction__Group__4__Impl rule__Restriction__Group__5 ;
    public final void rule__Restriction__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6237:1: ( rule__Restriction__Group__4__Impl rule__Restriction__Group__5 )
            // InternalSM2.g:6238:2: rule__Restriction__Group__4__Impl rule__Restriction__Group__5
            {
            pushFollow(FOLLOW_31);
            rule__Restriction__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4"


    // $ANTLR start "rule__Restriction__Group__4__Impl"
    // InternalSM2.g:6245:1: rule__Restriction__Group__4__Impl : ( ( rule__Restriction__Expr2Assignment_4 ) ) ;
    public final void rule__Restriction__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6249:1: ( ( ( rule__Restriction__Expr2Assignment_4 ) ) )
            // InternalSM2.g:6250:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            {
            // InternalSM2.g:6250:1: ( ( rule__Restriction__Expr2Assignment_4 ) )
            // InternalSM2.g:6251:2: ( rule__Restriction__Expr2Assignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 
            }
            // InternalSM2.g:6252:2: ( rule__Restriction__Expr2Assignment_4 )
            // InternalSM2.g:6252:3: rule__Restriction__Expr2Assignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Expr2Assignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr2Assignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__4__Impl"


    // $ANTLR start "rule__Restriction__Group__5"
    // InternalSM2.g:6260:1: rule__Restriction__Group__5 : rule__Restriction__Group__5__Impl rule__Restriction__Group__6 ;
    public final void rule__Restriction__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6264:1: ( rule__Restriction__Group__5__Impl rule__Restriction__Group__6 )
            // InternalSM2.g:6265:2: rule__Restriction__Group__5__Impl rule__Restriction__Group__6
            {
            pushFollow(FOLLOW_5);
            rule__Restriction__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5"


    // $ANTLR start "rule__Restriction__Group__5__Impl"
    // InternalSM2.g:6272:1: rule__Restriction__Group__5__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__Restriction__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6276:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6277:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6277:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6278:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getCLOSEPARENTHESISTerminalRuleCall_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__5__Impl"


    // $ANTLR start "rule__Restriction__Group__6"
    // InternalSM2.g:6287:1: rule__Restriction__Group__6 : rule__Restriction__Group__6__Impl rule__Restriction__Group__7 ;
    public final void rule__Restriction__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6291:1: ( rule__Restriction__Group__6__Impl rule__Restriction__Group__7 )
            // InternalSM2.g:6292:2: rule__Restriction__Group__6__Impl rule__Restriction__Group__7
            {
            pushFollow(FOLLOW_21);
            rule__Restriction__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6"


    // $ANTLR start "rule__Restriction__Group__6__Impl"
    // InternalSM2.g:6299:1: rule__Restriction__Group__6__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__Restriction__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6303:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:6304:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:6304:1: ( RULE_SEMICOLON )
            // InternalSM2.g:6305:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getSEMICOLONTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__6__Impl"


    // $ANTLR start "rule__Restriction__Group__7"
    // InternalSM2.g:6314:1: rule__Restriction__Group__7 : rule__Restriction__Group__7__Impl ;
    public final void rule__Restriction__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6318:1: ( rule__Restriction__Group__7__Impl )
            // InternalSM2.g:6319:2: rule__Restriction__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Restriction__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7"


    // $ANTLR start "rule__Restriction__Group__7__Impl"
    // InternalSM2.g:6325:1: rule__Restriction__Group__7__Impl : ( RULE_EOLINE ) ;
    public final void rule__Restriction__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6329:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6330:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6330:1: ( RULE_EOLINE )
            // InternalSM2.g:6331:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getEOLINETerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__0"
    // InternalSM2.g:6341:1: rule__RestrictionGas__Group__0 : rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 ;
    public final void rule__RestrictionGas__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6345:1: ( rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1 )
            // InternalSM2.g:6346:2: rule__RestrictionGas__Group__0__Impl rule__RestrictionGas__Group__1
            {
            pushFollow(FOLLOW_29);
            rule__RestrictionGas__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0"


    // $ANTLR start "rule__RestrictionGas__Group__0__Impl"
    // InternalSM2.g:6353:1: rule__RestrictionGas__Group__0__Impl : ( 'require' ) ;
    public final void rule__RestrictionGas__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6357:1: ( ( 'require' ) )
            // InternalSM2.g:6358:1: ( 'require' )
            {
            // InternalSM2.g:6358:1: ( 'require' )
            // InternalSM2.g:6359:2: 'require'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            }
            match(input,77,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getRequireKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__0__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__1"
    // InternalSM2.g:6368:1: rule__RestrictionGas__Group__1 : rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 ;
    public final void rule__RestrictionGas__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6372:1: ( rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2 )
            // InternalSM2.g:6373:2: rule__RestrictionGas__Group__1__Impl rule__RestrictionGas__Group__2
            {
            pushFollow(FOLLOW_34);
            rule__RestrictionGas__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1"


    // $ANTLR start "rule__RestrictionGas__Group__1__Impl"
    // InternalSM2.g:6380:1: rule__RestrictionGas__Group__1__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6384:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6385:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6385:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6386:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOPENPARENTHESISTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__1__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__2"
    // InternalSM2.g:6395:1: rule__RestrictionGas__Group__2 : rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 ;
    public final void rule__RestrictionGas__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6399:1: ( rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3 )
            // InternalSM2.g:6400:2: rule__RestrictionGas__Group__2__Impl rule__RestrictionGas__Group__3
            {
            pushFollow(FOLLOW_61);
            rule__RestrictionGas__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2"


    // $ANTLR start "rule__RestrictionGas__Group__2__Impl"
    // InternalSM2.g:6407:1: rule__RestrictionGas__Group__2__Impl : ( ( rule__RestrictionGas__ExprAssignment_2 ) ) ;
    public final void rule__RestrictionGas__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6411:1: ( ( ( rule__RestrictionGas__ExprAssignment_2 ) ) )
            // InternalSM2.g:6412:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            {
            // InternalSM2.g:6412:1: ( ( rule__RestrictionGas__ExprAssignment_2 ) )
            // InternalSM2.g:6413:2: ( rule__RestrictionGas__ExprAssignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            }
            // InternalSM2.g:6414:2: ( rule__RestrictionGas__ExprAssignment_2 )
            // InternalSM2.g:6414:3: rule__RestrictionGas__ExprAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__ExprAssignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getExprAssignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__2__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__3"
    // InternalSM2.g:6422:1: rule__RestrictionGas__Group__3 : rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 ;
    public final void rule__RestrictionGas__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6426:1: ( rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4 )
            // InternalSM2.g:6427:2: rule__RestrictionGas__Group__3__Impl rule__RestrictionGas__Group__4
            {
            pushFollow(FOLLOW_17);
            rule__RestrictionGas__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3"


    // $ANTLR start "rule__RestrictionGas__Group__3__Impl"
    // InternalSM2.g:6434:1: rule__RestrictionGas__Group__3__Impl : ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) ;
    public final void rule__RestrictionGas__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6438:1: ( ( ( rule__RestrictionGas__OperatorAssignment_3 ) ) )
            // InternalSM2.g:6439:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            {
            // InternalSM2.g:6439:1: ( ( rule__RestrictionGas__OperatorAssignment_3 ) )
            // InternalSM2.g:6440:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            }
            // InternalSM2.g:6441:2: ( rule__RestrictionGas__OperatorAssignment_3 )
            // InternalSM2.g:6441:3: rule__RestrictionGas__OperatorAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__OperatorAssignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOperatorAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__3__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__4"
    // InternalSM2.g:6449:1: rule__RestrictionGas__Group__4 : rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 ;
    public final void rule__RestrictionGas__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6453:1: ( rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5 )
            // InternalSM2.g:6454:2: rule__RestrictionGas__Group__4__Impl rule__RestrictionGas__Group__5
            {
            pushFollow(FOLLOW_62);
            rule__RestrictionGas__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4"


    // $ANTLR start "rule__RestrictionGas__Group__4__Impl"
    // InternalSM2.g:6461:1: rule__RestrictionGas__Group__4__Impl : ( ( rule__RestrictionGas__AmountAssignment_4 ) ) ;
    public final void rule__RestrictionGas__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6465:1: ( ( ( rule__RestrictionGas__AmountAssignment_4 ) ) )
            // InternalSM2.g:6466:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            {
            // InternalSM2.g:6466:1: ( ( rule__RestrictionGas__AmountAssignment_4 ) )
            // InternalSM2.g:6467:2: ( rule__RestrictionGas__AmountAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            }
            // InternalSM2.g:6468:2: ( rule__RestrictionGas__AmountAssignment_4 )
            // InternalSM2.g:6468:3: rule__RestrictionGas__AmountAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__AmountAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getAmountAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__4__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__5"
    // InternalSM2.g:6476:1: rule__RestrictionGas__Group__5 : rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 ;
    public final void rule__RestrictionGas__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6480:1: ( rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6 )
            // InternalSM2.g:6481:2: rule__RestrictionGas__Group__5__Impl rule__RestrictionGas__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__RestrictionGas__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5"


    // $ANTLR start "rule__RestrictionGas__Group__5__Impl"
    // InternalSM2.g:6488:1: rule__RestrictionGas__Group__5__Impl : ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) ;
    public final void rule__RestrictionGas__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6492:1: ( ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) ) )
            // InternalSM2.g:6493:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            {
            // InternalSM2.g:6493:1: ( ( rule__RestrictionGas__TypeCoinAssignment_5 ) )
            // InternalSM2.g:6494:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            }
            // InternalSM2.g:6495:2: ( rule__RestrictionGas__TypeCoinAssignment_5 )
            // InternalSM2.g:6495:3: rule__RestrictionGas__TypeCoinAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__TypeCoinAssignment_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getTypeCoinAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__5__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__6"
    // InternalSM2.g:6503:1: rule__RestrictionGas__Group__6 : rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 ;
    public final void rule__RestrictionGas__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6507:1: ( rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7 )
            // InternalSM2.g:6508:2: rule__RestrictionGas__Group__6__Impl rule__RestrictionGas__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__RestrictionGas__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6"


    // $ANTLR start "rule__RestrictionGas__Group__6__Impl"
    // InternalSM2.g:6515:1: rule__RestrictionGas__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__RestrictionGas__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6519:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:6520:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:6520:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:6521:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__6__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__7"
    // InternalSM2.g:6530:1: rule__RestrictionGas__Group__7 : rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 ;
    public final void rule__RestrictionGas__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6534:1: ( rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8 )
            // InternalSM2.g:6535:2: rule__RestrictionGas__Group__7__Impl rule__RestrictionGas__Group__8
            {
            pushFollow(FOLLOW_21);
            rule__RestrictionGas__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7"


    // $ANTLR start "rule__RestrictionGas__Group__7__Impl"
    // InternalSM2.g:6542:1: rule__RestrictionGas__Group__7__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__RestrictionGas__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6546:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:6547:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:6547:1: ( RULE_SEMICOLON )
            // InternalSM2.g:6548:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getSEMICOLONTerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__7__Impl"


    // $ANTLR start "rule__RestrictionGas__Group__8"
    // InternalSM2.g:6557:1: rule__RestrictionGas__Group__8 : rule__RestrictionGas__Group__8__Impl ;
    public final void rule__RestrictionGas__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6561:1: ( rule__RestrictionGas__Group__8__Impl )
            // InternalSM2.g:6562:2: rule__RestrictionGas__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__RestrictionGas__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8"


    // $ANTLR start "rule__RestrictionGas__Group__8__Impl"
    // InternalSM2.g:6568:1: rule__RestrictionGas__Group__8__Impl : ( RULE_EOLINE ) ;
    public final void rule__RestrictionGas__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6572:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6573:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6573:1: ( RULE_EOLINE )
            // InternalSM2.g:6574:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getEOLINETerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__0"
    // InternalSM2.g:6584:1: rule__Clause__Group__0 : rule__Clause__Group__0__Impl rule__Clause__Group__1 ;
    public final void rule__Clause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6588:1: ( rule__Clause__Group__0__Impl rule__Clause__Group__1 )
            // InternalSM2.g:6589:2: rule__Clause__Group__0__Impl rule__Clause__Group__1
            {
            pushFollow(FOLLOW_22);
            rule__Clause__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0"


    // $ANTLR start "rule__Clause__Group__0__Impl"
    // InternalSM2.g:6596:1: rule__Clause__Group__0__Impl : ( ruleHeadClause ) ;
    public final void rule__Clause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6600:1: ( ( ruleHeadClause ) )
            // InternalSM2.g:6601:1: ( ruleHeadClause )
            {
            // InternalSM2.g:6601:1: ( ruleHeadClause )
            // InternalSM2.g:6602:2: ruleHeadClause
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getHeadClauseParserRuleCall_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleHeadClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getHeadClauseParserRuleCall_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__0__Impl"


    // $ANTLR start "rule__Clause__Group__1"
    // InternalSM2.g:6611:1: rule__Clause__Group__1 : rule__Clause__Group__1__Impl rule__Clause__Group__2 ;
    public final void rule__Clause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6615:1: ( rule__Clause__Group__1__Impl rule__Clause__Group__2 )
            // InternalSM2.g:6616:2: rule__Clause__Group__1__Impl rule__Clause__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__Clause__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1"


    // $ANTLR start "rule__Clause__Group__1__Impl"
    // InternalSM2.g:6623:1: rule__Clause__Group__1__Impl : ( RULE_OPENKEY ) ;
    public final void rule__Clause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6627:1: ( ( RULE_OPENKEY ) )
            // InternalSM2.g:6628:1: ( RULE_OPENKEY )
            {
            // InternalSM2.g:6628:1: ( RULE_OPENKEY )
            // InternalSM2.g:6629:2: RULE_OPENKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_1()); 
            }
            match(input,RULE_OPENKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getOPENKEYTerminalRuleCall_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__1__Impl"


    // $ANTLR start "rule__Clause__Group__2"
    // InternalSM2.g:6638:1: rule__Clause__Group__2 : rule__Clause__Group__2__Impl rule__Clause__Group__3 ;
    public final void rule__Clause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6642:1: ( rule__Clause__Group__2__Impl rule__Clause__Group__3 )
            // InternalSM2.g:6643:2: rule__Clause__Group__2__Impl rule__Clause__Group__3
            {
            pushFollow(FOLLOW_63);
            rule__Clause__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2"


    // $ANTLR start "rule__Clause__Group__2__Impl"
    // InternalSM2.g:6650:1: rule__Clause__Group__2__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6654:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6655:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6655:1: ( RULE_EOLINE )
            // InternalSM2.g:6656:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_2()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__2__Impl"


    // $ANTLR start "rule__Clause__Group__3"
    // InternalSM2.g:6665:1: rule__Clause__Group__3 : rule__Clause__Group__3__Impl rule__Clause__Group__4 ;
    public final void rule__Clause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6669:1: ( rule__Clause__Group__3__Impl rule__Clause__Group__4 )
            // InternalSM2.g:6670:2: rule__Clause__Group__3__Impl rule__Clause__Group__4
            {
            pushFollow(FOLLOW_63);
            rule__Clause__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3"


    // $ANTLR start "rule__Clause__Group__3__Impl"
    // InternalSM2.g:6677:1: rule__Clause__Group__3__Impl : ( ( rule__Clause__RestrictionAssignment_3 )? ) ;
    public final void rule__Clause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6681:1: ( ( ( rule__Clause__RestrictionAssignment_3 )? ) )
            // InternalSM2.g:6682:1: ( ( rule__Clause__RestrictionAssignment_3 )? )
            {
            // InternalSM2.g:6682:1: ( ( rule__Clause__RestrictionAssignment_3 )? )
            // InternalSM2.g:6683:2: ( rule__Clause__RestrictionAssignment_3 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionAssignment_3()); 
            }
            // InternalSM2.g:6684:2: ( rule__Clause__RestrictionAssignment_3 )?
            int alt74=2;
            alt74 = dfa74.predict(input);
            switch (alt74) {
                case 1 :
                    // InternalSM2.g:6684:3: rule__Clause__RestrictionAssignment_3
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionAssignment_3();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__3__Impl"


    // $ANTLR start "rule__Clause__Group__4"
    // InternalSM2.g:6692:1: rule__Clause__Group__4 : rule__Clause__Group__4__Impl rule__Clause__Group__5 ;
    public final void rule__Clause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6696:1: ( rule__Clause__Group__4__Impl rule__Clause__Group__5 )
            // InternalSM2.g:6697:2: rule__Clause__Group__4__Impl rule__Clause__Group__5
            {
            pushFollow(FOLLOW_63);
            rule__Clause__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4"


    // $ANTLR start "rule__Clause__Group__4__Impl"
    // InternalSM2.g:6704:1: rule__Clause__Group__4__Impl : ( ( rule__Clause__RestrictionGasAssignment_4 )? ) ;
    public final void rule__Clause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6708:1: ( ( ( rule__Clause__RestrictionGasAssignment_4 )? ) )
            // InternalSM2.g:6709:1: ( ( rule__Clause__RestrictionGasAssignment_4 )? )
            {
            // InternalSM2.g:6709:1: ( ( rule__Clause__RestrictionGasAssignment_4 )? )
            // InternalSM2.g:6710:2: ( rule__Clause__RestrictionGasAssignment_4 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionGasAssignment_4()); 
            }
            // InternalSM2.g:6711:2: ( rule__Clause__RestrictionGasAssignment_4 )?
            int alt75=2;
            int LA75_0 = input.LA(1);

            if ( (LA75_0==77) ) {
                alt75=1;
            }
            switch (alt75) {
                case 1 :
                    // InternalSM2.g:6711:3: rule__Clause__RestrictionGasAssignment_4
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__RestrictionGasAssignment_4();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionGasAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__4__Impl"


    // $ANTLR start "rule__Clause__Group__5"
    // InternalSM2.g:6719:1: rule__Clause__Group__5 : rule__Clause__Group__5__Impl rule__Clause__Group__6 ;
    public final void rule__Clause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6723:1: ( rule__Clause__Group__5__Impl rule__Clause__Group__6 )
            // InternalSM2.g:6724:2: rule__Clause__Group__5__Impl rule__Clause__Group__6
            {
            pushFollow(FOLLOW_63);
            rule__Clause__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5"


    // $ANTLR start "rule__Clause__Group__5__Impl"
    // InternalSM2.g:6731:1: rule__Clause__Group__5__Impl : ( ( rule__Clause__LocalAttributesAssignment_5 )? ) ;
    public final void rule__Clause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6735:1: ( ( ( rule__Clause__LocalAttributesAssignment_5 )? ) )
            // InternalSM2.g:6736:1: ( ( rule__Clause__LocalAttributesAssignment_5 )? )
            {
            // InternalSM2.g:6736:1: ( ( rule__Clause__LocalAttributesAssignment_5 )? )
            // InternalSM2.g:6737:2: ( rule__Clause__LocalAttributesAssignment_5 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getLocalAttributesAssignment_5()); 
            }
            // InternalSM2.g:6738:2: ( rule__Clause__LocalAttributesAssignment_5 )?
            int alt76=2;
            int LA76_0 = input.LA(1);

            if ( (LA76_0==RULE_ID||(LA76_0>=35 && LA76_0<=45)||LA76_0==72||LA76_0==74||LA76_0==76) ) {
                alt76=1;
            }
            switch (alt76) {
                case 1 :
                    // InternalSM2.g:6738:3: rule__Clause__LocalAttributesAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__Clause__LocalAttributesAssignment_5();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getLocalAttributesAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__5__Impl"


    // $ANTLR start "rule__Clause__Group__6"
    // InternalSM2.g:6746:1: rule__Clause__Group__6 : rule__Clause__Group__6__Impl rule__Clause__Group__7 ;
    public final void rule__Clause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6750:1: ( rule__Clause__Group__6__Impl rule__Clause__Group__7 )
            // InternalSM2.g:6751:2: rule__Clause__Group__6__Impl rule__Clause__Group__7
            {
            pushFollow(FOLLOW_51);
            rule__Clause__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6"


    // $ANTLR start "rule__Clause__Group__6__Impl"
    // InternalSM2.g:6758:1: rule__Clause__Group__6__Impl : ( ( ( rule__Clause__ExpressionAssignment_6 ) ) ( ( rule__Clause__ExpressionAssignment_6 )* ) ) ;
    public final void rule__Clause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6762:1: ( ( ( ( rule__Clause__ExpressionAssignment_6 ) ) ( ( rule__Clause__ExpressionAssignment_6 )* ) ) )
            // InternalSM2.g:6763:1: ( ( ( rule__Clause__ExpressionAssignment_6 ) ) ( ( rule__Clause__ExpressionAssignment_6 )* ) )
            {
            // InternalSM2.g:6763:1: ( ( ( rule__Clause__ExpressionAssignment_6 ) ) ( ( rule__Clause__ExpressionAssignment_6 )* ) )
            // InternalSM2.g:6764:2: ( ( rule__Clause__ExpressionAssignment_6 ) ) ( ( rule__Clause__ExpressionAssignment_6 )* )
            {
            // InternalSM2.g:6764:2: ( ( rule__Clause__ExpressionAssignment_6 ) )
            // InternalSM2.g:6765:3: ( rule__Clause__ExpressionAssignment_6 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionAssignment_6()); 
            }
            // InternalSM2.g:6766:3: ( rule__Clause__ExpressionAssignment_6 )
            // InternalSM2.g:6766:4: rule__Clause__ExpressionAssignment_6
            {
            pushFollow(FOLLOW_64);
            rule__Clause__ExpressionAssignment_6();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionAssignment_6()); 
            }

            }

            // InternalSM2.g:6769:2: ( ( rule__Clause__ExpressionAssignment_6 )* )
            // InternalSM2.g:6770:3: ( rule__Clause__ExpressionAssignment_6 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionAssignment_6()); 
            }
            // InternalSM2.g:6771:3: ( rule__Clause__ExpressionAssignment_6 )*
            loop77:
            do {
                int alt77=2;
                int LA77_0 = input.LA(1);

                if ( ((LA77_0>=RULE_INTEGER && LA77_0<=RULE_STRING)||LA77_0==RULE_OPENPARENTHESIS) ) {
                    alt77=1;
                }


                switch (alt77) {
            	case 1 :
            	    // InternalSM2.g:6771:4: rule__Clause__ExpressionAssignment_6
            	    {
            	    pushFollow(FOLLOW_64);
            	    rule__Clause__ExpressionAssignment_6();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop77;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionAssignment_6()); 
            }

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__6__Impl"


    // $ANTLR start "rule__Clause__Group__7"
    // InternalSM2.g:6780:1: rule__Clause__Group__7 : rule__Clause__Group__7__Impl rule__Clause__Group__8 ;
    public final void rule__Clause__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6784:1: ( rule__Clause__Group__7__Impl rule__Clause__Group__8 )
            // InternalSM2.g:6785:2: rule__Clause__Group__7__Impl rule__Clause__Group__8
            {
            pushFollow(FOLLOW_51);
            rule__Clause__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__8();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7"


    // $ANTLR start "rule__Clause__Group__7__Impl"
    // InternalSM2.g:6792:1: rule__Clause__Group__7__Impl : ( ( RULE_EOLINE )? ) ;
    public final void rule__Clause__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6796:1: ( ( ( RULE_EOLINE )? ) )
            // InternalSM2.g:6797:1: ( ( RULE_EOLINE )? )
            {
            // InternalSM2.g:6797:1: ( ( RULE_EOLINE )? )
            // InternalSM2.g:6798:2: ( RULE_EOLINE )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 
            }
            // InternalSM2.g:6799:2: ( RULE_EOLINE )?
            int alt78=2;
            int LA78_0 = input.LA(1);

            if ( (LA78_0==RULE_EOLINE) ) {
                alt78=1;
            }
            switch (alt78) {
                case 1 :
                    // InternalSM2.g:6799:3: RULE_EOLINE
                    {
                    match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__7__Impl"


    // $ANTLR start "rule__Clause__Group__8"
    // InternalSM2.g:6807:1: rule__Clause__Group__8 : rule__Clause__Group__8__Impl rule__Clause__Group__9 ;
    public final void rule__Clause__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6811:1: ( rule__Clause__Group__8__Impl rule__Clause__Group__9 )
            // InternalSM2.g:6812:2: rule__Clause__Group__8__Impl rule__Clause__Group__9
            {
            pushFollow(FOLLOW_21);
            rule__Clause__Group__8__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__Clause__Group__9();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8"


    // $ANTLR start "rule__Clause__Group__8__Impl"
    // InternalSM2.g:6819:1: rule__Clause__Group__8__Impl : ( RULE_CLOSEKEY ) ;
    public final void rule__Clause__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6823:1: ( ( RULE_CLOSEKEY ) )
            // InternalSM2.g:6824:1: ( RULE_CLOSEKEY )
            {
            // InternalSM2.g:6824:1: ( RULE_CLOSEKEY )
            // InternalSM2.g:6825:2: RULE_CLOSEKEY
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_8()); 
            }
            match(input,RULE_CLOSEKEY,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getCLOSEKEYTerminalRuleCall_8()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__8__Impl"


    // $ANTLR start "rule__Clause__Group__9"
    // InternalSM2.g:6834:1: rule__Clause__Group__9 : rule__Clause__Group__9__Impl ;
    public final void rule__Clause__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6838:1: ( rule__Clause__Group__9__Impl )
            // InternalSM2.g:6839:2: rule__Clause__Group__9__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Clause__Group__9__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9"


    // $ANTLR start "rule__Clause__Group__9__Impl"
    // InternalSM2.g:6845:1: rule__Clause__Group__9__Impl : ( RULE_EOLINE ) ;
    public final void rule__Clause__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6849:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:6850:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:6850:1: ( RULE_EOLINE )
            // InternalSM2.g:6851:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_9()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getEOLINETerminalRuleCall_9()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__Group__9__Impl"


    // $ANTLR start "rule__HeadClause__Group__0"
    // InternalSM2.g:6861:1: rule__HeadClause__Group__0 : rule__HeadClause__Group__0__Impl rule__HeadClause__Group__1 ;
    public final void rule__HeadClause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6865:1: ( rule__HeadClause__Group__0__Impl rule__HeadClause__Group__1 )
            // InternalSM2.g:6866:2: rule__HeadClause__Group__0__Impl rule__HeadClause__Group__1
            {
            pushFollow(FOLLOW_9);
            rule__HeadClause__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__0"


    // $ANTLR start "rule__HeadClause__Group__0__Impl"
    // InternalSM2.g:6873:1: rule__HeadClause__Group__0__Impl : ( 'function' ) ;
    public final void rule__HeadClause__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6877:1: ( ( 'function' ) )
            // InternalSM2.g:6878:1: ( 'function' )
            {
            // InternalSM2.g:6878:1: ( 'function' )
            // InternalSM2.g:6879:2: 'function'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getFunctionKeyword_0()); 
            }
            match(input,78,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getFunctionKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__0__Impl"


    // $ANTLR start "rule__HeadClause__Group__1"
    // InternalSM2.g:6888:1: rule__HeadClause__Group__1 : rule__HeadClause__Group__1__Impl rule__HeadClause__Group__2 ;
    public final void rule__HeadClause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6892:1: ( rule__HeadClause__Group__1__Impl rule__HeadClause__Group__2 )
            // InternalSM2.g:6893:2: rule__HeadClause__Group__1__Impl rule__HeadClause__Group__2
            {
            pushFollow(FOLLOW_29);
            rule__HeadClause__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__1"


    // $ANTLR start "rule__HeadClause__Group__1__Impl"
    // InternalSM2.g:6900:1: rule__HeadClause__Group__1__Impl : ( ( rule__HeadClause__NameFunctionAssignment_1 ) ) ;
    public final void rule__HeadClause__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6904:1: ( ( ( rule__HeadClause__NameFunctionAssignment_1 ) ) )
            // InternalSM2.g:6905:1: ( ( rule__HeadClause__NameFunctionAssignment_1 ) )
            {
            // InternalSM2.g:6905:1: ( ( rule__HeadClause__NameFunctionAssignment_1 ) )
            // InternalSM2.g:6906:2: ( rule__HeadClause__NameFunctionAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getNameFunctionAssignment_1()); 
            }
            // InternalSM2.g:6907:2: ( rule__HeadClause__NameFunctionAssignment_1 )
            // InternalSM2.g:6907:3: rule__HeadClause__NameFunctionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__HeadClause__NameFunctionAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getNameFunctionAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__1__Impl"


    // $ANTLR start "rule__HeadClause__Group__2"
    // InternalSM2.g:6915:1: rule__HeadClause__Group__2 : rule__HeadClause__Group__2__Impl rule__HeadClause__Group__3 ;
    public final void rule__HeadClause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6919:1: ( rule__HeadClause__Group__2__Impl rule__HeadClause__Group__3 )
            // InternalSM2.g:6920:2: rule__HeadClause__Group__2__Impl rule__HeadClause__Group__3
            {
            pushFollow(FOLLOW_42);
            rule__HeadClause__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__2"


    // $ANTLR start "rule__HeadClause__Group__2__Impl"
    // InternalSM2.g:6927:1: rule__HeadClause__Group__2__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__HeadClause__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6931:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:6932:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:6932:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:6933:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getOPENPARENTHESISTerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__2__Impl"


    // $ANTLR start "rule__HeadClause__Group__3"
    // InternalSM2.g:6942:1: rule__HeadClause__Group__3 : rule__HeadClause__Group__3__Impl rule__HeadClause__Group__4 ;
    public final void rule__HeadClause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6946:1: ( rule__HeadClause__Group__3__Impl rule__HeadClause__Group__4 )
            // InternalSM2.g:6947:2: rule__HeadClause__Group__3__Impl rule__HeadClause__Group__4
            {
            pushFollow(FOLLOW_42);
            rule__HeadClause__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__3"


    // $ANTLR start "rule__HeadClause__Group__3__Impl"
    // InternalSM2.g:6954:1: rule__HeadClause__Group__3__Impl : ( ( rule__HeadClause__InputParamsAssignment_3 )* ) ;
    public final void rule__HeadClause__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6958:1: ( ( ( rule__HeadClause__InputParamsAssignment_3 )* ) )
            // InternalSM2.g:6959:1: ( ( rule__HeadClause__InputParamsAssignment_3 )* )
            {
            // InternalSM2.g:6959:1: ( ( rule__HeadClause__InputParamsAssignment_3 )* )
            // InternalSM2.g:6960:2: ( rule__HeadClause__InputParamsAssignment_3 )*
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getInputParamsAssignment_3()); 
            }
            // InternalSM2.g:6961:2: ( rule__HeadClause__InputParamsAssignment_3 )*
            loop79:
            do {
                int alt79=2;
                int LA79_0 = input.LA(1);

                if ( (LA79_0==RULE_ID) ) {
                    alt79=1;
                }


                switch (alt79) {
            	case 1 :
            	    // InternalSM2.g:6961:3: rule__HeadClause__InputParamsAssignment_3
            	    {
            	    pushFollow(FOLLOW_33);
            	    rule__HeadClause__InputParamsAssignment_3();

            	    state._fsp--;
            	    if (state.failed) return ;

            	    }
            	    break;

            	default :
            	    break loop79;
                }
            } while (true);

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getInputParamsAssignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__3__Impl"


    // $ANTLR start "rule__HeadClause__Group__4"
    // InternalSM2.g:6969:1: rule__HeadClause__Group__4 : rule__HeadClause__Group__4__Impl rule__HeadClause__Group__5 ;
    public final void rule__HeadClause__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6973:1: ( rule__HeadClause__Group__4__Impl rule__HeadClause__Group__5 )
            // InternalSM2.g:6974:2: rule__HeadClause__Group__4__Impl rule__HeadClause__Group__5
            {
            pushFollow(FOLLOW_65);
            rule__HeadClause__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__4"


    // $ANTLR start "rule__HeadClause__Group__4__Impl"
    // InternalSM2.g:6981:1: rule__HeadClause__Group__4__Impl : ( ( rule__HeadClause__VisibilityAccessAssignment_4 ) ) ;
    public final void rule__HeadClause__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:6985:1: ( ( ( rule__HeadClause__VisibilityAccessAssignment_4 ) ) )
            // InternalSM2.g:6986:1: ( ( rule__HeadClause__VisibilityAccessAssignment_4 ) )
            {
            // InternalSM2.g:6986:1: ( ( rule__HeadClause__VisibilityAccessAssignment_4 ) )
            // InternalSM2.g:6987:2: ( rule__HeadClause__VisibilityAccessAssignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getVisibilityAccessAssignment_4()); 
            }
            // InternalSM2.g:6988:2: ( rule__HeadClause__VisibilityAccessAssignment_4 )
            // InternalSM2.g:6988:3: rule__HeadClause__VisibilityAccessAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__HeadClause__VisibilityAccessAssignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getVisibilityAccessAssignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__4__Impl"


    // $ANTLR start "rule__HeadClause__Group__5"
    // InternalSM2.g:6996:1: rule__HeadClause__Group__5 : rule__HeadClause__Group__5__Impl rule__HeadClause__Group__6 ;
    public final void rule__HeadClause__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7000:1: ( rule__HeadClause__Group__5__Impl rule__HeadClause__Group__6 )
            // InternalSM2.g:7001:2: rule__HeadClause__Group__5__Impl rule__HeadClause__Group__6
            {
            pushFollow(FOLLOW_65);
            rule__HeadClause__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__5"


    // $ANTLR start "rule__HeadClause__Group__5__Impl"
    // InternalSM2.g:7008:1: rule__HeadClause__Group__5__Impl : ( ( rule__HeadClause__ModifierAssignment_5 )? ) ;
    public final void rule__HeadClause__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7012:1: ( ( ( rule__HeadClause__ModifierAssignment_5 )? ) )
            // InternalSM2.g:7013:1: ( ( rule__HeadClause__ModifierAssignment_5 )? )
            {
            // InternalSM2.g:7013:1: ( ( rule__HeadClause__ModifierAssignment_5 )? )
            // InternalSM2.g:7014:2: ( rule__HeadClause__ModifierAssignment_5 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getModifierAssignment_5()); 
            }
            // InternalSM2.g:7015:2: ( rule__HeadClause__ModifierAssignment_5 )?
            int alt80=2;
            int LA80_0 = input.LA(1);

            if ( (LA80_0==RULE_ID) ) {
                alt80=1;
            }
            switch (alt80) {
                case 1 :
                    // InternalSM2.g:7015:3: rule__HeadClause__ModifierAssignment_5
                    {
                    pushFollow(FOLLOW_2);
                    rule__HeadClause__ModifierAssignment_5();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getModifierAssignment_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__5__Impl"


    // $ANTLR start "rule__HeadClause__Group__6"
    // InternalSM2.g:7023:1: rule__HeadClause__Group__6 : rule__HeadClause__Group__6__Impl ;
    public final void rule__HeadClause__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7027:1: ( rule__HeadClause__Group__6__Impl )
            // InternalSM2.g:7028:2: rule__HeadClause__Group__6__Impl
            {
            pushFollow(FOLLOW_2);
            rule__HeadClause__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__6"


    // $ANTLR start "rule__HeadClause__Group__6__Impl"
    // InternalSM2.g:7034:1: rule__HeadClause__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__HeadClause__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7038:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:7039:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:7039:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:7040:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__Group__6__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0"
    // InternalSM2.g:7050:1: rule__ArithmethicalExpression__Group_0__0 : rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 ;
    public final void rule__ArithmethicalExpression__Group_0__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7054:1: ( rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1 )
            // InternalSM2.g:7055:2: rule__ArithmethicalExpression__Group_0__0__Impl rule__ArithmethicalExpression__Group_0__1
            {
            pushFollow(FOLLOW_66);
            rule__ArithmethicalExpression__Group_0__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__0__Impl"
    // InternalSM2.g:7062:1: rule__ArithmethicalExpression__Group_0__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7066:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:7067:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:7067:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:7068:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1"
    // InternalSM2.g:7077:1: rule__ArithmethicalExpression__Group_0__1 : rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 ;
    public final void rule__ArithmethicalExpression__Group_0__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7081:1: ( rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2 )
            // InternalSM2.g:7082:2: rule__ArithmethicalExpression__Group_0__1__Impl rule__ArithmethicalExpression__Group_0__2
            {
            pushFollow(FOLLOW_67);
            rule__ArithmethicalExpression__Group_0__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__1__Impl"
    // InternalSM2.g:7089:1: rule__ArithmethicalExpression__Group_0__1__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7093:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) ) )
            // InternalSM2.g:7094:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            {
            // InternalSM2.g:7094:1: ( ( rule__ArithmethicalExpression__Op1Assignment_0_1 ) )
            // InternalSM2.g:7095:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            }
            // InternalSM2.g:7096:2: ( rule__ArithmethicalExpression__Op1Assignment_0_1 )
            // InternalSM2.g:7096:3: rule__ArithmethicalExpression__Op1Assignment_0_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_0_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_0_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2"
    // InternalSM2.g:7104:1: rule__ArithmethicalExpression__Group_0__2 : rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 ;
    public final void rule__ArithmethicalExpression__Group_0__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7108:1: ( rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3 )
            // InternalSM2.g:7109:2: rule__ArithmethicalExpression__Group_0__2__Impl rule__ArithmethicalExpression__Group_0__3
            {
            pushFollow(FOLLOW_66);
            rule__ArithmethicalExpression__Group_0__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__2__Impl"
    // InternalSM2.g:7116:1: rule__ArithmethicalExpression__Group_0__2__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7120:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) ) )
            // InternalSM2.g:7121:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            {
            // InternalSM2.g:7121:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_0_2 ) )
            // InternalSM2.g:7122:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            }
            // InternalSM2.g:7123:2: ( rule__ArithmethicalExpression__OperatorAssignment_0_2 )
            // InternalSM2.g:7123:3: rule__ArithmethicalExpression__OperatorAssignment_0_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_0_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_0_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3"
    // InternalSM2.g:7131:1: rule__ArithmethicalExpression__Group_0__3 : rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 ;
    public final void rule__ArithmethicalExpression__Group_0__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7135:1: ( rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4 )
            // InternalSM2.g:7136:2: rule__ArithmethicalExpression__Group_0__3__Impl rule__ArithmethicalExpression__Group_0__4
            {
            pushFollow(FOLLOW_31);
            rule__ArithmethicalExpression__Group_0__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__3__Impl"
    // InternalSM2.g:7143:1: rule__ArithmethicalExpression__Group_0__3__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) ;
    public final void rule__ArithmethicalExpression__Group_0__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7147:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) ) )
            // InternalSM2.g:7148:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            {
            // InternalSM2.g:7148:1: ( ( rule__ArithmethicalExpression__Op2Assignment_0_3 ) )
            // InternalSM2.g:7149:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            }
            // InternalSM2.g:7150:2: ( rule__ArithmethicalExpression__Op2Assignment_0_3 )
            // InternalSM2.g:7150:3: rule__ArithmethicalExpression__Op2Assignment_0_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_0_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_0_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4"
    // InternalSM2.g:7158:1: rule__ArithmethicalExpression__Group_0__4 : rule__ArithmethicalExpression__Group_0__4__Impl ;
    public final void rule__ArithmethicalExpression__Group_0__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7162:1: ( rule__ArithmethicalExpression__Group_0__4__Impl )
            // InternalSM2.g:7163:2: rule__ArithmethicalExpression__Group_0__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_0__4__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4"


    // $ANTLR start "rule__ArithmethicalExpression__Group_0__4__Impl"
    // InternalSM2.g:7169:1: rule__ArithmethicalExpression__Group_0__4__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalExpression__Group_0__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7173:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:7174:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:7174:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:7175:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_0_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_0__4__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0"
    // InternalSM2.g:7185:1: rule__ArithmethicalExpression__Group_1__0 : rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 ;
    public final void rule__ArithmethicalExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7189:1: ( rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1 )
            // InternalSM2.g:7190:2: rule__ArithmethicalExpression__Group_1__0__Impl rule__ArithmethicalExpression__Group_1__1
            {
            pushFollow(FOLLOW_67);
            rule__ArithmethicalExpression__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__0__Impl"
    // InternalSM2.g:7197:1: rule__ArithmethicalExpression__Group_1__0__Impl : ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7201:1: ( ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) ) )
            // InternalSM2.g:7202:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            {
            // InternalSM2.g:7202:1: ( ( rule__ArithmethicalExpression__Op1Assignment_1_0 ) )
            // InternalSM2.g:7203:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            }
            // InternalSM2.g:7204:2: ( rule__ArithmethicalExpression__Op1Assignment_1_0 )
            // InternalSM2.g:7204:3: rule__ArithmethicalExpression__Op1Assignment_1_0
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op1Assignment_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1Assignment_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1"
    // InternalSM2.g:7212:1: rule__ArithmethicalExpression__Group_1__1 : rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 ;
    public final void rule__ArithmethicalExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7216:1: ( rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2 )
            // InternalSM2.g:7217:2: rule__ArithmethicalExpression__Group_1__1__Impl rule__ArithmethicalExpression__Group_1__2
            {
            pushFollow(FOLLOW_66);
            rule__ArithmethicalExpression__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__1__Impl"
    // InternalSM2.g:7224:1: rule__ArithmethicalExpression__Group_1__1__Impl : ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7228:1: ( ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) ) )
            // InternalSM2.g:7229:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            {
            // InternalSM2.g:7229:1: ( ( rule__ArithmethicalExpression__OperatorAssignment_1_1 ) )
            // InternalSM2.g:7230:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            }
            // InternalSM2.g:7231:2: ( rule__ArithmethicalExpression__OperatorAssignment_1_1 )
            // InternalSM2.g:7231:3: rule__ArithmethicalExpression__OperatorAssignment_1_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__OperatorAssignment_1_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorAssignment_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__1__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2"
    // InternalSM2.g:7239:1: rule__ArithmethicalExpression__Group_1__2 : rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 ;
    public final void rule__ArithmethicalExpression__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7243:1: ( rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3 )
            // InternalSM2.g:7244:2: rule__ArithmethicalExpression__Group_1__2__Impl rule__ArithmethicalExpression__Group_1__3
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalExpression__Group_1__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__2__Impl"
    // InternalSM2.g:7251:1: rule__ArithmethicalExpression__Group_1__2__Impl : ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) ;
    public final void rule__ArithmethicalExpression__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7255:1: ( ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) ) )
            // InternalSM2.g:7256:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            {
            // InternalSM2.g:7256:1: ( ( rule__ArithmethicalExpression__Op2Assignment_1_2 ) )
            // InternalSM2.g:7257:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            }
            // InternalSM2.g:7258:2: ( rule__ArithmethicalExpression__Op2Assignment_1_2 )
            // InternalSM2.g:7258:3: rule__ArithmethicalExpression__Op2Assignment_1_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Op2Assignment_1_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2Assignment_1_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__2__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3"
    // InternalSM2.g:7266:1: rule__ArithmethicalExpression__Group_1__3 : rule__ArithmethicalExpression__Group_1__3__Impl ;
    public final void rule__ArithmethicalExpression__Group_1__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7270:1: ( rule__ArithmethicalExpression__Group_1__3__Impl )
            // InternalSM2.g:7271:2: rule__ArithmethicalExpression__Group_1__3__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1__3__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1__3__Impl"
    // InternalSM2.g:7277:1: rule__ArithmethicalExpression__Group_1__3__Impl : ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) ;
    public final void rule__ArithmethicalExpression__Group_1__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7281:1: ( ( ( rule__ArithmethicalExpression__Group_1_3__0 )? ) )
            // InternalSM2.g:7282:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            {
            // InternalSM2.g:7282:1: ( ( rule__ArithmethicalExpression__Group_1_3__0 )? )
            // InternalSM2.g:7283:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            }
            // InternalSM2.g:7284:2: ( rule__ArithmethicalExpression__Group_1_3__0 )?
            int alt81=2;
            int LA81_0 = input.LA(1);

            if ( (LA81_0==RULE_SEMICOLON) ) {
                alt81=1;
            }
            switch (alt81) {
                case 1 :
                    // InternalSM2.g:7284:3: rule__ArithmethicalExpression__Group_1_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalExpression__Group_1_3__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getGroup_1_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1__3__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0"
    // InternalSM2.g:7293:1: rule__ArithmethicalExpression__Group_1_3__0 : rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 ;
    public final void rule__ArithmethicalExpression__Group_1_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7297:1: ( rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1 )
            // InternalSM2.g:7298:2: rule__ArithmethicalExpression__Group_1_3__0__Impl rule__ArithmethicalExpression__Group_1_3__1
            {
            pushFollow(FOLLOW_21);
            rule__ArithmethicalExpression__Group_1_3__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__0__Impl"
    // InternalSM2.g:7305:1: rule__ArithmethicalExpression__Group_1_3__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7309:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:7310:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:7310:1: ( RULE_SEMICOLON )
            // InternalSM2.g:7311:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getSEMICOLONTerminalRuleCall_1_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__0__Impl"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1"
    // InternalSM2.g:7320:1: rule__ArithmethicalExpression__Group_1_3__1 : rule__ArithmethicalExpression__Group_1_3__1__Impl ;
    public final void rule__ArithmethicalExpression__Group_1_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7324:1: ( rule__ArithmethicalExpression__Group_1_3__1__Impl )
            // InternalSM2.g:7325:2: rule__ArithmethicalExpression__Group_1_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalExpression__Group_1_3__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1"


    // $ANTLR start "rule__ArithmethicalExpression__Group_1_3__1__Impl"
    // InternalSM2.g:7331:1: rule__ArithmethicalExpression__Group_1_3__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalExpression__Group_1_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7335:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:7336:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:7336:1: ( RULE_EOLINE )
            // InternalSM2.g:7337:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getEOLINETerminalRuleCall_1_3_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Group_1_3__1__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__0"
    // InternalSM2.g:7347:1: rule__ArithmethicalLogicalExpression__Group__0 : rule__ArithmethicalLogicalExpression__Group__0__Impl rule__ArithmethicalLogicalExpression__Group__1 ;
    public final void rule__ArithmethicalLogicalExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7351:1: ( rule__ArithmethicalLogicalExpression__Group__0__Impl rule__ArithmethicalLogicalExpression__Group__1 )
            // InternalSM2.g:7352:2: rule__ArithmethicalLogicalExpression__Group__0__Impl rule__ArithmethicalLogicalExpression__Group__1
            {
            pushFollow(FOLLOW_66);
            rule__ArithmethicalLogicalExpression__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__0"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__0__Impl"
    // InternalSM2.g:7359:1: rule__ArithmethicalLogicalExpression__Group__0__Impl : ( RULE_OPENPARENTHESIS ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7363:1: ( ( RULE_OPENPARENTHESIS ) )
            // InternalSM2.g:7364:1: ( RULE_OPENPARENTHESIS )
            {
            // InternalSM2.g:7364:1: ( RULE_OPENPARENTHESIS )
            // InternalSM2.g:7365:2: RULE_OPENPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0()); 
            }
            match(input,RULE_OPENPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOPENPARENTHESISTerminalRuleCall_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__0__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__1"
    // InternalSM2.g:7374:1: rule__ArithmethicalLogicalExpression__Group__1 : rule__ArithmethicalLogicalExpression__Group__1__Impl rule__ArithmethicalLogicalExpression__Group__2 ;
    public final void rule__ArithmethicalLogicalExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7378:1: ( rule__ArithmethicalLogicalExpression__Group__1__Impl rule__ArithmethicalLogicalExpression__Group__2 )
            // InternalSM2.g:7379:2: rule__ArithmethicalLogicalExpression__Group__1__Impl rule__ArithmethicalLogicalExpression__Group__2
            {
            pushFollow(FOLLOW_67);
            rule__ArithmethicalLogicalExpression__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__1"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__1__Impl"
    // InternalSM2.g:7386:1: rule__ArithmethicalLogicalExpression__Group__1__Impl : ( ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 ) ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7390:1: ( ( ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 ) ) )
            // InternalSM2.g:7391:1: ( ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 ) )
            {
            // InternalSM2.g:7391:1: ( ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 ) )
            // InternalSM2.g:7392:2: ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1Assignment_1()); 
            }
            // InternalSM2.g:7393:2: ( rule__ArithmethicalLogicalExpression__Op1Assignment_1 )
            // InternalSM2.g:7393:3: rule__ArithmethicalLogicalExpression__Op1Assignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Op1Assignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1Assignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__1__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__2"
    // InternalSM2.g:7401:1: rule__ArithmethicalLogicalExpression__Group__2 : rule__ArithmethicalLogicalExpression__Group__2__Impl rule__ArithmethicalLogicalExpression__Group__3 ;
    public final void rule__ArithmethicalLogicalExpression__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7405:1: ( rule__ArithmethicalLogicalExpression__Group__2__Impl rule__ArithmethicalLogicalExpression__Group__3 )
            // InternalSM2.g:7406:2: rule__ArithmethicalLogicalExpression__Group__2__Impl rule__ArithmethicalLogicalExpression__Group__3
            {
            pushFollow(FOLLOW_66);
            rule__ArithmethicalLogicalExpression__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__3();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__2"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__2__Impl"
    // InternalSM2.g:7413:1: rule__ArithmethicalLogicalExpression__Group__2__Impl : ( ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 ) ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7417:1: ( ( ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 ) ) )
            // InternalSM2.g:7418:1: ( ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 ) )
            {
            // InternalSM2.g:7418:1: ( ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 ) )
            // InternalSM2.g:7419:2: ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1Assignment_2()); 
            }
            // InternalSM2.g:7420:2: ( rule__ArithmethicalLogicalExpression__Operator1Assignment_2 )
            // InternalSM2.g:7420:3: rule__ArithmethicalLogicalExpression__Operator1Assignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Operator1Assignment_2();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1Assignment_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__2__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__3"
    // InternalSM2.g:7428:1: rule__ArithmethicalLogicalExpression__Group__3 : rule__ArithmethicalLogicalExpression__Group__3__Impl rule__ArithmethicalLogicalExpression__Group__4 ;
    public final void rule__ArithmethicalLogicalExpression__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7432:1: ( rule__ArithmethicalLogicalExpression__Group__3__Impl rule__ArithmethicalLogicalExpression__Group__4 )
            // InternalSM2.g:7433:2: rule__ArithmethicalLogicalExpression__Group__3__Impl rule__ArithmethicalLogicalExpression__Group__4
            {
            pushFollow(FOLLOW_61);
            rule__ArithmethicalLogicalExpression__Group__3__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__4();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__3"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__3__Impl"
    // InternalSM2.g:7440:1: rule__ArithmethicalLogicalExpression__Group__3__Impl : ( ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 ) ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7444:1: ( ( ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 ) ) )
            // InternalSM2.g:7445:1: ( ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 ) )
            {
            // InternalSM2.g:7445:1: ( ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 ) )
            // InternalSM2.g:7446:2: ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2Assignment_3()); 
            }
            // InternalSM2.g:7447:2: ( rule__ArithmethicalLogicalExpression__Op2Assignment_3 )
            // InternalSM2.g:7447:3: rule__ArithmethicalLogicalExpression__Op2Assignment_3
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Op2Assignment_3();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2Assignment_3()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__3__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__4"
    // InternalSM2.g:7455:1: rule__ArithmethicalLogicalExpression__Group__4 : rule__ArithmethicalLogicalExpression__Group__4__Impl rule__ArithmethicalLogicalExpression__Group__5 ;
    public final void rule__ArithmethicalLogicalExpression__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7459:1: ( rule__ArithmethicalLogicalExpression__Group__4__Impl rule__ArithmethicalLogicalExpression__Group__5 )
            // InternalSM2.g:7460:2: rule__ArithmethicalLogicalExpression__Group__4__Impl rule__ArithmethicalLogicalExpression__Group__5
            {
            pushFollow(FOLLOW_68);
            rule__ArithmethicalLogicalExpression__Group__4__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__5();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__4"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__4__Impl"
    // InternalSM2.g:7467:1: rule__ArithmethicalLogicalExpression__Group__4__Impl : ( ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 ) ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7471:1: ( ( ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 ) ) )
            // InternalSM2.g:7472:1: ( ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 ) )
            {
            // InternalSM2.g:7472:1: ( ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 ) )
            // InternalSM2.g:7473:2: ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2Assignment_4()); 
            }
            // InternalSM2.g:7474:2: ( rule__ArithmethicalLogicalExpression__Operator2Assignment_4 )
            // InternalSM2.g:7474:3: rule__ArithmethicalLogicalExpression__Operator2Assignment_4
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Operator2Assignment_4();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2Assignment_4()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__4__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__5"
    // InternalSM2.g:7482:1: rule__ArithmethicalLogicalExpression__Group__5 : rule__ArithmethicalLogicalExpression__Group__5__Impl rule__ArithmethicalLogicalExpression__Group__6 ;
    public final void rule__ArithmethicalLogicalExpression__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7486:1: ( rule__ArithmethicalLogicalExpression__Group__5__Impl rule__ArithmethicalLogicalExpression__Group__6 )
            // InternalSM2.g:7487:2: rule__ArithmethicalLogicalExpression__Group__5__Impl rule__ArithmethicalLogicalExpression__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__ArithmethicalLogicalExpression__Group__5__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__6();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__5"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__5__Impl"
    // InternalSM2.g:7494:1: rule__ArithmethicalLogicalExpression__Group__5__Impl : ( ( rule__ArithmethicalLogicalExpression__Alternatives_5 ) ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7498:1: ( ( ( rule__ArithmethicalLogicalExpression__Alternatives_5 ) ) )
            // InternalSM2.g:7499:1: ( ( rule__ArithmethicalLogicalExpression__Alternatives_5 ) )
            {
            // InternalSM2.g:7499:1: ( ( rule__ArithmethicalLogicalExpression__Alternatives_5 ) )
            // InternalSM2.g:7500:2: ( rule__ArithmethicalLogicalExpression__Alternatives_5 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getAlternatives_5()); 
            }
            // InternalSM2.g:7501:2: ( rule__ArithmethicalLogicalExpression__Alternatives_5 )
            // InternalSM2.g:7501:3: rule__ArithmethicalLogicalExpression__Alternatives_5
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Alternatives_5();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getAlternatives_5()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__5__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__6"
    // InternalSM2.g:7509:1: rule__ArithmethicalLogicalExpression__Group__6 : rule__ArithmethicalLogicalExpression__Group__6__Impl rule__ArithmethicalLogicalExpression__Group__7 ;
    public final void rule__ArithmethicalLogicalExpression__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7513:1: ( rule__ArithmethicalLogicalExpression__Group__6__Impl rule__ArithmethicalLogicalExpression__Group__7 )
            // InternalSM2.g:7514:2: rule__ArithmethicalLogicalExpression__Group__6__Impl rule__ArithmethicalLogicalExpression__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__ArithmethicalLogicalExpression__Group__6__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__7();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__6"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__6__Impl"
    // InternalSM2.g:7521:1: rule__ArithmethicalLogicalExpression__Group__6__Impl : ( RULE_CLOSEPARENTHESIS ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7525:1: ( ( RULE_CLOSEPARENTHESIS ) )
            // InternalSM2.g:7526:1: ( RULE_CLOSEPARENTHESIS )
            {
            // InternalSM2.g:7526:1: ( RULE_CLOSEPARENTHESIS )
            // InternalSM2.g:7527:2: RULE_CLOSEPARENTHESIS
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }
            match(input,RULE_CLOSEPARENTHESIS,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getCLOSEPARENTHESISTerminalRuleCall_6()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__6__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__7"
    // InternalSM2.g:7536:1: rule__ArithmethicalLogicalExpression__Group__7 : rule__ArithmethicalLogicalExpression__Group__7__Impl ;
    public final void rule__ArithmethicalLogicalExpression__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7540:1: ( rule__ArithmethicalLogicalExpression__Group__7__Impl )
            // InternalSM2.g:7541:2: rule__ArithmethicalLogicalExpression__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group__7__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__7"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group__7__Impl"
    // InternalSM2.g:7547:1: rule__ArithmethicalLogicalExpression__Group__7__Impl : ( ( rule__ArithmethicalLogicalExpression__Group_7__0 )? ) ;
    public final void rule__ArithmethicalLogicalExpression__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7551:1: ( ( ( rule__ArithmethicalLogicalExpression__Group_7__0 )? ) )
            // InternalSM2.g:7552:1: ( ( rule__ArithmethicalLogicalExpression__Group_7__0 )? )
            {
            // InternalSM2.g:7552:1: ( ( rule__ArithmethicalLogicalExpression__Group_7__0 )? )
            // InternalSM2.g:7553:2: ( rule__ArithmethicalLogicalExpression__Group_7__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getGroup_7()); 
            }
            // InternalSM2.g:7554:2: ( rule__ArithmethicalLogicalExpression__Group_7__0 )?
            int alt82=2;
            int LA82_0 = input.LA(1);

            if ( (LA82_0==RULE_SEMICOLON) ) {
                alt82=1;
            }
            switch (alt82) {
                case 1 :
                    // InternalSM2.g:7554:3: rule__ArithmethicalLogicalExpression__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ArithmethicalLogicalExpression__Group_7__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getGroup_7()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group__7__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group_7__0"
    // InternalSM2.g:7563:1: rule__ArithmethicalLogicalExpression__Group_7__0 : rule__ArithmethicalLogicalExpression__Group_7__0__Impl rule__ArithmethicalLogicalExpression__Group_7__1 ;
    public final void rule__ArithmethicalLogicalExpression__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7567:1: ( rule__ArithmethicalLogicalExpression__Group_7__0__Impl rule__ArithmethicalLogicalExpression__Group_7__1 )
            // InternalSM2.g:7568:2: rule__ArithmethicalLogicalExpression__Group_7__0__Impl rule__ArithmethicalLogicalExpression__Group_7__1
            {
            pushFollow(FOLLOW_21);
            rule__ArithmethicalLogicalExpression__Group_7__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group_7__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group_7__0"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group_7__0__Impl"
    // InternalSM2.g:7575:1: rule__ArithmethicalLogicalExpression__Group_7__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__ArithmethicalLogicalExpression__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7579:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:7580:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:7580:1: ( RULE_SEMICOLON )
            // InternalSM2.g:7581:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getSEMICOLONTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group_7__0__Impl"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group_7__1"
    // InternalSM2.g:7590:1: rule__ArithmethicalLogicalExpression__Group_7__1 : rule__ArithmethicalLogicalExpression__Group_7__1__Impl ;
    public final void rule__ArithmethicalLogicalExpression__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7594:1: ( rule__ArithmethicalLogicalExpression__Group_7__1__Impl )
            // InternalSM2.g:7595:2: rule__ArithmethicalLogicalExpression__Group_7__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ArithmethicalLogicalExpression__Group_7__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group_7__1"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Group_7__1__Impl"
    // InternalSM2.g:7601:1: rule__ArithmethicalLogicalExpression__Group_7__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__ArithmethicalLogicalExpression__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7605:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:7606:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:7606:1: ( RULE_EOLINE )
            // InternalSM2.g:7607:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getEOLINETerminalRuleCall_7_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Group_7__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0"
    // InternalSM2.g:7617:1: rule__SyntaxExpression__Group_1__0 : rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 ;
    public final void rule__SyntaxExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7621:1: ( rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1 )
            // InternalSM2.g:7622:2: rule__SyntaxExpression__Group_1__0__Impl rule__SyntaxExpression__Group_1__1
            {
            pushFollow(FOLLOW_5);
            rule__SyntaxExpression__Group_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1__0__Impl"
    // InternalSM2.g:7629:1: rule__SyntaxExpression__Group_1__0__Impl : ( RULE_INTEGER ) ;
    public final void rule__SyntaxExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7633:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:7634:1: ( RULE_INTEGER )
            {
            // InternalSM2.g:7634:1: ( RULE_INTEGER )
            // InternalSM2.g:7635:2: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getINTEGERTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1"
    // InternalSM2.g:7644:1: rule__SyntaxExpression__Group_1__1 : rule__SyntaxExpression__Group_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7648:1: ( rule__SyntaxExpression__Group_1__1__Impl )
            // InternalSM2.g:7649:2: rule__SyntaxExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1__1__Impl"
    // InternalSM2.g:7655:1: rule__SyntaxExpression__Group_1__1__Impl : ( ( rule__SyntaxExpression__Group_1_1__0 )? ) ;
    public final void rule__SyntaxExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7659:1: ( ( ( rule__SyntaxExpression__Group_1_1__0 )? ) )
            // InternalSM2.g:7660:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            {
            // InternalSM2.g:7660:1: ( ( rule__SyntaxExpression__Group_1_1__0 )? )
            // InternalSM2.g:7661:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            }
            // InternalSM2.g:7662:2: ( rule__SyntaxExpression__Group_1_1__0 )?
            int alt83=2;
            int LA83_0 = input.LA(1);

            if ( (LA83_0==RULE_SEMICOLON) ) {
                alt83=1;
            }
            switch (alt83) {
                case 1 :
                    // InternalSM2.g:7662:3: rule__SyntaxExpression__Group_1_1__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__SyntaxExpression__Group_1_1__0();

                    state._fsp--;
                    if (state.failed) return ;

                    }
                    break;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getGroup_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1__1__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0"
    // InternalSM2.g:7671:1: rule__SyntaxExpression__Group_1_1__0 : rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 ;
    public final void rule__SyntaxExpression__Group_1_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7675:1: ( rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1 )
            // InternalSM2.g:7676:2: rule__SyntaxExpression__Group_1_1__0__Impl rule__SyntaxExpression__Group_1_1__1
            {
            pushFollow(FOLLOW_21);
            rule__SyntaxExpression__Group_1_1__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__0__Impl"
    // InternalSM2.g:7683:1: rule__SyntaxExpression__Group_1_1__0__Impl : ( RULE_SEMICOLON ) ;
    public final void rule__SyntaxExpression__Group_1_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7687:1: ( ( RULE_SEMICOLON ) )
            // InternalSM2.g:7688:1: ( RULE_SEMICOLON )
            {
            // InternalSM2.g:7688:1: ( RULE_SEMICOLON )
            // InternalSM2.g:7689:2: RULE_SEMICOLON
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            }
            match(input,RULE_SEMICOLON,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getSEMICOLONTerminalRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__0__Impl"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1"
    // InternalSM2.g:7698:1: rule__SyntaxExpression__Group_1_1__1 : rule__SyntaxExpression__Group_1_1__1__Impl ;
    public final void rule__SyntaxExpression__Group_1_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7702:1: ( rule__SyntaxExpression__Group_1_1__1__Impl )
            // InternalSM2.g:7703:2: rule__SyntaxExpression__Group_1_1__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__SyntaxExpression__Group_1_1__1__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1"


    // $ANTLR start "rule__SyntaxExpression__Group_1_1__1__Impl"
    // InternalSM2.g:7709:1: rule__SyntaxExpression__Group_1_1__1__Impl : ( RULE_EOLINE ) ;
    public final void rule__SyntaxExpression__Group_1_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7713:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:7714:1: ( RULE_EOLINE )
            {
            // InternalSM2.g:7714:1: ( RULE_EOLINE )
            // InternalSM2.g:7715:2: RULE_EOLINE
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            }
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getEOLINETerminalRuleCall_1_1_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__Group_1_1__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__0"
    // InternalSM2.g:7725:1: rule__ShortComment__Group__0 : rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 ;
    public final void rule__ShortComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7729:1: ( rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1 )
            // InternalSM2.g:7730:2: rule__ShortComment__Group__0__Impl rule__ShortComment__Group__1
            {
            pushFollow(FOLLOW_41);
            rule__ShortComment__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0"


    // $ANTLR start "rule__ShortComment__Group__0__Impl"
    // InternalSM2.g:7737:1: rule__ShortComment__Group__0__Impl : ( '//' ) ;
    public final void rule__ShortComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7741:1: ( ( '//' ) )
            // InternalSM2.g:7742:1: ( '//' )
            {
            // InternalSM2.g:7742:1: ( '//' )
            // InternalSM2.g:7743:2: '//'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            }
            match(input,79,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__0__Impl"


    // $ANTLR start "rule__ShortComment__Group__1"
    // InternalSM2.g:7752:1: rule__ShortComment__Group__1 : rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 ;
    public final void rule__ShortComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7756:1: ( rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2 )
            // InternalSM2.g:7757:2: rule__ShortComment__Group__1__Impl rule__ShortComment__Group__2
            {
            pushFollow(FOLLOW_21);
            rule__ShortComment__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1"


    // $ANTLR start "rule__ShortComment__Group__1__Impl"
    // InternalSM2.g:7764:1: rule__ShortComment__Group__1__Impl : ( ( rule__ShortComment__ExprAssignment_1 ) ) ;
    public final void rule__ShortComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7768:1: ( ( ( rule__ShortComment__ExprAssignment_1 ) ) )
            // InternalSM2.g:7769:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            {
            // InternalSM2.g:7769:1: ( ( rule__ShortComment__ExprAssignment_1 ) )
            // InternalSM2.g:7770:2: ( rule__ShortComment__ExprAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            }
            // InternalSM2.g:7771:2: ( rule__ShortComment__ExprAssignment_1 )
            // InternalSM2.g:7771:3: rule__ShortComment__ExprAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__ExprAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getExprAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__1__Impl"


    // $ANTLR start "rule__ShortComment__Group__2"
    // InternalSM2.g:7779:1: rule__ShortComment__Group__2 : rule__ShortComment__Group__2__Impl ;
    public final void rule__ShortComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7783:1: ( rule__ShortComment__Group__2__Impl )
            // InternalSM2.g:7784:2: rule__ShortComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ShortComment__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2"


    // $ANTLR start "rule__ShortComment__Group__2__Impl"
    // InternalSM2.g:7790:1: rule__ShortComment__Group__2__Impl : ( ( RULE_EOLINE ) ) ;
    public final void rule__ShortComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7794:1: ( ( ( RULE_EOLINE ) ) )
            // InternalSM2.g:7795:1: ( ( RULE_EOLINE ) )
            {
            // InternalSM2.g:7795:1: ( ( RULE_EOLINE ) )
            // InternalSM2.g:7796:2: ( RULE_EOLINE )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            }
            // InternalSM2.g:7797:2: ( RULE_EOLINE )
            // InternalSM2.g:7797:3: RULE_EOLINE
            {
            match(input,RULE_EOLINE,FOLLOW_2); if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getEOLINETerminalRuleCall_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__Group__2__Impl"


    // $ANTLR start "rule__LongComment__Group__0"
    // InternalSM2.g:7806:1: rule__LongComment__Group__0 : rule__LongComment__Group__0__Impl rule__LongComment__Group__1 ;
    public final void rule__LongComment__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7810:1: ( rule__LongComment__Group__0__Impl rule__LongComment__Group__1 )
            // InternalSM2.g:7811:2: rule__LongComment__Group__0__Impl rule__LongComment__Group__1
            {
            pushFollow(FOLLOW_69);
            rule__LongComment__Group__0__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__1();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0"


    // $ANTLR start "rule__LongComment__Group__0__Impl"
    // InternalSM2.g:7818:1: rule__LongComment__Group__0__Impl : ( '/*' ) ;
    public final void rule__LongComment__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7822:1: ( ( '/*' ) )
            // InternalSM2.g:7823:1: ( '/*' )
            {
            // InternalSM2.g:7823:1: ( '/*' )
            // InternalSM2.g:7824:2: '/*'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            }
            match(input,80,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__0__Impl"


    // $ANTLR start "rule__LongComment__Group__1"
    // InternalSM2.g:7833:1: rule__LongComment__Group__1 : rule__LongComment__Group__1__Impl rule__LongComment__Group__2 ;
    public final void rule__LongComment__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7837:1: ( rule__LongComment__Group__1__Impl rule__LongComment__Group__2 )
            // InternalSM2.g:7838:2: rule__LongComment__Group__1__Impl rule__LongComment__Group__2
            {
            pushFollow(FOLLOW_70);
            rule__LongComment__Group__1__Impl();

            state._fsp--;
            if (state.failed) return ;
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1"


    // $ANTLR start "rule__LongComment__Group__1__Impl"
    // InternalSM2.g:7845:1: rule__LongComment__Group__1__Impl : ( ( rule__LongComment__ExpressionAssignment_1 ) ) ;
    public final void rule__LongComment__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7849:1: ( ( ( rule__LongComment__ExpressionAssignment_1 ) ) )
            // InternalSM2.g:7850:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            {
            // InternalSM2.g:7850:1: ( ( rule__LongComment__ExpressionAssignment_1 ) )
            // InternalSM2.g:7851:2: ( rule__LongComment__ExpressionAssignment_1 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 
            }
            // InternalSM2.g:7852:2: ( rule__LongComment__ExpressionAssignment_1 )
            // InternalSM2.g:7852:3: rule__LongComment__ExpressionAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAssignment_1();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getExpressionAssignment_1()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__1__Impl"


    // $ANTLR start "rule__LongComment__Group__2"
    // InternalSM2.g:7860:1: rule__LongComment__Group__2 : rule__LongComment__Group__2__Impl ;
    public final void rule__LongComment__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7864:1: ( rule__LongComment__Group__2__Impl )
            // InternalSM2.g:7865:2: rule__LongComment__Group__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__Group__2__Impl();

            state._fsp--;
            if (state.failed) return ;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2"


    // $ANTLR start "rule__LongComment__Group__2__Impl"
    // InternalSM2.g:7871:1: rule__LongComment__Group__2__Impl : ( ( '*/' ) ) ;
    public final void rule__LongComment__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7875:1: ( ( ( '*/' ) ) )
            // InternalSM2.g:7876:1: ( ( '*/' ) )
            {
            // InternalSM2.g:7876:1: ( ( '*/' ) )
            // InternalSM2.g:7877:2: ( '*/' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            }
            // InternalSM2.g:7878:2: ( '*/' )
            // InternalSM2.g:7878:3: '*/'
            {
            match(input,81,FOLLOW_2); if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__Group__2__Impl"


    // $ANTLR start "rule__SmartContract__CompilerAssignment_0"
    // InternalSM2.g:7887:1: rule__SmartContract__CompilerAssignment_0 : ( ( 'pragma' ) ) ;
    public final void rule__SmartContract__CompilerAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7891:1: ( ( ( 'pragma' ) ) )
            // InternalSM2.g:7892:2: ( ( 'pragma' ) )
            {
            // InternalSM2.g:7892:2: ( ( 'pragma' ) )
            // InternalSM2.g:7893:3: ( 'pragma' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }
            // InternalSM2.g:7894:3: ( 'pragma' )
            // InternalSM2.g:7895:4: 'pragma'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }
            match(input,82,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CompilerAssignment_0"


    // $ANTLR start "rule__SmartContract__VersionCompilerAssignment_2"
    // InternalSM2.g:7906:1: rule__SmartContract__VersionCompilerAssignment_2 : ( ruleVersion ) ;
    public final void rule__SmartContract__VersionCompilerAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7910:1: ( ( ruleVersion ) )
            // InternalSM2.g:7911:2: ( ruleVersion )
            {
            // InternalSM2.g:7911:2: ( ruleVersion )
            // InternalSM2.g:7912:3: ruleVersion
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVersion();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__VersionCompilerAssignment_2"


    // $ANTLR start "rule__SmartContract__ImportsAssignment_5"
    // InternalSM2.g:7921:1: rule__SmartContract__ImportsAssignment_5 : ( ruleImport ) ;
    public final void rule__SmartContract__ImportsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7925:1: ( ( ruleImport ) )
            // InternalSM2.g:7926:2: ( ruleImport )
            {
            // InternalSM2.g:7926:2: ( ruleImport )
            // InternalSM2.g:7927:3: ruleImport
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleImport();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ImportsAssignment_5"


    // $ANTLR start "rule__SmartContract__InterfacesAssignment_6"
    // InternalSM2.g:7936:1: rule__SmartContract__InterfacesAssignment_6 : ( ruleInterface ) ;
    public final void rule__SmartContract__InterfacesAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7940:1: ( ( ruleInterface ) )
            // InternalSM2.g:7941:2: ( ruleInterface )
            {
            // InternalSM2.g:7941:2: ( ruleInterface )
            // InternalSM2.g:7942:3: ruleInterface
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleInterface();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getInterfacesInterfaceParserRuleCall_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__InterfacesAssignment_6"


    // $ANTLR start "rule__SmartContract__ContractAssignment_7"
    // InternalSM2.g:7951:1: rule__SmartContract__ContractAssignment_7 : ( ( 'contract' ) ) ;
    public final void rule__SmartContract__ContractAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7955:1: ( ( ( 'contract' ) ) )
            // InternalSM2.g:7956:2: ( ( 'contract' ) )
            {
            // InternalSM2.g:7956:2: ( ( 'contract' ) )
            // InternalSM2.g:7957:3: ( 'contract' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0()); 
            }
            // InternalSM2.g:7958:3: ( 'contract' )
            // InternalSM2.g:7959:4: 'contract'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0()); 
            }
            match(input,83,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getContractContractKeyword_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ContractAssignment_7"


    // $ANTLR start "rule__SmartContract__NameContractAssignment_8"
    // InternalSM2.g:7970:1: rule__SmartContract__NameContractAssignment_8 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7974:1: ( ( RULE_ID ) )
            // InternalSM2.g:7975:2: ( RULE_ID )
            {
            // InternalSM2.g:7975:2: ( RULE_ID )
            // InternalSM2.g:7976:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_8_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_8_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractAssignment_8"


    // $ANTLR start "rule__SmartContract__NameContractFatherAssignment_9_1"
    // InternalSM2.g:7985:1: rule__SmartContract__NameContractFatherAssignment_9_1 : ( RULE_ID ) ;
    public final void rule__SmartContract__NameContractFatherAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:7989:1: ( ( RULE_ID ) )
            // InternalSM2.g:7990:2: ( RULE_ID )
            {
            // InternalSM2.g:7990:2: ( RULE_ID )
            // InternalSM2.g:7991:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_9_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_9_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__NameContractFatherAssignment_9_1"


    // $ANTLR start "rule__SmartContract__AttributesAssignment_12"
    // InternalSM2.g:8000:1: rule__SmartContract__AttributesAssignment_12 : ( ruleAttributes ) ;
    public final void rule__SmartContract__AttributesAssignment_12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8004:1: ( ( ruleAttributes ) )
            // InternalSM2.g:8005:2: ( ruleAttributes )
            {
            // InternalSM2.g:8005:2: ( ruleAttributes )
            // InternalSM2.g:8006:3: ruleAttributes
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_12_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_12_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__AttributesAssignment_12"


    // $ANTLR start "rule__SmartContract__ConstructorAssignment_13"
    // InternalSM2.g:8015:1: rule__SmartContract__ConstructorAssignment_13 : ( ruleConstructor ) ;
    public final void rule__SmartContract__ConstructorAssignment_13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8019:1: ( ( ruleConstructor ) )
            // InternalSM2.g:8020:2: ( ruleConstructor )
            {
            // InternalSM2.g:8020:2: ( ruleConstructor )
            // InternalSM2.g:8021:3: ruleConstructor
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getConstructorConstructorParserRuleCall_13_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleConstructor();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getConstructorConstructorParserRuleCall_13_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ConstructorAssignment_13"


    // $ANTLR start "rule__SmartContract__EventsAssignment_14"
    // InternalSM2.g:8030:1: rule__SmartContract__EventsAssignment_14 : ( ruleEvent ) ;
    public final void rule__SmartContract__EventsAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8034:1: ( ( ruleEvent ) )
            // InternalSM2.g:8035:2: ( ruleEvent )
            {
            // InternalSM2.g:8035:2: ( ruleEvent )
            // InternalSM2.g:8036:3: ruleEvent
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_14_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleEvent();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getEventsEventParserRuleCall_14_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__EventsAssignment_14"


    // $ANTLR start "rule__SmartContract__ModifierAssignment_15"
    // InternalSM2.g:8045:1: rule__SmartContract__ModifierAssignment_15 : ( ruleModifier ) ;
    public final void rule__SmartContract__ModifierAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8049:1: ( ( ruleModifier ) )
            // InternalSM2.g:8050:2: ( ruleModifier )
            {
            // InternalSM2.g:8050:2: ( ruleModifier )
            // InternalSM2.g:8051:3: ruleModifier
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_15_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleModifier();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_15_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ModifierAssignment_15"


    // $ANTLR start "rule__SmartContract__ClausesAssignment_16"
    // InternalSM2.g:8060:1: rule__SmartContract__ClausesAssignment_16 : ( ruleClause ) ;
    public final void rule__SmartContract__ClausesAssignment_16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8064:1: ( ( ruleClause ) )
            // InternalSM2.g:8065:2: ( ruleClause )
            {
            // InternalSM2.g:8065:2: ( ruleClause )
            // InternalSM2.g:8066:3: ruleClause
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_16_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_16_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__ClausesAssignment_16"


    // $ANTLR start "rule__SmartContract__CommentsAssignment_17"
    // InternalSM2.g:8075:1: rule__SmartContract__CommentsAssignment_17 : ( ruleComment ) ;
    public final void rule__SmartContract__CommentsAssignment_17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8079:1: ( ( ruleComment ) )
            // InternalSM2.g:8080:2: ( ruleComment )
            {
            // InternalSM2.g:8080:2: ( ruleComment )
            // InternalSM2.g:8081:3: ruleComment
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_17_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComment();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_17_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SmartContract__CommentsAssignment_17"


    // $ANTLR start "rule__Version__SymbolAssignment_0_0"
    // InternalSM2.g:8090:1: rule__Version__SymbolAssignment_0_0 : ( ( '^' ) ) ;
    public final void rule__Version__SymbolAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8094:1: ( ( ( '^' ) ) )
            // InternalSM2.g:8095:2: ( ( '^' ) )
            {
            // InternalSM2.g:8095:2: ( ( '^' ) )
            // InternalSM2.g:8096:3: ( '^' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }
            // InternalSM2.g:8097:3: ( '^' )
            // InternalSM2.g:8098:4: '^'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }
            match(input,84,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_0_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_0_1"
    // InternalSM2.g:8109:1: rule__Version__NumberVersionAssignment_0_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8113:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8114:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8114:2: ( RULE_NUMBER )
            // InternalSM2.g:8115:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_0_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_0_3"
    // InternalSM2.g:8124:1: rule__Version__NumberVersion2Assignment_0_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8128:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8129:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8129:2: ( RULE_NUMBER )
            // InternalSM2.g:8130:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_0_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_0_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_0_5"
    // InternalSM2.g:8139:1: rule__Version__NumberVersion3Assignment_0_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_0_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8143:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8144:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8144:2: ( RULE_NUMBER )
            // InternalSM2.g:8145:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_0_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_0_5"


    // $ANTLR start "rule__Version__SymbolAssignment_1_0"
    // InternalSM2.g:8154:1: rule__Version__SymbolAssignment_1_0 : ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) ;
    public final void rule__Version__SymbolAssignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8158:1: ( ( ( rule__Version__SymbolAlternatives_1_0_0 ) ) )
            // InternalSM2.g:8159:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            {
            // InternalSM2.g:8159:2: ( ( rule__Version__SymbolAlternatives_1_0_0 ) )
            // InternalSM2.g:8160:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 
            }
            // InternalSM2.g:8161:3: ( rule__Version__SymbolAlternatives_1_0_0 )
            // InternalSM2.g:8161:4: rule__Version__SymbolAlternatives_1_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__SymbolAlternatives_1_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbolAlternatives_1_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__SymbolAssignment_1_0"


    // $ANTLR start "rule__Version__NumberVersionAssignment_1_1"
    // InternalSM2.g:8169:1: rule__Version__NumberVersionAssignment_1_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8173:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8174:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8174:2: ( RULE_NUMBER )
            // InternalSM2.g:8175:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionNUMBERTerminalRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionAssignment_1_1"


    // $ANTLR start "rule__Version__NumberVersion2Assignment_1_3"
    // InternalSM2.g:8184:1: rule__Version__NumberVersion2Assignment_1_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion2Assignment_1_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8188:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8189:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8189:2: ( RULE_NUMBER )
            // InternalSM2.g:8190:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion2NUMBERTerminalRuleCall_1_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion2Assignment_1_3"


    // $ANTLR start "rule__Version__NumberVersion3Assignment_1_5"
    // InternalSM2.g:8199:1: rule__Version__NumberVersion3Assignment_1_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersion3Assignment_1_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8203:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8204:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8204:2: ( RULE_NUMBER )
            // InternalSM2.g:8205:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersion3NUMBERTerminalRuleCall_1_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersion3Assignment_1_5"


    // $ANTLR start "rule__Version__Symbol2Assignment_1_6_0"
    // InternalSM2.g:8214:1: rule__Version__Symbol2Assignment_1_6_0 : ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) ;
    public final void rule__Version__Symbol2Assignment_1_6_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8218:1: ( ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) ) )
            // InternalSM2.g:8219:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            {
            // InternalSM2.g:8219:2: ( ( rule__Version__Symbol2Alternatives_1_6_0_0 ) )
            // InternalSM2.g:8220:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 
            }
            // InternalSM2.g:8221:3: ( rule__Version__Symbol2Alternatives_1_6_0_0 )
            // InternalSM2.g:8221:4: rule__Version__Symbol2Alternatives_1_6_0_0
            {
            pushFollow(FOLLOW_2);
            rule__Version__Symbol2Alternatives_1_6_0_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getSymbol2Alternatives_1_6_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__Symbol2Assignment_1_6_0"


    // $ANTLR start "rule__Version__NumberVersionOptionalAssignment_1_6_1"
    // InternalSM2.g:8229:1: rule__Version__NumberVersionOptionalAssignment_1_6_1 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptionalAssignment_1_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8233:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8234:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8234:2: ( RULE_NUMBER )
            // InternalSM2.g:8235:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptionalNUMBERTerminalRuleCall_1_6_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptionalAssignment_1_6_1"


    // $ANTLR start "rule__Version__NumberVersionOptional2Assignment_1_6_3"
    // InternalSM2.g:8244:1: rule__Version__NumberVersionOptional2Assignment_1_6_3 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional2Assignment_1_6_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8248:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8249:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8249:2: ( RULE_NUMBER )
            // InternalSM2.g:8250:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional2NUMBERTerminalRuleCall_1_6_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional2Assignment_1_6_3"


    // $ANTLR start "rule__Version__NumberVersionOptional3Assignment_1_6_5"
    // InternalSM2.g:8259:1: rule__Version__NumberVersionOptional3Assignment_1_6_5 : ( RULE_NUMBER ) ;
    public final void rule__Version__NumberVersionOptional3Assignment_1_6_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8263:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8264:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8264:2: ( RULE_NUMBER )
            // InternalSM2.g:8265:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getVersionAccess().getNumberVersionOptional3NUMBERTerminalRuleCall_1_6_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Version__NumberVersionOptional3Assignment_1_6_5"


    // $ANTLR start "rule__Import__NameLibraryAssignment_1"
    // InternalSM2.g:8274:1: rule__Import__NameLibraryAssignment_1 : ( RULE_ID ) ;
    public final void rule__Import__NameLibraryAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8278:1: ( ( RULE_ID ) )
            // InternalSM2.g:8279:2: ( RULE_ID )
            {
            // InternalSM2.g:8279:2: ( RULE_ID )
            // InternalSM2.g:8280:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getNameLibraryIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__NameLibraryAssignment_1"


    // $ANTLR start "rule__Import__AliasAssignment_2_1"
    // InternalSM2.g:8289:1: rule__Import__AliasAssignment_2_1 : ( RULE_ID ) ;
    public final void rule__Import__AliasAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8293:1: ( ( RULE_ID ) )
            // InternalSM2.g:8294:2: ( RULE_ID )
            {
            // InternalSM2.g:8294:2: ( RULE_ID )
            // InternalSM2.g:8295:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getImportAccess().getAliasIDTerminalRuleCall_2_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Import__AliasAssignment_2_1"


    // $ANTLR start "rule__Interface__NameInterfaceAssignment_1"
    // InternalSM2.g:8304:1: rule__Interface__NameInterfaceAssignment_1 : ( RULE_ID ) ;
    public final void rule__Interface__NameInterfaceAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8308:1: ( ( RULE_ID ) )
            // InternalSM2.g:8309:2: ( RULE_ID )
            {
            // InternalSM2.g:8309:2: ( RULE_ID )
            // InternalSM2.g:8310:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getNameInterfaceIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__NameInterfaceAssignment_1"


    // $ANTLR start "rule__Interface__EnumsAssignment_4"
    // InternalSM2.g:8319:1: rule__Interface__EnumsAssignment_4 : ( ruleEnum ) ;
    public final void rule__Interface__EnumsAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8323:1: ( ( ruleEnum ) )
            // InternalSM2.g:8324:2: ( ruleEnum )
            {
            // InternalSM2.g:8324:2: ( ruleEnum )
            // InternalSM2.g:8325:3: ruleEnum
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getEnumsEnumParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleEnum();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getEnumsEnumParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__EnumsAssignment_4"


    // $ANTLR start "rule__Interface__StructsAssignment_6"
    // InternalSM2.g:8334:1: rule__Interface__StructsAssignment_6 : ( ruleStruct ) ;
    public final void rule__Interface__StructsAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8338:1: ( ( ruleStruct ) )
            // InternalSM2.g:8339:2: ( ruleStruct )
            {
            // InternalSM2.g:8339:2: ( ruleStruct )
            // InternalSM2.g:8340:3: ruleStruct
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getStructsStructParserRuleCall_6_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleStruct();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getStructsStructParserRuleCall_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__StructsAssignment_6"


    // $ANTLR start "rule__Interface__ClausesAssignment_8"
    // InternalSM2.g:8349:1: rule__Interface__ClausesAssignment_8 : ( ruleHeadClause ) ;
    public final void rule__Interface__ClausesAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8353:1: ( ( ruleHeadClause ) )
            // InternalSM2.g:8354:2: ( ruleHeadClause )
            {
            // InternalSM2.g:8354:2: ( ruleHeadClause )
            // InternalSM2.g:8355:3: ruleHeadClause
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInterfaceAccess().getClausesHeadClauseParserRuleCall_8_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleHeadClause();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInterfaceAccess().getClausesHeadClauseParserRuleCall_8_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Interface__ClausesAssignment_8"


    // $ANTLR start "rule__Constructor__InputParamsAssignment_2"
    // InternalSM2.g:8364:1: rule__Constructor__InputParamsAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__Constructor__InputParamsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8368:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:8369:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:8369:2: ( ( RULE_ID ) )
            // InternalSM2.g:8370:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0()); 
            }
            // InternalSM2.g:8371:3: ( RULE_ID )
            // InternalSM2.g:8372:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getInputParamsInputParamIDTerminalRuleCall_2_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getInputParamsInputParamIDTerminalRuleCall_2_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getInputParamsInputParamCrossReference_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__InputParamsAssignment_2"


    // $ANTLR start "rule__Constructor__TypeAssignment_3"
    // InternalSM2.g:8383:1: rule__Constructor__TypeAssignment_3 : ( ( rule__Constructor__TypeAlternatives_3_0 ) ) ;
    public final void rule__Constructor__TypeAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8387:1: ( ( ( rule__Constructor__TypeAlternatives_3_0 ) ) )
            // InternalSM2.g:8388:2: ( ( rule__Constructor__TypeAlternatives_3_0 ) )
            {
            // InternalSM2.g:8388:2: ( ( rule__Constructor__TypeAlternatives_3_0 ) )
            // InternalSM2.g:8389:3: ( rule__Constructor__TypeAlternatives_3_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getTypeAlternatives_3_0()); 
            }
            // InternalSM2.g:8390:3: ( rule__Constructor__TypeAlternatives_3_0 )
            // InternalSM2.g:8390:4: rule__Constructor__TypeAlternatives_3_0
            {
            pushFollow(FOLLOW_2);
            rule__Constructor__TypeAlternatives_3_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getTypeAlternatives_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__TypeAssignment_3"


    // $ANTLR start "rule__Constructor__AttributesAssignment_6"
    // InternalSM2.g:8398:1: rule__Constructor__AttributesAssignment_6 : ( ( RULE_ID ) ) ;
    public final void rule__Constructor__AttributesAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8402:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:8403:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:8403:2: ( ( RULE_ID ) )
            // InternalSM2.g:8404:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0()); 
            }
            // InternalSM2.g:8405:3: ( RULE_ID )
            // InternalSM2.g:8406:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getAttributesAttributesIDTerminalRuleCall_6_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getAttributesAttributesIDTerminalRuleCall_6_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getAttributesAttributesCrossReference_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__AttributesAssignment_6"


    // $ANTLR start "rule__Constructor__ValueAssignment_8"
    // InternalSM2.g:8417:1: rule__Constructor__ValueAssignment_8 : ( ruleExpression ) ;
    public final void rule__Constructor__ValueAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8421:1: ( ( ruleExpression ) )
            // InternalSM2.g:8422:2: ( ruleExpression )
            {
            // InternalSM2.g:8422:2: ( ruleExpression )
            // InternalSM2.g:8423:3: ruleExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getConstructorAccess().getValueExpressionParserRuleCall_8_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getConstructorAccess().getValueExpressionParserRuleCall_8_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constructor__ValueAssignment_8"


    // $ANTLR start "rule__Event__NameEventAssignment_1"
    // InternalSM2.g:8432:1: rule__Event__NameEventAssignment_1 : ( RULE_ID ) ;
    public final void rule__Event__NameEventAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8436:1: ( ( RULE_ID ) )
            // InternalSM2.g:8437:2: ( RULE_ID )
            {
            // InternalSM2.g:8437:2: ( RULE_ID )
            // InternalSM2.g:8438:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getNameEventIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__NameEventAssignment_1"


    // $ANTLR start "rule__Event__InputParamsAssignment_3"
    // InternalSM2.g:8447:1: rule__Event__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Event__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8451:1: ( ( ruleInputParam ) )
            // InternalSM2.g:8452:2: ( ruleInputParam )
            {
            // InternalSM2.g:8452:2: ( ruleInputParam )
            // InternalSM2.g:8453:3: ruleInputParam
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEventAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Event__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__NameModifierAssignment_1"
    // InternalSM2.g:8462:1: rule__Modifier__NameModifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Modifier__NameModifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8466:1: ( ( RULE_ID ) )
            // InternalSM2.g:8467:2: ( RULE_ID )
            {
            // InternalSM2.g:8467:2: ( RULE_ID )
            // InternalSM2.g:8468:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__NameModifierAssignment_1"


    // $ANTLR start "rule__Modifier__InputParamsAssignment_3"
    // InternalSM2.g:8477:1: rule__Modifier__InputParamsAssignment_3 : ( ruleInputParam ) ;
    public final void rule__Modifier__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8481:1: ( ( ruleInputParam ) )
            // InternalSM2.g:8482:2: ( ruleInputParam )
            {
            // InternalSM2.g:8482:2: ( ruleInputParam )
            // InternalSM2.g:8483:3: ruleInputParam
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleInputParam();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getInputParamsInputParamParserRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__InputParamsAssignment_3"


    // $ANTLR start "rule__Modifier__ExprAssignment_7"
    // InternalSM2.g:8492:1: rule__Modifier__ExprAssignment_7 : ( RULE_STRING ) ;
    public final void rule__Modifier__ExprAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8496:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8497:2: ( RULE_STRING )
            {
            // InternalSM2.g:8497:2: ( RULE_STRING )
            // InternalSM2.g:8498:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Modifier__ExprAssignment_7"


    // $ANTLR start "rule__Mapping__TypeAssignment_2"
    // InternalSM2.g:8507:1: rule__Mapping__TypeAssignment_2 : ( ruleSingularType ) ;
    public final void rule__Mapping__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8511:1: ( ( ruleSingularType ) )
            // InternalSM2.g:8512:2: ( ruleSingularType )
            {
            // InternalSM2.g:8512:2: ( ruleSingularType )
            // InternalSM2.g:8513:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__TypeAssignment_2"


    // $ANTLR start "rule__Mapping__ExprAssignment_4"
    // InternalSM2.g:8522:1: rule__Mapping__ExprAssignment_4 : ( RULE_STRING ) ;
    public final void rule__Mapping__ExprAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8526:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8527:2: ( RULE_STRING )
            {
            // InternalSM2.g:8527:2: ( RULE_STRING )
            // InternalSM2.g:8528:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__ExprAssignment_4"


    // $ANTLR start "rule__Mapping__VisibilityAssignment_6"
    // InternalSM2.g:8537:1: rule__Mapping__VisibilityAssignment_6 : ( ruleVisibility ) ;
    public final void rule__Mapping__VisibilityAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8541:1: ( ( ruleVisibility ) )
            // InternalSM2.g:8542:2: ( ruleVisibility )
            {
            // InternalSM2.g:8542:2: ( ruleVisibility )
            // InternalSM2.g:8543:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__VisibilityAssignment_6"


    // $ANTLR start "rule__Mapping__NameMappingAssignment_7"
    // InternalSM2.g:8552:1: rule__Mapping__NameMappingAssignment_7 : ( RULE_ID ) ;
    public final void rule__Mapping__NameMappingAssignment_7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8556:1: ( ( RULE_ID ) )
            // InternalSM2.g:8557:2: ( RULE_ID )
            {
            // InternalSM2.g:8557:2: ( RULE_ID )
            // InternalSM2.g:8558:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_7_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Mapping__NameMappingAssignment_7"


    // $ANTLR start "rule__Struct__TypeStructAssignment"
    // InternalSM2.g:8567:1: rule__Struct__TypeStructAssignment : ( ( rule__Struct__TypeStructAlternatives_0 ) ) ;
    public final void rule__Struct__TypeStructAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8571:1: ( ( ( rule__Struct__TypeStructAlternatives_0 ) ) )
            // InternalSM2.g:8572:2: ( ( rule__Struct__TypeStructAlternatives_0 ) )
            {
            // InternalSM2.g:8572:2: ( ( rule__Struct__TypeStructAlternatives_0 ) )
            // InternalSM2.g:8573:3: ( rule__Struct__TypeStructAlternatives_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getStructAccess().getTypeStructAlternatives_0()); 
            }
            // InternalSM2.g:8574:3: ( rule__Struct__TypeStructAlternatives_0 )
            // InternalSM2.g:8574:4: rule__Struct__TypeStructAlternatives_0
            {
            pushFollow(FOLLOW_2);
            rule__Struct__TypeStructAlternatives_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getStructAccess().getTypeStructAlternatives_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Struct__TypeStructAssignment"


    // $ANTLR start "rule__PersonalizedStruct__NameStructAssignment_1"
    // InternalSM2.g:8582:1: rule__PersonalizedStruct__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__PersonalizedStruct__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8586:1: ( ( RULE_ID ) )
            // InternalSM2.g:8587:2: ( RULE_ID )
            {
            // InternalSM2.g:8587:2: ( RULE_ID )
            // InternalSM2.g:8588:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__NameStructAssignment_1"


    // $ANTLR start "rule__PersonalizedStruct__PropertiesAssignment_4"
    // InternalSM2.g:8597:1: rule__PersonalizedStruct__PropertiesAssignment_4 : ( ruleProperty ) ;
    public final void rule__PersonalizedStruct__PropertiesAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8601:1: ( ( ruleProperty ) )
            // InternalSM2.g:8602:2: ( ruleProperty )
            {
            // InternalSM2.g:8602:2: ( ruleProperty )
            // InternalSM2.g:8603:3: ruleProperty
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleProperty();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPersonalizedStructAccess().getPropertiesPropertyParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__PersonalizedStruct__PropertiesAssignment_4"


    // $ANTLR start "rule__User__NameStructAssignment_1"
    // InternalSM2.g:8612:1: rule__User__NameStructAssignment_1 : ( RULE_ID ) ;
    public final void rule__User__NameStructAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8616:1: ( ( RULE_ID ) )
            // InternalSM2.g:8617:2: ( RULE_ID )
            {
            // InternalSM2.g:8617:2: ( RULE_ID )
            // InternalSM2.g:8618:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameStructIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameStructAssignment_1"


    // $ANTLR start "rule__User__IdAdressAssignment_5"
    // InternalSM2.g:8627:1: rule__User__IdAdressAssignment_5 : ( RULE_ID ) ;
    public final void rule__User__IdAdressAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8631:1: ( ( RULE_ID ) )
            // InternalSM2.g:8632:2: ( RULE_ID )
            {
            // InternalSM2.g:8632:2: ( RULE_ID )
            // InternalSM2.g:8633:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getIdAdressIDTerminalRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__IdAdressAssignment_5"


    // $ANTLR start "rule__User__NameUserAssignment_10"
    // InternalSM2.g:8642:1: rule__User__NameUserAssignment_10 : ( RULE_STRING ) ;
    public final void rule__User__NameUserAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8646:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8647:2: ( RULE_STRING )
            {
            // InternalSM2.g:8647:2: ( RULE_STRING )
            // InternalSM2.g:8648:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getNameUserSTRINGTerminalRuleCall_10_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__NameUserAssignment_10"


    // $ANTLR start "rule__User__SurnameAssignment_15"
    // InternalSM2.g:8657:1: rule__User__SurnameAssignment_15 : ( RULE_STRING ) ;
    public final void rule__User__SurnameAssignment_15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8661:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8662:2: ( RULE_STRING )
            {
            // InternalSM2.g:8662:2: ( RULE_STRING )
            // InternalSM2.g:8663:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getSurnameSTRINGTerminalRuleCall_15_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__SurnameAssignment_15"


    // $ANTLR start "rule__User__EmailAssignment_20"
    // InternalSM2.g:8672:1: rule__User__EmailAssignment_20 : ( RULE_STRING ) ;
    public final void rule__User__EmailAssignment_20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8676:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8677:2: ( RULE_STRING )
            {
            // InternalSM2.g:8677:2: ( RULE_STRING )
            // InternalSM2.g:8678:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getEmailSTRINGTerminalRuleCall_20_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__EmailAssignment_20"


    // $ANTLR start "rule__User__AmountAssignment_26_0_1"
    // InternalSM2.g:8687:1: rule__User__AmountAssignment_26_0_1 : ( RULE_FLOAT ) ;
    public final void rule__User__AmountAssignment_26_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8691:1: ( ( RULE_FLOAT ) )
            // InternalSM2.g:8692:2: ( RULE_FLOAT )
            {
            // InternalSM2.g:8692:2: ( RULE_FLOAT )
            // InternalSM2.g:8693:3: RULE_FLOAT
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getUserAccess().getAmountFLOATTerminalRuleCall_26_0_1_0()); 
            }
            match(input,RULE_FLOAT,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getUserAccess().getAmountFLOATTerminalRuleCall_26_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__User__AmountAssignment_26_0_1"


    // $ANTLR start "rule__Enum__NameEnumAssignment_1"
    // InternalSM2.g:8702:1: rule__Enum__NameEnumAssignment_1 : ( RULE_ID ) ;
    public final void rule__Enum__NameEnumAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8706:1: ( ( RULE_ID ) )
            // InternalSM2.g:8707:2: ( RULE_ID )
            {
            // InternalSM2.g:8707:2: ( RULE_ID )
            // InternalSM2.g:8708:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Enum__NameEnumAssignment_1"


    // $ANTLR start "rule__Property__TypeAssignment_0"
    // InternalSM2.g:8717:1: rule__Property__TypeAssignment_0 : ( ruleSingularType ) ;
    public final void rule__Property__TypeAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8721:1: ( ( ruleSingularType ) )
            // InternalSM2.g:8722:2: ( ruleSingularType )
            {
            // InternalSM2.g:8722:2: ( ruleSingularType )
            // InternalSM2.g:8723:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__TypeAssignment_0"


    // $ANTLR start "rule__Property__VisibilityAssignment_1"
    // InternalSM2.g:8732:1: rule__Property__VisibilityAssignment_1 : ( ruleVisibility ) ;
    public final void rule__Property__VisibilityAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8736:1: ( ( ruleVisibility ) )
            // InternalSM2.g:8737:2: ( ruleVisibility )
            {
            // InternalSM2.g:8737:2: ( ruleVisibility )
            // InternalSM2.g:8738:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__VisibilityAssignment_1"


    // $ANTLR start "rule__Property__NamePropertyAssignment_2"
    // InternalSM2.g:8747:1: rule__Property__NamePropertyAssignment_2 : ( RULE_ID ) ;
    public final void rule__Property__NamePropertyAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8751:1: ( ( RULE_ID ) )
            // InternalSM2.g:8752:2: ( RULE_ID )
            {
            // InternalSM2.g:8752:2: ( RULE_ID )
            // InternalSM2.g:8753:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__NamePropertyAssignment_2"


    // $ANTLR start "rule__Property__InicializationAssignment_4_0"
    // InternalSM2.g:8762:1: rule__Property__InicializationAssignment_4_0 : ( RULE_STRING ) ;
    public final void rule__Property__InicializationAssignment_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8766:1: ( ( RULE_STRING ) )
            // InternalSM2.g:8767:2: ( RULE_STRING )
            {
            // InternalSM2.g:8767:2: ( RULE_STRING )
            // InternalSM2.g:8768:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Property__InicializationAssignment_4_0"


    // $ANTLR start "rule__InputParam__TypeAssignment_0_0"
    // InternalSM2.g:8777:1: rule__InputParam__TypeAssignment_0_0 : ( ruleSingularType ) ;
    public final void rule__InputParam__TypeAssignment_0_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8781:1: ( ( ruleSingularType ) )
            // InternalSM2.g:8782:2: ( ruleSingularType )
            {
            // InternalSM2.g:8782:2: ( ruleSingularType )
            // InternalSM2.g:8783:3: ruleSingularType
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSingularType();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getTypeSingularTypeEnumRuleCall_0_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__TypeAssignment_0_0"


    // $ANTLR start "rule__InputParam__IsArrayAssignment_0_1_0"
    // InternalSM2.g:8792:1: rule__InputParam__IsArrayAssignment_0_1_0 : ( ( '[]' ) ) ;
    public final void rule__InputParam__IsArrayAssignment_0_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8796:1: ( ( ( '[]' ) ) )
            // InternalSM2.g:8797:2: ( ( '[]' ) )
            {
            // InternalSM2.g:8797:2: ( ( '[]' ) )
            // InternalSM2.g:8798:3: ( '[]' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_1_0_0()); 
            }
            // InternalSM2.g:8799:3: ( '[]' )
            // InternalSM2.g:8800:4: '[]'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_1_0_0()); 
            }
            match(input,85,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_1_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getIsArrayLeftSquareBracketRightSquareBracketKeyword_0_1_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__IsArrayAssignment_0_1_0"


    // $ANTLR start "rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1"
    // InternalSM2.g:8811:1: rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1 : ( ( '[]' ) ) ;
    public final void rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8815:1: ( ( ( '[]' ) ) )
            // InternalSM2.g:8816:2: ( ( '[]' ) )
            {
            // InternalSM2.g:8816:2: ( ( '[]' ) )
            // InternalSM2.g:8817:3: ( '[]' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayLeftSquareBracketRightSquareBracketKeyword_0_1_1_0()); 
            }
            // InternalSM2.g:8818:3: ( '[]' )
            // InternalSM2.g:8819:4: '[]'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayLeftSquareBracketRightSquareBracketKeyword_0_1_1_0()); 
            }
            match(input,85,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayLeftSquareBracketRightSquareBracketKeyword_0_1_1_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNeedMoreDimensionArrayLeftSquareBracketRightSquareBracketKeyword_0_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NeedMoreDimensionArrayAssignment_0_1_1"


    // $ANTLR start "rule__InputParam__StorageAssignment_0_2_0"
    // InternalSM2.g:8830:1: rule__InputParam__StorageAssignment_0_2_0 : ( ( 'memory' ) ) ;
    public final void rule__InputParam__StorageAssignment_0_2_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8834:1: ( ( ( 'memory' ) ) )
            // InternalSM2.g:8835:2: ( ( 'memory' ) )
            {
            // InternalSM2.g:8835:2: ( ( 'memory' ) )
            // InternalSM2.g:8836:3: ( 'memory' )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0()); 
            }
            // InternalSM2.g:8837:3: ( 'memory' )
            // InternalSM2.g:8838:4: 'memory'
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0()); 
            }
            match(input,86,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getStorageMemoryKeyword_0_2_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__StorageAssignment_0_2_0"


    // $ANTLR start "rule__InputParam__NameParamAssignment_0_3"
    // InternalSM2.g:8849:1: rule__InputParam__NameParamAssignment_0_3 : ( RULE_ID ) ;
    public final void rule__InputParam__NameParamAssignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8853:1: ( ( RULE_ID ) )
            // InternalSM2.g:8854:2: ( RULE_ID )
            {
            // InternalSM2.g:8854:2: ( RULE_ID )
            // InternalSM2.g:8855:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getNameParamIDTerminalRuleCall_0_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__NameParamAssignment_0_3"


    // $ANTLR start "rule__InputParam__CommaAssignment_1"
    // InternalSM2.g:8864:1: rule__InputParam__CommaAssignment_1 : ( RULE_COMMA ) ;
    public final void rule__InputParam__CommaAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8868:1: ( ( RULE_COMMA ) )
            // InternalSM2.g:8869:2: ( RULE_COMMA )
            {
            // InternalSM2.g:8869:2: ( RULE_COMMA )
            // InternalSM2.g:8870:3: RULE_COMMA
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 
            }
            match(input,RULE_COMMA,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getInputParamAccess().getCommaCOMMATerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__InputParam__CommaAssignment_1"


    // $ANTLR start "rule__Restriction__Expr1Assignment_2"
    // InternalSM2.g:8879:1: rule__Restriction__Expr1Assignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr1Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8883:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:8884:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:8884:2: ( ruleSyntaxExpression )
            // InternalSM2.g:8885:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr1SyntaxExpressionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr1Assignment_2"


    // $ANTLR start "rule__Restriction__OperatorAssignment_3"
    // InternalSM2.g:8894:1: rule__Restriction__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__Restriction__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8898:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:8899:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:8899:2: ( ruleComparationOperator )
            // InternalSM2.g:8900:3: ruleComparationOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__OperatorAssignment_3"


    // $ANTLR start "rule__Restriction__Expr2Assignment_4"
    // InternalSM2.g:8909:1: rule__Restriction__Expr2Assignment_4 : ( ruleSyntaxExpression ) ;
    public final void rule__Restriction__Expr2Assignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8913:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:8914:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:8914:2: ( ruleSyntaxExpression )
            // InternalSM2.g:8915:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionAccess().getExpr2SyntaxExpressionParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Restriction__Expr2Assignment_4"


    // $ANTLR start "rule__RestrictionGas__ExprAssignment_2"
    // InternalSM2.g:8924:1: rule__RestrictionGas__ExprAssignment_2 : ( ruleSyntaxExpression ) ;
    public final void rule__RestrictionGas__ExprAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8928:1: ( ( ruleSyntaxExpression ) )
            // InternalSM2.g:8929:2: ( ruleSyntaxExpression )
            {
            // InternalSM2.g:8929:2: ( ruleSyntaxExpression )
            // InternalSM2.g:8930:3: ruleSyntaxExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleSyntaxExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__ExprAssignment_2"


    // $ANTLR start "rule__RestrictionGas__OperatorAssignment_3"
    // InternalSM2.g:8939:1: rule__RestrictionGas__OperatorAssignment_3 : ( ruleComparationOperator ) ;
    public final void rule__RestrictionGas__OperatorAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8943:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:8944:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:8944:2: ( ruleComparationOperator )
            // InternalSM2.g:8945:3: ruleComparationOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__OperatorAssignment_3"


    // $ANTLR start "rule__RestrictionGas__AmountAssignment_4"
    // InternalSM2.g:8954:1: rule__RestrictionGas__AmountAssignment_4 : ( RULE_NUMBER ) ;
    public final void rule__RestrictionGas__AmountAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8958:1: ( ( RULE_NUMBER ) )
            // InternalSM2.g:8959:2: ( RULE_NUMBER )
            {
            // InternalSM2.g:8959:2: ( RULE_NUMBER )
            // InternalSM2.g:8960:3: RULE_NUMBER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0()); 
            }
            match(input,RULE_NUMBER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getAmountNUMBERTerminalRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__AmountAssignment_4"


    // $ANTLR start "rule__RestrictionGas__TypeCoinAssignment_5"
    // InternalSM2.g:8969:1: rule__RestrictionGas__TypeCoinAssignment_5 : ( ruleCoin ) ;
    public final void rule__RestrictionGas__TypeCoinAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8973:1: ( ( ruleCoin ) )
            // InternalSM2.g:8974:2: ( ruleCoin )
            {
            // InternalSM2.g:8974:2: ( ruleCoin )
            // InternalSM2.g:8975:3: ruleCoin
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleCoin();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RestrictionGas__TypeCoinAssignment_5"


    // $ANTLR start "rule__Clause__RestrictionAssignment_3"
    // InternalSM2.g:8984:1: rule__Clause__RestrictionAssignment_3 : ( ruleRestriction ) ;
    public final void rule__Clause__RestrictionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:8988:1: ( ( ruleRestriction ) )
            // InternalSM2.g:8989:2: ( ruleRestriction )
            {
            // InternalSM2.g:8989:2: ( ruleRestriction )
            // InternalSM2.g:8990:3: ruleRestriction
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_3_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleRestriction();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionAssignment_3"


    // $ANTLR start "rule__Clause__RestrictionGasAssignment_4"
    // InternalSM2.g:8999:1: rule__Clause__RestrictionGasAssignment_4 : ( ruleRestrictionGas ) ;
    public final void rule__Clause__RestrictionGasAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9003:1: ( ( ruleRestrictionGas ) )
            // InternalSM2.g:9004:2: ( ruleRestrictionGas )
            {
            // InternalSM2.g:9004:2: ( ruleRestrictionGas )
            // InternalSM2.g:9005:3: ruleRestrictionGas
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleRestrictionGas();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__RestrictionGasAssignment_4"


    // $ANTLR start "rule__Clause__LocalAttributesAssignment_5"
    // InternalSM2.g:9014:1: rule__Clause__LocalAttributesAssignment_5 : ( ruleAttributes ) ;
    public final void rule__Clause__LocalAttributesAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9018:1: ( ( ruleAttributes ) )
            // InternalSM2.g:9019:2: ( ruleAttributes )
            {
            // InternalSM2.g:9019:2: ( ruleAttributes )
            // InternalSM2.g:9020:3: ruleAttributes
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getLocalAttributesAttributesParserRuleCall_5_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleAttributes();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getLocalAttributesAttributesParserRuleCall_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__LocalAttributesAssignment_5"


    // $ANTLR start "rule__Clause__ExpressionAssignment_6"
    // InternalSM2.g:9029:1: rule__Clause__ExpressionAssignment_6 : ( ruleExpression ) ;
    public final void rule__Clause__ExpressionAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9033:1: ( ( ruleExpression ) )
            // InternalSM2.g:9034:2: ( ruleExpression )
            {
            // InternalSM2.g:9034:2: ( ruleExpression )
            // InternalSM2.g:9035:3: ruleExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_6_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_6_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Clause__ExpressionAssignment_6"


    // $ANTLR start "rule__HeadClause__NameFunctionAssignment_1"
    // InternalSM2.g:9044:1: rule__HeadClause__NameFunctionAssignment_1 : ( RULE_ID ) ;
    public final void rule__HeadClause__NameFunctionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9048:1: ( ( RULE_ID ) )
            // InternalSM2.g:9049:2: ( RULE_ID )
            {
            // InternalSM2.g:9049:2: ( RULE_ID )
            // InternalSM2.g:9050:3: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getNameFunctionIDTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__NameFunctionAssignment_1"


    // $ANTLR start "rule__HeadClause__InputParamsAssignment_3"
    // InternalSM2.g:9059:1: rule__HeadClause__InputParamsAssignment_3 : ( ( RULE_ID ) ) ;
    public final void rule__HeadClause__InputParamsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9063:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:9064:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:9064:2: ( ( RULE_ID ) )
            // InternalSM2.g:9065:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            }
            // InternalSM2.g:9066:3: ( RULE_ID )
            // InternalSM2.g:9067:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getInputParamsInputParamIDTerminalRuleCall_3_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getInputParamsInputParamCrossReference_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__InputParamsAssignment_3"


    // $ANTLR start "rule__HeadClause__VisibilityAccessAssignment_4"
    // InternalSM2.g:9078:1: rule__HeadClause__VisibilityAccessAssignment_4 : ( ruleVisibility ) ;
    public final void rule__HeadClause__VisibilityAccessAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9082:1: ( ( ruleVisibility ) )
            // InternalSM2.g:9083:2: ( ruleVisibility )
            {
            // InternalSM2.g:9083:2: ( ruleVisibility )
            // InternalSM2.g:9084:3: ruleVisibility
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleVisibility();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__VisibilityAccessAssignment_4"


    // $ANTLR start "rule__HeadClause__ModifierAssignment_5"
    // InternalSM2.g:9093:1: rule__HeadClause__ModifierAssignment_5 : ( ( RULE_ID ) ) ;
    public final void rule__HeadClause__ModifierAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9097:1: ( ( ( RULE_ID ) ) )
            // InternalSM2.g:9098:2: ( ( RULE_ID ) )
            {
            // InternalSM2.g:9098:2: ( ( RULE_ID ) )
            // InternalSM2.g:9099:3: ( RULE_ID )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0()); 
            }
            // InternalSM2.g:9100:3: ( RULE_ID )
            // InternalSM2.g:9101:4: RULE_ID
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getHeadClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            }
            match(input,RULE_ID,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getModifierModifierIDTerminalRuleCall_5_0_1()); 
            }

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getHeadClauseAccess().getModifierModifierCrossReference_5_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__HeadClause__ModifierAssignment_5"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_0_1"
    // InternalSM2.g:9112:1: rule__ArithmethicalExpression__Op1Assignment_0_1 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_0_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9116:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9117:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9117:2: ( RULE_INTEGER )
            // InternalSM2.g:9118:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_0_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_0_1"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_0_2"
    // InternalSM2.g:9127:1: rule__ArithmethicalExpression__OperatorAssignment_0_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_0_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9131:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:9132:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:9132:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:9133:3: ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_0_2"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_0_3"
    // InternalSM2.g:9142:1: rule__ArithmethicalExpression__Op2Assignment_0_3 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_0_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9146:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9147:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9147:2: ( RULE_INTEGER )
            // InternalSM2.g:9148:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_0_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_0_3"


    // $ANTLR start "rule__ArithmethicalExpression__Op1Assignment_1_0"
    // InternalSM2.g:9157:1: rule__ArithmethicalExpression__Op1Assignment_1_0 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalExpression__Op1Assignment_1_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9161:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9162:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9162:2: ( RULE_INTEGER )
            // InternalSM2.g:9163:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op1Assignment_1_0"


    // $ANTLR start "rule__ArithmethicalExpression__OperatorAssignment_1_1"
    // InternalSM2.g:9172:1: rule__ArithmethicalExpression__OperatorAssignment_1_1 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalExpression__OperatorAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9176:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:9177:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:9177:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:9178:3: ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__OperatorAssignment_1_1"


    // $ANTLR start "rule__ArithmethicalExpression__Op2Assignment_1_2"
    // InternalSM2.g:9187:1: rule__ArithmethicalExpression__Op2Assignment_1_2 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalExpression__Op2Assignment_1_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9191:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9192:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9192:2: ( RULE_INTEGER )
            // InternalSM2.g:9193:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalExpressionAccess().getOp2INTEGERTerminalRuleCall_1_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalExpression__Op2Assignment_1_2"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Op1Assignment_1"
    // InternalSM2.g:9202:1: rule__ArithmethicalLogicalExpression__Op1Assignment_1 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalLogicalExpression__Op1Assignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9206:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9207:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9207:2: ( RULE_INTEGER )
            // InternalSM2.g:9208:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp1INTEGERTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Op1Assignment_1"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Operator1Assignment_2"
    // InternalSM2.g:9217:1: rule__ArithmethicalLogicalExpression__Operator1Assignment_2 : ( ruleArithmeticalOperator ) ;
    public final void rule__ArithmethicalLogicalExpression__Operator1Assignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9221:1: ( ( ruleArithmeticalOperator ) )
            // InternalSM2.g:9222:2: ( ruleArithmeticalOperator )
            {
            // InternalSM2.g:9222:2: ( ruleArithmeticalOperator )
            // InternalSM2.g:9223:3: ruleArithmeticalOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmeticalOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator1ArithmeticalOperatorEnumRuleCall_2_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Operator1Assignment_2"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Op2Assignment_3"
    // InternalSM2.g:9232:1: rule__ArithmethicalLogicalExpression__Op2Assignment_3 : ( RULE_INTEGER ) ;
    public final void rule__ArithmethicalLogicalExpression__Op2Assignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9236:1: ( ( RULE_INTEGER ) )
            // InternalSM2.g:9237:2: ( RULE_INTEGER )
            {
            // InternalSM2.g:9237:2: ( RULE_INTEGER )
            // InternalSM2.g:9238:3: RULE_INTEGER
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0()); 
            }
            match(input,RULE_INTEGER,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOp2INTEGERTerminalRuleCall_3_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Op2Assignment_3"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__Operator2Assignment_4"
    // InternalSM2.g:9247:1: rule__ArithmethicalLogicalExpression__Operator2Assignment_4 : ( ruleComparationOperator ) ;
    public final void rule__ArithmethicalLogicalExpression__Operator2Assignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9251:1: ( ( ruleComparationOperator ) )
            // InternalSM2.g:9252:2: ( ruleComparationOperator )
            {
            // InternalSM2.g:9252:2: ( ruleComparationOperator )
            // InternalSM2.g:9253:3: ruleComparationOperator
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleComparationOperator();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getOperator2ComparationOperatorEnumRuleCall_4_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__Operator2Assignment_4"


    // $ANTLR start "rule__ArithmethicalLogicalExpression__ExprAssignment_5_0"
    // InternalSM2.g:9262:1: rule__ArithmethicalLogicalExpression__ExprAssignment_5_0 : ( ruleArithmethicalExpression ) ;
    public final void rule__ArithmethicalLogicalExpression__ExprAssignment_5_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9266:1: ( ( ruleArithmethicalExpression ) )
            // InternalSM2.g:9267:2: ( ruleArithmethicalExpression )
            {
            // InternalSM2.g:9267:2: ( ruleArithmethicalExpression )
            // InternalSM2.g:9268:3: ruleArithmethicalExpression
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0_0()); 
            }
            pushFollow(FOLLOW_2);
            ruleArithmethicalExpression();

            state._fsp--;
            if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getArithmethicalLogicalExpressionAccess().getExprArithmethicalExpressionParserRuleCall_5_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ArithmethicalLogicalExpression__ExprAssignment_5_0"


    // $ANTLR start "rule__SyntaxExpression__TextAssignment_0"
    // InternalSM2.g:9277:1: rule__SyntaxExpression__TextAssignment_0 : ( RULE_STRING ) ;
    public final void rule__SyntaxExpression__TextAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9281:1: ( ( RULE_STRING ) )
            // InternalSM2.g:9282:2: ( RULE_STRING )
            {
            // InternalSM2.g:9282:2: ( RULE_STRING )
            // InternalSM2.g:9283:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__SyntaxExpression__TextAssignment_0"


    // $ANTLR start "rule__ShortComment__ExprAssignment_1"
    // InternalSM2.g:9292:1: rule__ShortComment__ExprAssignment_1 : ( RULE_STRING ) ;
    public final void rule__ShortComment__ExprAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9296:1: ( ( RULE_STRING ) )
            // InternalSM2.g:9297:2: ( RULE_STRING )
            {
            // InternalSM2.g:9297:2: ( RULE_STRING )
            // InternalSM2.g:9298:3: RULE_STRING
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            }
            match(input,RULE_STRING,FOLLOW_2); if (state.failed) return ;
            if ( state.backtracking==0 ) {
               after(grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ShortComment__ExprAssignment_1"


    // $ANTLR start "rule__LongComment__ExpressionAssignment_1"
    // InternalSM2.g:9307:1: rule__LongComment__ExpressionAssignment_1 : ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) ;
    public final void rule__LongComment__ExpressionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalSM2.g:9311:1: ( ( ( rule__LongComment__ExpressionAlternatives_1_0 ) ) )
            // InternalSM2.g:9312:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            {
            // InternalSM2.g:9312:2: ( ( rule__LongComment__ExpressionAlternatives_1_0 ) )
            // InternalSM2.g:9313:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            {
            if ( state.backtracking==0 ) {
               before(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 
            }
            // InternalSM2.g:9314:3: ( rule__LongComment__ExpressionAlternatives_1_0 )
            // InternalSM2.g:9314:4: rule__LongComment__ExpressionAlternatives_1_0
            {
            pushFollow(FOLLOW_2);
            rule__LongComment__ExpressionAlternatives_1_0();

            state._fsp--;
            if (state.failed) return ;

            }

            if ( state.backtracking==0 ) {
               after(grammarAccess.getLongCommentAccess().getExpressionAlternatives_1_0()); 
            }

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__LongComment__ExpressionAssignment_1"

    // Delegated rules


    protected DFA8 dfa8 = new DFA8(this);
    protected DFA12 dfa12 = new DFA12(this);
    protected DFA51 dfa51 = new DFA51(this);
    protected DFA63 dfa63 = new DFA63(this);
    protected DFA65 dfa65 = new DFA65(this);
    protected DFA74 dfa74 = new DFA74(this);
    static final String dfa_1s = "\16\uffff";
    static final String dfa_2s = "\1\112\1\4\1\16\1\15\1\43\1\uffff\1\4\1\14\1\5\1\uffff\1\14\1\15\1\17\1\4";
    static final String dfa_3s = "\1\112\1\4\1\16\2\55\1\uffff\1\57\1\104\1\14\1\uffff\1\14\2\55\1\57";
    static final String dfa_4s = "\5\uffff\1\1\3\uffff\1\2\4\uffff";
    static final String dfa_5s = "\16\uffff}>";
    static final String[] dfa_6s = {
            "\1\1",
            "\1\2",
            "\1\3",
            "\1\4\25\uffff\5\5\1\6\5\5",
            "\5\5\1\6\5\5",
            "",
            "\1\7\33\uffff\2\5\14\uffff\2\5",
            "\1\11\67\uffff\1\10",
            "\1\5\1\12\5\uffff\1\5",
            "",
            "\1\13",
            "\1\14\1\uffff\1\5\23\uffff\4\5\1\15\6\5",
            "\1\5\23\uffff\4\5\1\15\6\5",
            "\1\5\1\uffff\1\11\31\uffff\2\5\14\uffff\2\5"
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1002:1: rule__Struct__TypeStructAlternatives_0 : ( ( rulePersonalizedStruct ) | ( ruleUser ) );";
        }
    }
    static final String dfa_7s = "\14\uffff";
    static final String dfa_8s = "\2\uffff\1\3\11\uffff";
    static final String dfa_9s = "\3\5\1\uffff\1\72\1\uffff\4\5\1\22\1\uffff";
    static final String dfa_10s = "\1\21\1\5\1\75\1\uffff\1\75\1\uffff\4\5\1\67\1\uffff";
    static final String dfa_11s = "\3\uffff\1\3\1\uffff\1\1\5\uffff\1\2";
    static final String dfa_12s = "\14\uffff}>";
    static final String[] dfa_13s = {
            "\1\2\1\3\12\uffff\1\1",
            "\1\4",
            "\2\3\5\uffff\2\3\1\uffff\1\3\1\uffff\1\3\50\uffff\4\5",
            "",
            "\1\6\1\7\1\10\1\11",
            "",
            "\1\12",
            "\1\12",
            "\1\12",
            "\1\12",
            "\1\5\11\uffff\4\13\26\uffff\2\13",
            ""
    };

    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final short[] dfa_8 = DFA.unpackEncodedString(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final char[] dfa_10 = DFA.unpackEncodedStringToUnsignedChars(dfa_10s);
    static final short[] dfa_11 = DFA.unpackEncodedString(dfa_11s);
    static final short[] dfa_12 = DFA.unpackEncodedString(dfa_12s);
    static final short[][] dfa_13 = unpackEncodedStringArray(dfa_13s);

    class DFA12 extends DFA {

        public DFA12(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 12;
            this.eot = dfa_7;
            this.eof = dfa_8;
            this.min = dfa_9;
            this.max = dfa_10;
            this.accept = dfa_11;
            this.special = dfa_12;
            this.transition = dfa_13;
        }
        public String getDescription() {
            return "1086:1: rule__Expression__Alternatives : ( ( ruleArithmethicalExpression ) | ( ruleArithmethicalLogicalExpression ) | ( ruleSyntaxExpression ) );";
        }
    }
    static final String dfa_14s = "\1\2\1\4\14\uffff";
    static final String dfa_15s = "\2\4\1\uffff\1\4\1\uffff\1\21\6\4\1\22\1\14";
    static final String dfa_16s = "\2\120\1\uffff\1\4\1\uffff\1\21\2\57\5\22\1\116";
    static final String dfa_17s = "\2\uffff\1\2\1\uffff\1\1\11\uffff";
    static final String[] dfa_18s = {
            "\3\2\6\uffff\1\1\1\uffff\1\2\1\uffff\1\2\21\uffff\13\2\25\uffff\1\2\1\uffff\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\1\uffff\3\2",
            "\3\4\5\uffff\1\2\1\4\1\uffff\1\4\1\uffff\1\4\21\uffff\13\4\25\uffff\1\4\1\uffff\2\4\1\uffff\1\4\1\uffff\1\4\1\uffff\1\4\1\uffff\1\3\2\4",
            "",
            "\1\5",
            "",
            "\1\6",
            "\1\7\33\uffff\1\10\1\12\14\uffff\1\11\1\13",
            "\1\7\33\uffff\1\10\1\12\14\uffff\1\11\1\13",
            "\1\14\15\uffff\1\15",
            "\1\14\15\uffff\1\15",
            "\1\14\15\uffff\1\15",
            "\1\14\15\uffff\1\15",
            "\1\15",
            "\1\2\1\uffff\1\4\77\uffff\1\2"
    };
    static final short[] dfa_14 = DFA.unpackEncodedString(dfa_14s);
    static final char[] dfa_15 = DFA.unpackEncodedStringToUnsignedChars(dfa_15s);
    static final char[] dfa_16 = DFA.unpackEncodedStringToUnsignedChars(dfa_16s);
    static final short[] dfa_17 = DFA.unpackEncodedString(dfa_17s);
    static final short[][] dfa_18 = unpackEncodedStringArray(dfa_18s);

    class DFA51 extends DFA {

        public DFA51(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 51;
            this.eot = dfa_1;
            this.eof = dfa_14;
            this.min = dfa_15;
            this.max = dfa_16;
            this.accept = dfa_17;
            this.special = dfa_5;
            this.transition = dfa_18;
        }
        public String getDescription() {
            return "4354:2: ( RULE_EOLINE )?";
        }
    }

    class DFA63 extends DFA {

        public DFA63(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 63;
            this.eot = dfa_1;
            this.eof = dfa_14;
            this.min = dfa_15;
            this.max = dfa_16;
            this.accept = dfa_17;
            this.special = dfa_5;
            this.transition = dfa_18;
        }
        public String getDescription() {
            return "5191:2: ( RULE_EOLINE )?";
        }
    }
    static final String dfa_19s = "\142\uffff";
    static final String dfa_20s = "\1\2\1\3\140\uffff";
    static final String dfa_21s = "\2\4\2\uffff\1\4\1\14\1\16\1\15\1\43\17\4\1\104\1\14\2\5\1\15\2\14\1\15\1\14\1\47\1\6\1\17\14\4\1\15\1\14\4\4\1\104\1\4\1\17\1\4\1\6\1\15\1\5\1\4\1\14\1\47\1\6\2\14\1\15\1\21\1\14\1\17\1\4\1\6\1\15\5\4\1\14\1\47\1\6\1\22\2\14\1\23\1\15\1\14\1\44\1\113\1\5\1\26\1\14\1\15\1\14\1\17\2\4";
    static final String dfa_22s = "\2\120\2\uffff\1\4\1\116\1\16\2\55\13\57\4\4\2\104\2\14\1\47\2\14\1\55\1\14\1\47\1\6\1\55\13\57\1\120\1\55\1\104\4\4\1\104\1\120\1\55\1\57\1\6\1\47\1\14\1\4\1\14\1\47\1\6\2\14\1\55\1\21\1\104\1\55\1\57\1\6\1\47\1\57\4\22\1\14\1\47\1\6\1\22\1\116\1\104\1\23\1\44\1\14\1\44\1\113\1\104\1\26\1\14\1\17\1\14\1\17\2\120";
    static final String dfa_23s = "\2\uffff\1\2\1\1\136\uffff";
    static final String dfa_24s = "\142\uffff}>";
    static final String[] dfa_25s = {
            "\3\2\6\uffff\1\1\1\uffff\1\2\1\uffff\1\2\21\uffff\13\2\25\uffff\1\2\1\uffff\2\2\1\uffff\1\2\1\uffff\1\2\1\uffff\1\2\1\uffff\3\2",
            "\3\3\6\uffff\1\5\1\uffff\1\3\1\uffff\1\3\21\uffff\13\3\25\uffff\1\3\1\uffff\2\3\1\uffff\1\3\1\uffff\1\4\1\uffff\1\3\1\uffff\3\3",
            "",
            "",
            "\1\6",
            "\1\2\1\3\74\uffff\1\3\3\uffff\1\2",
            "\1\7",
            "\1\10\25\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20\1\21\1\22\1\23",
            "\1\11\1\12\1\13\1\14\1\15\1\16\1\17\1\20\1\21\1\22\1\23",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\31\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30\33\uffff\1\24\1\26\14\uffff\1\25\1\27",
            "\1\30",
            "\1\30",
            "\1\30",
            "\1\30",
            "\1\32",
            "\1\34\67\uffff\1\33",
            "\1\36\1\35\5\uffff\1\37",
            "\1\36\1\40\5\uffff\1\37",
            "\1\41\31\uffff\1\42",
            "\1\37",
            "\1\37",
            "\1\43\1\uffff\1\57\23\uffff\1\44\1\45\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\60",
            "\1\42",
            "\1\61",
            "\1\57\23\uffff\1\44\1\45\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\66\33\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\3\10\uffff\1\67\1\uffff\1\3\23\uffff\13\3\25\uffff\1\3\1\uffff\2\3\1\uffff\1\3\1\uffff\1\4\1\uffff\1\3\1\uffff\3\3",
            "\1\70\1\uffff\1\57\23\uffff\1\44\1\45\1\46\1\47\1\71\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\73\67\uffff\1\72",
            "\1\66",
            "\1\66",
            "\1\66",
            "\1\66",
            "\1\74",
            "\1\3\7\uffff\2\2\1\uffff\1\3\23\uffff\13\3\25\uffff\1\3\1\uffff\2\3\1\uffff\1\3\1\uffff\1\4\1\uffff\1\3\1\uffff\1\75\2\3",
            "\1\57\23\uffff\1\44\1\45\1\46\1\47\1\71\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\66\1\uffff\1\61\31\uffff\1\62\1\64\14\uffff\1\63\1\65",
            "\1\76",
            "\1\77\31\uffff\1\100",
            "\1\102\1\101\5\uffff\1\103",
            "\1\104",
            "\1\73",
            "\1\100",
            "\1\105",
            "\1\103",
            "\1\103",
            "\1\106\1\uffff\1\57\23\uffff\1\44\1\45\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\107",
            "\1\111\67\uffff\1\110",
            "\1\57\23\uffff\1\44\1\45\1\46\1\47\1\50\1\51\1\52\1\53\1\54\1\55\1\56",
            "\1\112\33\uffff\1\113\1\115\14\uffff\1\114\1\116",
            "\1\117",
            "\1\120\31\uffff\1\121",
            "\1\112\33\uffff\1\113\1\115\14\uffff\1\114\1\116",
            "\1\122\15\uffff\1\123",
            "\1\122\15\uffff\1\123",
            "\1\122\15\uffff\1\123",
            "\1\122\15\uffff\1\123",
            "\1\111",
            "\1\121",
            "\1\124",
            "\1\123",
            "\1\2\1\uffff\1\3\77\uffff\1\2",
            "\1\126\67\uffff\1\125",
            "\1\127",
            "\1\130\26\uffff\1\131",
            "\1\126",
            "\1\131",
            "\1\132",
            "\1\134\6\uffff\1\135\67\uffff\1\133",
            "\1\136",
            "\1\135",
            "\1\137\1\uffff\1\140",
            "\1\135",
            "\1\140",
            "\1\3\10\uffff\1\141\1\uffff\1\3\23\uffff\13\3\25\uffff\1\3\1\uffff\2\3\1\uffff\1\3\1\uffff\1\4\1\uffff\1\3\1\uffff\3\3",
            "\1\3\7\uffff\2\2\1\uffff\1\3\23\uffff\13\3\25\uffff\1\3\1\uffff\2\3\1\uffff\1\3\1\uffff\1\4\1\uffff\1\3\1\uffff\1\75\2\3"
    };

    static final short[] dfa_19 = DFA.unpackEncodedString(dfa_19s);
    static final short[] dfa_20 = DFA.unpackEncodedString(dfa_20s);
    static final char[] dfa_21 = DFA.unpackEncodedStringToUnsignedChars(dfa_21s);
    static final char[] dfa_22 = DFA.unpackEncodedStringToUnsignedChars(dfa_22s);
    static final short[] dfa_23 = DFA.unpackEncodedString(dfa_23s);
    static final short[] dfa_24 = DFA.unpackEncodedString(dfa_24s);
    static final short[][] dfa_25 = unpackEncodedStringArray(dfa_25s);

    class DFA65 extends DFA {

        public DFA65(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 65;
            this.eot = dfa_19;
            this.eof = dfa_20;
            this.min = dfa_21;
            this.max = dfa_22;
            this.accept = dfa_23;
            this.special = dfa_24;
            this.transition = dfa_25;
        }
        public String getDescription() {
            return "5657:2: ( RULE_EOLINE )?";
        }
    }
    static final String dfa_26s = "\17\uffff";
    static final String dfa_27s = "\1\4\1\21\1\uffff\1\5\1\34\1\14\6\5\1\15\1\uffff\1\34";
    static final String dfa_28s = "\1\115\1\21\1\uffff\1\6\2\67\6\25\1\15\1\uffff\1\67";
    static final String dfa_29s = "\2\uffff\1\2\12\uffff\1\1\1\uffff";
    static final String dfa_30s = "\17\uffff}>";
    static final String[] dfa_31s = {
            "\3\2\12\uffff\1\2\21\uffff\13\2\32\uffff\1\2\1\uffff\1\2\1\uffff\1\2\1\1",
            "\1\3",
            "",
            "\1\5\1\4",
            "\1\6\1\10\1\7\1\11\26\uffff\1\12\1\13",
            "\1\14\17\uffff\1\6\1\10\1\7\1\11\26\uffff\1\12\1\13",
            "\2\15\16\uffff\1\2",
            "\2\15\16\uffff\1\2",
            "\2\15\16\uffff\1\2",
            "\2\15\16\uffff\1\2",
            "\2\15\16\uffff\1\2",
            "\2\15\16\uffff\1\2",
            "\1\16",
            "",
            "\1\6\1\10\1\7\1\11\26\uffff\1\12\1\13"
    };

    static final short[] dfa_26 = DFA.unpackEncodedString(dfa_26s);
    static final char[] dfa_27 = DFA.unpackEncodedStringToUnsignedChars(dfa_27s);
    static final char[] dfa_28 = DFA.unpackEncodedStringToUnsignedChars(dfa_28s);
    static final short[] dfa_29 = DFA.unpackEncodedString(dfa_29s);
    static final short[] dfa_30 = DFA.unpackEncodedString(dfa_30s);
    static final short[][] dfa_31 = unpackEncodedStringArray(dfa_31s);

    class DFA74 extends DFA {

        public DFA74(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 74;
            this.eot = dfa_26;
            this.eof = dfa_26;
            this.min = dfa_27;
            this.max = dfa_28;
            this.accept = dfa_29;
            this.special = dfa_30;
            this.transition = dfa_31;
        }
        public String getDescription() {
            return "6684:2: ( rule__Clause__RestrictionAssignment_3 )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000030000000L,0x0000000000100000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000002000L,0x0000000000080005L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000001L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000004L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x8000000000004000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00003FF80000A010L,0x000000000001D568L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00003FF800000012L,0x0000000000001500L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000020L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000000002L,0x0000000000004000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000002L,0x0000000000018000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x00000000C0000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000001000L,0x0000000000000002L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000000002000L,0x0000000000001000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000002L,0x0000000000001000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000000002000L,0x0000000000000500L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000500L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000000001000L,0x0000000000004000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000300000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000010L,0x0000000000000010L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000000020060L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x00003FF800040000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x00003FF800000002L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000002040L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000002000L,0x0000000000000080L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x00003FF800000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000C00300000010L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x00003FF800002000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x00003FF800002002L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000010000002000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000000000001000L,0x0000000000000010L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000008000002000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000001000002000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000800L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000001020L,0x0000000000000010L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x000000000000A000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x0000000000000042L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000010L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0000000000001060L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0000000400000010L,0x0000000000600000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0000000000000000L,0x0000000000200000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0000000000000002L,0x0000000000200000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x00C00000F0000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x003F000000000000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x00003FF800020070L,0x0000000000003500L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x00003FF800020072L,0x0000000000003500L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x3C00000000000000L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000020020L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000FC0L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});

}