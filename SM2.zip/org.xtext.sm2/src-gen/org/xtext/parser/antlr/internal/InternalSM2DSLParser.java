package org.xtext.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.services.SM2DSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalSM2DSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'pragma'", "'solidity'", "';\\n'", "'contract'", "'is'", "'{\\n'", "'}'", "'^'", "'>'", "'>='", "'.'", "'import'", "'modifier'", "'('", "')'", "'_;'", "'}\\n'", "'mapping('", "'=>'", "';'", "'struct'", "'enum'", "'{'", "','", "'='", "'require'", "');\\n'", "'function'", "'\\n'", "'selfdesctruct'", "'//'", "'/n'", "'/*'", "'*/'", "'int'", "'uint'", "'uint8'", "'string'", "'address'", "'address payable'", "'double'", "'bool'", "'public'", "'private'", "'internal'", "'ether'", "'wei'", "'gwei'", "'pwei'", "'finney'", "'szabo'", "'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'+'", "'-'", "'*'", "'/'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalSM2DSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalSM2DSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalSM2DSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalSM2DSL.g"; }



     	private SM2DSLGrammarAccess grammarAccess;

        public InternalSM2DSLParser(TokenStream input, SM2DSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "SmartContract";
       	}

       	@Override
       	protected SM2DSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleSmartContract"
    // InternalSM2DSL.g:65:1: entryRuleSmartContract returns [EObject current=null] : iv_ruleSmartContract= ruleSmartContract EOF ;
    public final EObject entryRuleSmartContract() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSmartContract = null;


        try {
            // InternalSM2DSL.g:65:54: (iv_ruleSmartContract= ruleSmartContract EOF )
            // InternalSM2DSL.g:66:2: iv_ruleSmartContract= ruleSmartContract EOF
            {
             newCompositeNode(grammarAccess.getSmartContractRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSmartContract=ruleSmartContract();

            state._fsp--;

             current =iv_ruleSmartContract; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSmartContract"


    // $ANTLR start "ruleSmartContract"
    // InternalSM2DSL.g:72:1: ruleSmartContract returns [EObject current=null] : ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) otherlv_3= ';\\n' ( (lv_imports_4_0= ruleImport ) )* ( (lv_contract_5_0= 'contract' ) ) ( (lv_nameContract_6_0= RULE_ID ) ) (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )? otherlv_9= '{\\n' ( (lv_attributes_10_0= ruleAttributes ) )* ( (lv_modifier_11_0= ruleModifier ) )* ( (lv_clauses_12_0= ruleClause ) )* ( (lv_comments_13_0= ruleComment ) )* otherlv_14= '}' ) ;
    public final EObject ruleSmartContract() throws RecognitionException {
        EObject current = null;

        Token lv_compiler_0_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token lv_contract_5_0=null;
        Token lv_nameContract_6_0=null;
        Token otherlv_7=null;
        Token lv_nameContractFather_8_0=null;
        Token otherlv_9=null;
        Token otherlv_14=null;
        EObject lv_VersionCompiler_2_0 = null;

        EObject lv_imports_4_0 = null;

        EObject lv_attributes_10_0 = null;

        EObject lv_modifier_11_0 = null;

        EObject lv_clauses_12_0 = null;

        EObject lv_comments_13_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:78:2: ( ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) otherlv_3= ';\\n' ( (lv_imports_4_0= ruleImport ) )* ( (lv_contract_5_0= 'contract' ) ) ( (lv_nameContract_6_0= RULE_ID ) ) (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )? otherlv_9= '{\\n' ( (lv_attributes_10_0= ruleAttributes ) )* ( (lv_modifier_11_0= ruleModifier ) )* ( (lv_clauses_12_0= ruleClause ) )* ( (lv_comments_13_0= ruleComment ) )* otherlv_14= '}' ) )
            // InternalSM2DSL.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) otherlv_3= ';\\n' ( (lv_imports_4_0= ruleImport ) )* ( (lv_contract_5_0= 'contract' ) ) ( (lv_nameContract_6_0= RULE_ID ) ) (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )? otherlv_9= '{\\n' ( (lv_attributes_10_0= ruleAttributes ) )* ( (lv_modifier_11_0= ruleModifier ) )* ( (lv_clauses_12_0= ruleClause ) )* ( (lv_comments_13_0= ruleComment ) )* otherlv_14= '}' )
            {
            // InternalSM2DSL.g:79:2: ( ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) otherlv_3= ';\\n' ( (lv_imports_4_0= ruleImport ) )* ( (lv_contract_5_0= 'contract' ) ) ( (lv_nameContract_6_0= RULE_ID ) ) (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )? otherlv_9= '{\\n' ( (lv_attributes_10_0= ruleAttributes ) )* ( (lv_modifier_11_0= ruleModifier ) )* ( (lv_clauses_12_0= ruleClause ) )* ( (lv_comments_13_0= ruleComment ) )* otherlv_14= '}' )
            // InternalSM2DSL.g:80:3: ( (lv_compiler_0_0= 'pragma' ) ) otherlv_1= 'solidity' ( (lv_VersionCompiler_2_0= ruleVersion ) ) otherlv_3= ';\\n' ( (lv_imports_4_0= ruleImport ) )* ( (lv_contract_5_0= 'contract' ) ) ( (lv_nameContract_6_0= RULE_ID ) ) (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )? otherlv_9= '{\\n' ( (lv_attributes_10_0= ruleAttributes ) )* ( (lv_modifier_11_0= ruleModifier ) )* ( (lv_clauses_12_0= ruleClause ) )* ( (lv_comments_13_0= ruleComment ) )* otherlv_14= '}'
            {
            // InternalSM2DSL.g:80:3: ( (lv_compiler_0_0= 'pragma' ) )
            // InternalSM2DSL.g:81:4: (lv_compiler_0_0= 'pragma' )
            {
            // InternalSM2DSL.g:81:4: (lv_compiler_0_0= 'pragma' )
            // InternalSM2DSL.g:82:5: lv_compiler_0_0= 'pragma'
            {
            lv_compiler_0_0=(Token)match(input,11,FOLLOW_3); 

            					newLeafNode(lv_compiler_0_0, grammarAccess.getSmartContractAccess().getCompilerPragmaKeyword_0_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					setWithLastConsumed(current, "compiler", lv_compiler_0_0, "pragma");
            				

            }


            }

            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getSmartContractAccess().getSolidityKeyword_1());
            		
            // InternalSM2DSL.g:98:3: ( (lv_VersionCompiler_2_0= ruleVersion ) )
            // InternalSM2DSL.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            {
            // InternalSM2DSL.g:99:4: (lv_VersionCompiler_2_0= ruleVersion )
            // InternalSM2DSL.g:100:5: lv_VersionCompiler_2_0= ruleVersion
            {

            					newCompositeNode(grammarAccess.getSmartContractAccess().getVersionCompilerVersionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_5);
            lv_VersionCompiler_2_0=ruleVersion();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            					}
            					set(
            						current,
            						"VersionCompiler",
            						lv_VersionCompiler_2_0,
            						"org.xtext.SM2DSL.Version");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_6); 

            			newLeafNode(otherlv_3, grammarAccess.getSmartContractAccess().getSemicolonControl000aKeyword_3());
            		
            // InternalSM2DSL.g:121:3: ( (lv_imports_4_0= ruleImport ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==22) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalSM2DSL.g:122:4: (lv_imports_4_0= ruleImport )
            	    {
            	    // InternalSM2DSL.g:122:4: (lv_imports_4_0= ruleImport )
            	    // InternalSM2DSL.g:123:5: lv_imports_4_0= ruleImport
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getImportsImportParserRuleCall_4_0());
            	    				
            	    pushFollow(FOLLOW_6);
            	    lv_imports_4_0=ruleImport();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"imports",
            	    						lv_imports_4_0,
            	    						"org.xtext.SM2DSL.Import");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            // InternalSM2DSL.g:140:3: ( (lv_contract_5_0= 'contract' ) )
            // InternalSM2DSL.g:141:4: (lv_contract_5_0= 'contract' )
            {
            // InternalSM2DSL.g:141:4: (lv_contract_5_0= 'contract' )
            // InternalSM2DSL.g:142:5: lv_contract_5_0= 'contract'
            {
            lv_contract_5_0=(Token)match(input,14,FOLLOW_7); 

            					newLeafNode(lv_contract_5_0, grammarAccess.getSmartContractAccess().getContractContractKeyword_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					addWithLastConsumed(current, "contract", lv_contract_5_0, "contract");
            				

            }


            }

            // InternalSM2DSL.g:154:3: ( (lv_nameContract_6_0= RULE_ID ) )
            // InternalSM2DSL.g:155:4: (lv_nameContract_6_0= RULE_ID )
            {
            // InternalSM2DSL.g:155:4: (lv_nameContract_6_0= RULE_ID )
            // InternalSM2DSL.g:156:5: lv_nameContract_6_0= RULE_ID
            {
            lv_nameContract_6_0=(Token)match(input,RULE_ID,FOLLOW_8); 

            					newLeafNode(lv_nameContract_6_0, grammarAccess.getSmartContractAccess().getNameContractIDTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getSmartContractRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameContract",
            						lv_nameContract_6_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            // InternalSM2DSL.g:172:3: (otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==15) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalSM2DSL.g:173:4: otherlv_7= 'is' ( (lv_nameContractFather_8_0= RULE_ID ) )
                    {
                    otherlv_7=(Token)match(input,15,FOLLOW_7); 

                    				newLeafNode(otherlv_7, grammarAccess.getSmartContractAccess().getIsKeyword_7_0());
                    			
                    // InternalSM2DSL.g:177:4: ( (lv_nameContractFather_8_0= RULE_ID ) )
                    // InternalSM2DSL.g:178:5: (lv_nameContractFather_8_0= RULE_ID )
                    {
                    // InternalSM2DSL.g:178:5: (lv_nameContractFather_8_0= RULE_ID )
                    // InternalSM2DSL.g:179:6: lv_nameContractFather_8_0= RULE_ID
                    {
                    lv_nameContractFather_8_0=(Token)match(input,RULE_ID,FOLLOW_9); 

                    						newLeafNode(lv_nameContractFather_8_0, grammarAccess.getSmartContractAccess().getNameContractFatherIDTerminalRuleCall_7_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getSmartContractRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"nameContractFather",
                    							lv_nameContractFather_8_0,
                    							"org.eclipse.xtext.common.Terminals.ID");
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,16,FOLLOW_10); 

            			newLeafNode(otherlv_9, grammarAccess.getSmartContractAccess().getLeftCurlyBracketControl000aKeyword_8());
            		
            // InternalSM2DSL.g:200:3: ( (lv_attributes_10_0= ruleAttributes ) )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==RULE_ID||LA3_0==28||(LA3_0>=31 && LA3_0<=32)||(LA3_0>=45 && LA3_0<=52)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // InternalSM2DSL.g:201:4: (lv_attributes_10_0= ruleAttributes )
            	    {
            	    // InternalSM2DSL.g:201:4: (lv_attributes_10_0= ruleAttributes )
            	    // InternalSM2DSL.g:202:5: lv_attributes_10_0= ruleAttributes
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getAttributesAttributesParserRuleCall_9_0());
            	    				
            	    pushFollow(FOLLOW_10);
            	    lv_attributes_10_0=ruleAttributes();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"attributes",
            	    						lv_attributes_10_0,
            	    						"org.xtext.SM2DSL.Attributes");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            // InternalSM2DSL.g:219:3: ( (lv_modifier_11_0= ruleModifier ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==23) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalSM2DSL.g:220:4: (lv_modifier_11_0= ruleModifier )
            	    {
            	    // InternalSM2DSL.g:220:4: (lv_modifier_11_0= ruleModifier )
            	    // InternalSM2DSL.g:221:5: lv_modifier_11_0= ruleModifier
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getModifierModifierParserRuleCall_10_0());
            	    				
            	    pushFollow(FOLLOW_11);
            	    lv_modifier_11_0=ruleModifier();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"modifier",
            	    						lv_modifier_11_0,
            	    						"org.xtext.SM2DSL.Modifier");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // InternalSM2DSL.g:238:3: ( (lv_clauses_12_0= ruleClause ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==38) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalSM2DSL.g:239:4: (lv_clauses_12_0= ruleClause )
            	    {
            	    // InternalSM2DSL.g:239:4: (lv_clauses_12_0= ruleClause )
            	    // InternalSM2DSL.g:240:5: lv_clauses_12_0= ruleClause
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getClausesClauseParserRuleCall_11_0());
            	    				
            	    pushFollow(FOLLOW_12);
            	    lv_clauses_12_0=ruleClause();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"clauses",
            	    						lv_clauses_12_0,
            	    						"org.xtext.SM2DSL.Clause");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // InternalSM2DSL.g:257:3: ( (lv_comments_13_0= ruleComment ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==41||LA6_0==43) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalSM2DSL.g:258:4: (lv_comments_13_0= ruleComment )
            	    {
            	    // InternalSM2DSL.g:258:4: (lv_comments_13_0= ruleComment )
            	    // InternalSM2DSL.g:259:5: lv_comments_13_0= ruleComment
            	    {

            	    					newCompositeNode(grammarAccess.getSmartContractAccess().getCommentsCommentParserRuleCall_12_0());
            	    				
            	    pushFollow(FOLLOW_13);
            	    lv_comments_13_0=ruleComment();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getSmartContractRule());
            	    					}
            	    					add(
            	    						current,
            	    						"comments",
            	    						lv_comments_13_0,
            	    						"org.xtext.SM2DSL.Comment");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            otherlv_14=(Token)match(input,17,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getSmartContractAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSmartContract"


    // $ANTLR start "entryRuleVersion"
    // InternalSM2DSL.g:284:1: entryRuleVersion returns [EObject current=null] : iv_ruleVersion= ruleVersion EOF ;
    public final EObject entryRuleVersion() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVersion = null;


        try {
            // InternalSM2DSL.g:284:48: (iv_ruleVersion= ruleVersion EOF )
            // InternalSM2DSL.g:285:2: iv_ruleVersion= ruleVersion EOF
            {
             newCompositeNode(grammarAccess.getVersionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVersion=ruleVersion();

            state._fsp--;

             current =iv_ruleVersion; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVersion"


    // $ANTLR start "ruleVersion"
    // InternalSM2DSL.g:291:1: ruleVersion returns [EObject current=null] : ( ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) ) ( (lv_numberVersion_1_0= RULE_INT ) ) otherlv_2= '.' ( (lv_numberVersion2_3_0= RULE_INT ) ) otherlv_4= '.' ( (lv_numberVersion3_5_0= RULE_INT ) ) ( (otherlv_6= RULE_ID ) )? ) ;
    public final EObject ruleVersion() throws RecognitionException {
        EObject current = null;

        Token lv_symbol_0_1=null;
        Token lv_symbol_0_2=null;
        Token lv_symbol_0_3=null;
        Token lv_numberVersion_1_0=null;
        Token otherlv_2=null;
        Token lv_numberVersion2_3_0=null;
        Token otherlv_4=null;
        Token lv_numberVersion3_5_0=null;
        Token otherlv_6=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:297:2: ( ( ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) ) ( (lv_numberVersion_1_0= RULE_INT ) ) otherlv_2= '.' ( (lv_numberVersion2_3_0= RULE_INT ) ) otherlv_4= '.' ( (lv_numberVersion3_5_0= RULE_INT ) ) ( (otherlv_6= RULE_ID ) )? ) )
            // InternalSM2DSL.g:298:2: ( ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) ) ( (lv_numberVersion_1_0= RULE_INT ) ) otherlv_2= '.' ( (lv_numberVersion2_3_0= RULE_INT ) ) otherlv_4= '.' ( (lv_numberVersion3_5_0= RULE_INT ) ) ( (otherlv_6= RULE_ID ) )? )
            {
            // InternalSM2DSL.g:298:2: ( ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) ) ( (lv_numberVersion_1_0= RULE_INT ) ) otherlv_2= '.' ( (lv_numberVersion2_3_0= RULE_INT ) ) otherlv_4= '.' ( (lv_numberVersion3_5_0= RULE_INT ) ) ( (otherlv_6= RULE_ID ) )? )
            // InternalSM2DSL.g:299:3: ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) ) ( (lv_numberVersion_1_0= RULE_INT ) ) otherlv_2= '.' ( (lv_numberVersion2_3_0= RULE_INT ) ) otherlv_4= '.' ( (lv_numberVersion3_5_0= RULE_INT ) ) ( (otherlv_6= RULE_ID ) )?
            {
            // InternalSM2DSL.g:299:3: ( ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) ) )
            // InternalSM2DSL.g:300:4: ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) )
            {
            // InternalSM2DSL.g:300:4: ( (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' ) )
            // InternalSM2DSL.g:301:5: (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' )
            {
            // InternalSM2DSL.g:301:5: (lv_symbol_0_1= '^' | lv_symbol_0_2= '>' | lv_symbol_0_3= '>=' )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 18:
                {
                alt7=1;
                }
                break;
            case 19:
                {
                alt7=2;
                }
                break;
            case 20:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalSM2DSL.g:302:6: lv_symbol_0_1= '^'
                    {
                    lv_symbol_0_1=(Token)match(input,18,FOLLOW_14); 

                    						newLeafNode(lv_symbol_0_1, grammarAccess.getVersionAccess().getSymbolCircumflexAccentKeyword_0_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_0_1, null);
                    					

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:313:6: lv_symbol_0_2= '>'
                    {
                    lv_symbol_0_2=(Token)match(input,19,FOLLOW_14); 

                    						newLeafNode(lv_symbol_0_2, grammarAccess.getVersionAccess().getSymbolGreaterThanSignKeyword_0_0_1());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_0_2, null);
                    					

                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:324:6: lv_symbol_0_3= '>='
                    {
                    lv_symbol_0_3=(Token)match(input,20,FOLLOW_14); 

                    						newLeafNode(lv_symbol_0_3, grammarAccess.getVersionAccess().getSymbolGreaterThanSignEqualsSignKeyword_0_0_2());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getVersionRule());
                    						}
                    						setWithLastConsumed(current, "symbol", lv_symbol_0_3, null);
                    					

                    }
                    break;

            }


            }


            }

            // InternalSM2DSL.g:337:3: ( (lv_numberVersion_1_0= RULE_INT ) )
            // InternalSM2DSL.g:338:4: (lv_numberVersion_1_0= RULE_INT )
            {
            // InternalSM2DSL.g:338:4: (lv_numberVersion_1_0= RULE_INT )
            // InternalSM2DSL.g:339:5: lv_numberVersion_1_0= RULE_INT
            {
            lv_numberVersion_1_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            					newLeafNode(lv_numberVersion_1_0, grammarAccess.getVersionAccess().getNumberVersionINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion",
            						lv_numberVersion_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_2=(Token)match(input,21,FOLLOW_14); 

            			newLeafNode(otherlv_2, grammarAccess.getVersionAccess().getFullStopKeyword_2());
            		
            // InternalSM2DSL.g:359:3: ( (lv_numberVersion2_3_0= RULE_INT ) )
            // InternalSM2DSL.g:360:4: (lv_numberVersion2_3_0= RULE_INT )
            {
            // InternalSM2DSL.g:360:4: (lv_numberVersion2_3_0= RULE_INT )
            // InternalSM2DSL.g:361:5: lv_numberVersion2_3_0= RULE_INT
            {
            lv_numberVersion2_3_0=(Token)match(input,RULE_INT,FOLLOW_15); 

            					newLeafNode(lv_numberVersion2_3_0, grammarAccess.getVersionAccess().getNumberVersion2INTTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion2",
            						lv_numberVersion2_3_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            otherlv_4=(Token)match(input,21,FOLLOW_14); 

            			newLeafNode(otherlv_4, grammarAccess.getVersionAccess().getFullStopKeyword_4());
            		
            // InternalSM2DSL.g:381:3: ( (lv_numberVersion3_5_0= RULE_INT ) )
            // InternalSM2DSL.g:382:4: (lv_numberVersion3_5_0= RULE_INT )
            {
            // InternalSM2DSL.g:382:4: (lv_numberVersion3_5_0= RULE_INT )
            // InternalSM2DSL.g:383:5: lv_numberVersion3_5_0= RULE_INT
            {
            lv_numberVersion3_5_0=(Token)match(input,RULE_INT,FOLLOW_16); 

            					newLeafNode(lv_numberVersion3_5_0, grammarAccess.getVersionAccess().getNumberVersion3INTTerminalRuleCall_5_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getVersionRule());
            					}
            					setWithLastConsumed(
            						current,
            						"numberVersion3",
            						lv_numberVersion3_5_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2DSL.g:399:3: ( (otherlv_6= RULE_ID ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==RULE_ID) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalSM2DSL.g:400:4: (otherlv_6= RULE_ID )
                    {
                    // InternalSM2DSL.g:400:4: (otherlv_6= RULE_ID )
                    // InternalSM2DSL.g:401:5: otherlv_6= RULE_ID
                    {

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVersionRule());
                    					}
                    				
                    otherlv_6=(Token)match(input,RULE_ID,FOLLOW_2); 

                    					newLeafNode(otherlv_6, grammarAccess.getVersionAccess().getOptionalversionVersionCrossReference_6_0());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVersion"


    // $ANTLR start "entryRuleImport"
    // InternalSM2DSL.g:416:1: entryRuleImport returns [EObject current=null] : iv_ruleImport= ruleImport EOF ;
    public final EObject entryRuleImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleImport = null;


        try {
            // InternalSM2DSL.g:416:47: (iv_ruleImport= ruleImport EOF )
            // InternalSM2DSL.g:417:2: iv_ruleImport= ruleImport EOF
            {
             newCompositeNode(grammarAccess.getImportRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleImport=ruleImport();

            state._fsp--;

             current =iv_ruleImport; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleImport"


    // $ANTLR start "ruleImport"
    // InternalSM2DSL.g:423:1: ruleImport returns [EObject current=null] : (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_STRING ) ) otherlv_2= ';\\n' ) ;
    public final EObject ruleImport() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameLibrary_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:429:2: ( (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_STRING ) ) otherlv_2= ';\\n' ) )
            // InternalSM2DSL.g:430:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_STRING ) ) otherlv_2= ';\\n' )
            {
            // InternalSM2DSL.g:430:2: (otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_STRING ) ) otherlv_2= ';\\n' )
            // InternalSM2DSL.g:431:3: otherlv_0= 'import' ( (lv_nameLibrary_1_0= RULE_STRING ) ) otherlv_2= ';\\n'
            {
            otherlv_0=(Token)match(input,22,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getImportAccess().getImportKeyword_0());
            		
            // InternalSM2DSL.g:435:3: ( (lv_nameLibrary_1_0= RULE_STRING ) )
            // InternalSM2DSL.g:436:4: (lv_nameLibrary_1_0= RULE_STRING )
            {
            // InternalSM2DSL.g:436:4: (lv_nameLibrary_1_0= RULE_STRING )
            // InternalSM2DSL.g:437:5: lv_nameLibrary_1_0= RULE_STRING
            {
            lv_nameLibrary_1_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_nameLibrary_1_0, grammarAccess.getImportAccess().getNameLibrarySTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getImportRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameLibrary",
            						lv_nameLibrary_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getImportAccess().getSemicolonControl000aKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleImport"


    // $ANTLR start "entryRuleAttributes"
    // InternalSM2DSL.g:461:1: entryRuleAttributes returns [EObject current=null] : iv_ruleAttributes= ruleAttributes EOF ;
    public final EObject entryRuleAttributes() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttributes = null;


        try {
            // InternalSM2DSL.g:461:51: (iv_ruleAttributes= ruleAttributes EOF )
            // InternalSM2DSL.g:462:2: iv_ruleAttributes= ruleAttributes EOF
            {
             newCompositeNode(grammarAccess.getAttributesRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAttributes=ruleAttributes();

            state._fsp--;

             current =iv_ruleAttributes; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAttributes"


    // $ANTLR start "ruleAttributes"
    // InternalSM2DSL.g:468:1: ruleAttributes returns [EObject current=null] : (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) ;
    public final EObject ruleAttributes() throws RecognitionException {
        EObject current = null;

        EObject this_Property_0 = null;

        EObject this_DataType_1 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:474:2: ( (this_Property_0= ruleProperty | this_DataType_1= ruleDataType ) )
            // InternalSM2DSL.g:475:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            {
            // InternalSM2DSL.g:475:2: (this_Property_0= ruleProperty | this_DataType_1= ruleDataType )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( ((LA9_0>=45 && LA9_0<=52)) ) {
                alt9=1;
            }
            else if ( (LA9_0==RULE_ID||LA9_0==28||(LA9_0>=31 && LA9_0<=32)) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalSM2DSL.g:476:3: this_Property_0= ruleProperty
                    {

                    			newCompositeNode(grammarAccess.getAttributesAccess().getPropertyParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Property_0=ruleProperty();

                    state._fsp--;


                    			current = this_Property_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:485:3: this_DataType_1= ruleDataType
                    {

                    			newCompositeNode(grammarAccess.getAttributesAccess().getDataTypeParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_DataType_1=ruleDataType();

                    state._fsp--;


                    			current = this_DataType_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAttributes"


    // $ANTLR start "entryRuleModifier"
    // InternalSM2DSL.g:497:1: entryRuleModifier returns [EObject current=null] : iv_ruleModifier= ruleModifier EOF ;
    public final EObject entryRuleModifier() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModifier = null;


        try {
            // InternalSM2DSL.g:497:49: (iv_ruleModifier= ruleModifier EOF )
            // InternalSM2DSL.g:498:2: iv_ruleModifier= ruleModifier EOF
            {
             newCompositeNode(grammarAccess.getModifierRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModifier=ruleModifier();

            state._fsp--;

             current =iv_ruleModifier; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModifier"


    // $ANTLR start "ruleModifier"
    // InternalSM2DSL.g:504:1: ruleModifier returns [EObject current=null] : (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) )* otherlv_4= ')' otherlv_5= '{\\n' ( (lv_expr_6_0= RULE_STRING ) ) otherlv_7= ';\\n' otherlv_8= '_;' otherlv_9= '}\\n' ) ;
    public final EObject ruleModifier() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameModifier_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token lv_expr_6_0=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:510:2: ( (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) )* otherlv_4= ')' otherlv_5= '{\\n' ( (lv_expr_6_0= RULE_STRING ) ) otherlv_7= ';\\n' otherlv_8= '_;' otherlv_9= '}\\n' ) )
            // InternalSM2DSL.g:511:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) )* otherlv_4= ')' otherlv_5= '{\\n' ( (lv_expr_6_0= RULE_STRING ) ) otherlv_7= ';\\n' otherlv_8= '_;' otherlv_9= '}\\n' )
            {
            // InternalSM2DSL.g:511:2: (otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) )* otherlv_4= ')' otherlv_5= '{\\n' ( (lv_expr_6_0= RULE_STRING ) ) otherlv_7= ';\\n' otherlv_8= '_;' otherlv_9= '}\\n' )
            // InternalSM2DSL.g:512:3: otherlv_0= 'modifier' ( (lv_nameModifier_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) )* otherlv_4= ')' otherlv_5= '{\\n' ( (lv_expr_6_0= RULE_STRING ) ) otherlv_7= ';\\n' otherlv_8= '_;' otherlv_9= '}\\n'
            {
            otherlv_0=(Token)match(input,23,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getModifierAccess().getModifierKeyword_0());
            		
            // InternalSM2DSL.g:516:3: ( (lv_nameModifier_1_0= RULE_ID ) )
            // InternalSM2DSL.g:517:4: (lv_nameModifier_1_0= RULE_ID )
            {
            // InternalSM2DSL.g:517:4: (lv_nameModifier_1_0= RULE_ID )
            // InternalSM2DSL.g:518:5: lv_nameModifier_1_0= RULE_ID
            {
            lv_nameModifier_1_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            					newLeafNode(lv_nameModifier_1_0, grammarAccess.getModifierAccess().getNameModifierIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameModifier",
            						lv_nameModifier_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,24,FOLLOW_19); 

            			newLeafNode(otherlv_2, grammarAccess.getModifierAccess().getLeftParenthesisKeyword_2());
            		
            // InternalSM2DSL.g:538:3: ( (otherlv_3= RULE_ID ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==RULE_ID) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalSM2DSL.g:539:4: (otherlv_3= RULE_ID )
            	    {
            	    // InternalSM2DSL.g:539:4: (otherlv_3= RULE_ID )
            	    // InternalSM2DSL.g:540:5: otherlv_3= RULE_ID
            	    {

            	    					if (current==null) {
            	    						current = createModelElement(grammarAccess.getModifierRule());
            	    					}
            	    				
            	    otherlv_3=(Token)match(input,RULE_ID,FOLLOW_19); 

            	    					newLeafNode(otherlv_3, grammarAccess.getModifierAccess().getInputParamsInputParamCrossReference_3_0());
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            otherlv_4=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_4, grammarAccess.getModifierAccess().getRightParenthesisKeyword_4());
            		
            otherlv_5=(Token)match(input,16,FOLLOW_17); 

            			newLeafNode(otherlv_5, grammarAccess.getModifierAccess().getLeftCurlyBracketControl000aKeyword_5());
            		
            // InternalSM2DSL.g:559:3: ( (lv_expr_6_0= RULE_STRING ) )
            // InternalSM2DSL.g:560:4: (lv_expr_6_0= RULE_STRING )
            {
            // InternalSM2DSL.g:560:4: (lv_expr_6_0= RULE_STRING )
            // InternalSM2DSL.g:561:5: lv_expr_6_0= RULE_STRING
            {
            lv_expr_6_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

            					newLeafNode(lv_expr_6_0, grammarAccess.getModifierAccess().getExprSTRINGTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getModifierRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_6_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_7=(Token)match(input,13,FOLLOW_20); 

            			newLeafNode(otherlv_7, grammarAccess.getModifierAccess().getSemicolonControl000aKeyword_7());
            		
            otherlv_8=(Token)match(input,26,FOLLOW_21); 

            			newLeafNode(otherlv_8, grammarAccess.getModifierAccess().get_Keyword_8());
            		
            otherlv_9=(Token)match(input,27,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getModifierAccess().getRightCurlyBracketControl000aKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModifier"


    // $ANTLR start "entryRuleDataType"
    // InternalSM2DSL.g:593:1: entryRuleDataType returns [EObject current=null] : iv_ruleDataType= ruleDataType EOF ;
    public final EObject entryRuleDataType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDataType = null;


        try {
            // InternalSM2DSL.g:593:49: (iv_ruleDataType= ruleDataType EOF )
            // InternalSM2DSL.g:594:2: iv_ruleDataType= ruleDataType EOF
            {
             newCompositeNode(grammarAccess.getDataTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDataType=ruleDataType();

            state._fsp--;

             current =iv_ruleDataType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDataType"


    // $ANTLR start "ruleDataType"
    // InternalSM2DSL.g:600:1: ruleDataType returns [EObject current=null] : (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) ;
    public final EObject ruleDataType() throws RecognitionException {
        EObject current = null;

        Token this_ID_2=null;
        EObject this_CompositeType_0 = null;

        EObject this_Enum_1 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:606:2: ( (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID ) )
            // InternalSM2DSL.g:607:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            {
            // InternalSM2DSL.g:607:2: (this_CompositeType_0= ruleCompositeType | this_Enum_1= ruleEnum | this_ID_2= RULE_ID )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 28:
            case 31:
                {
                alt11=1;
                }
                break;
            case 32:
                {
                alt11=2;
                }
                break;
            case RULE_ID:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalSM2DSL.g:608:3: this_CompositeType_0= ruleCompositeType
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getCompositeTypeParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_CompositeType_0=ruleCompositeType();

                    state._fsp--;


                    			current = this_CompositeType_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:617:3: this_Enum_1= ruleEnum
                    {

                    			newCompositeNode(grammarAccess.getDataTypeAccess().getEnumParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Enum_1=ruleEnum();

                    state._fsp--;


                    			current = this_Enum_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:626:3: this_ID_2= RULE_ID
                    {
                    this_ID_2=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			newLeafNode(this_ID_2, grammarAccess.getDataTypeAccess().getIDTerminalRuleCall_2());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDataType"


    // $ANTLR start "entryRuleCompositeType"
    // InternalSM2DSL.g:634:1: entryRuleCompositeType returns [EObject current=null] : iv_ruleCompositeType= ruleCompositeType EOF ;
    public final EObject entryRuleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCompositeType = null;


        try {
            // InternalSM2DSL.g:634:54: (iv_ruleCompositeType= ruleCompositeType EOF )
            // InternalSM2DSL.g:635:2: iv_ruleCompositeType= ruleCompositeType EOF
            {
             newCompositeNode(grammarAccess.getCompositeTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCompositeType=ruleCompositeType();

            state._fsp--;

             current =iv_ruleCompositeType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCompositeType"


    // $ANTLR start "ruleCompositeType"
    // InternalSM2DSL.g:641:1: ruleCompositeType returns [EObject current=null] : (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) ;
    public final EObject ruleCompositeType() throws RecognitionException {
        EObject current = null;

        EObject this_Mapping_0 = null;

        EObject this_Struct_1 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:647:2: ( (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct ) )
            // InternalSM2DSL.g:648:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            {
            // InternalSM2DSL.g:648:2: (this_Mapping_0= ruleMapping | this_Struct_1= ruleStruct )
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==28) ) {
                alt12=1;
            }
            else if ( (LA12_0==31) ) {
                alt12=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 12, 0, input);

                throw nvae;
            }
            switch (alt12) {
                case 1 :
                    // InternalSM2DSL.g:649:3: this_Mapping_0= ruleMapping
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getMappingParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_Mapping_0=ruleMapping();

                    state._fsp--;


                    			current = this_Mapping_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:658:3: this_Struct_1= ruleStruct
                    {

                    			newCompositeNode(grammarAccess.getCompositeTypeAccess().getStructParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_Struct_1=ruleStruct();

                    state._fsp--;


                    			current = this_Struct_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCompositeType"


    // $ANTLR start "entryRuleMapping"
    // InternalSM2DSL.g:670:1: entryRuleMapping returns [EObject current=null] : iv_ruleMapping= ruleMapping EOF ;
    public final EObject entryRuleMapping() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMapping = null;


        try {
            // InternalSM2DSL.g:670:48: (iv_ruleMapping= ruleMapping EOF )
            // InternalSM2DSL.g:671:2: iv_ruleMapping= ruleMapping EOF
            {
             newCompositeNode(grammarAccess.getMappingRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMapping=ruleMapping();

            state._fsp--;

             current =iv_ruleMapping; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMapping"


    // $ANTLR start "ruleMapping"
    // InternalSM2DSL.g:677:1: ruleMapping returns [EObject current=null] : (otherlv_0= 'mapping(' ( (lv_type_1_0= ruleSingularType ) ) otherlv_2= '=>' ( (lv_expr_3_0= RULE_STRING ) ) otherlv_4= ')' ( (lv_visibility_5_0= ruleVisibility ) )? ( (lv_nameMapping_6_0= RULE_ID ) ) otherlv_7= ';' ) ;
    public final EObject ruleMapping() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token lv_expr_3_0=null;
        Token otherlv_4=null;
        Token lv_nameMapping_6_0=null;
        Token otherlv_7=null;
        Enumerator lv_type_1_0 = null;

        Enumerator lv_visibility_5_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:683:2: ( (otherlv_0= 'mapping(' ( (lv_type_1_0= ruleSingularType ) ) otherlv_2= '=>' ( (lv_expr_3_0= RULE_STRING ) ) otherlv_4= ')' ( (lv_visibility_5_0= ruleVisibility ) )? ( (lv_nameMapping_6_0= RULE_ID ) ) otherlv_7= ';' ) )
            // InternalSM2DSL.g:684:2: (otherlv_0= 'mapping(' ( (lv_type_1_0= ruleSingularType ) ) otherlv_2= '=>' ( (lv_expr_3_0= RULE_STRING ) ) otherlv_4= ')' ( (lv_visibility_5_0= ruleVisibility ) )? ( (lv_nameMapping_6_0= RULE_ID ) ) otherlv_7= ';' )
            {
            // InternalSM2DSL.g:684:2: (otherlv_0= 'mapping(' ( (lv_type_1_0= ruleSingularType ) ) otherlv_2= '=>' ( (lv_expr_3_0= RULE_STRING ) ) otherlv_4= ')' ( (lv_visibility_5_0= ruleVisibility ) )? ( (lv_nameMapping_6_0= RULE_ID ) ) otherlv_7= ';' )
            // InternalSM2DSL.g:685:3: otherlv_0= 'mapping(' ( (lv_type_1_0= ruleSingularType ) ) otherlv_2= '=>' ( (lv_expr_3_0= RULE_STRING ) ) otherlv_4= ')' ( (lv_visibility_5_0= ruleVisibility ) )? ( (lv_nameMapping_6_0= RULE_ID ) ) otherlv_7= ';'
            {
            otherlv_0=(Token)match(input,28,FOLLOW_22); 

            			newLeafNode(otherlv_0, grammarAccess.getMappingAccess().getMappingKeyword_0());
            		
            // InternalSM2DSL.g:689:3: ( (lv_type_1_0= ruleSingularType ) )
            // InternalSM2DSL.g:690:4: (lv_type_1_0= ruleSingularType )
            {
            // InternalSM2DSL.g:690:4: (lv_type_1_0= ruleSingularType )
            // InternalSM2DSL.g:691:5: lv_type_1_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getMappingAccess().getTypeSingularTypeEnumRuleCall_1_0());
            				
            pushFollow(FOLLOW_23);
            lv_type_1_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMappingRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_1_0,
            						"org.xtext.SM2DSL.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,29,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getMappingAccess().getEqualsSignGreaterThanSignKeyword_2());
            		
            // InternalSM2DSL.g:712:3: ( (lv_expr_3_0= RULE_STRING ) )
            // InternalSM2DSL.g:713:4: (lv_expr_3_0= RULE_STRING )
            {
            // InternalSM2DSL.g:713:4: (lv_expr_3_0= RULE_STRING )
            // InternalSM2DSL.g:714:5: lv_expr_3_0= RULE_STRING
            {
            lv_expr_3_0=(Token)match(input,RULE_STRING,FOLLOW_24); 

            					newLeafNode(lv_expr_3_0, grammarAccess.getMappingAccess().getExprSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_4=(Token)match(input,25,FOLLOW_25); 

            			newLeafNode(otherlv_4, grammarAccess.getMappingAccess().getRightParenthesisKeyword_4());
            		
            // InternalSM2DSL.g:734:3: ( (lv_visibility_5_0= ruleVisibility ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( ((LA13_0>=53 && LA13_0<=55)) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalSM2DSL.g:735:4: (lv_visibility_5_0= ruleVisibility )
                    {
                    // InternalSM2DSL.g:735:4: (lv_visibility_5_0= ruleVisibility )
                    // InternalSM2DSL.g:736:5: lv_visibility_5_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getMappingAccess().getVisibilityVisibilityEnumRuleCall_5_0());
                    				
                    pushFollow(FOLLOW_7);
                    lv_visibility_5_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getMappingRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_5_0,
                    						"org.xtext.SM2DSL.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2DSL.g:753:3: ( (lv_nameMapping_6_0= RULE_ID ) )
            // InternalSM2DSL.g:754:4: (lv_nameMapping_6_0= RULE_ID )
            {
            // InternalSM2DSL.g:754:4: (lv_nameMapping_6_0= RULE_ID )
            // InternalSM2DSL.g:755:5: lv_nameMapping_6_0= RULE_ID
            {
            lv_nameMapping_6_0=(Token)match(input,RULE_ID,FOLLOW_26); 

            					newLeafNode(lv_nameMapping_6_0, grammarAccess.getMappingAccess().getNameMappingIDTerminalRuleCall_6_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getMappingRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameMapping",
            						lv_nameMapping_6_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_7=(Token)match(input,30,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getMappingAccess().getSemicolonKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMapping"


    // $ANTLR start "entryRuleStruct"
    // InternalSM2DSL.g:779:1: entryRuleStruct returns [EObject current=null] : iv_ruleStruct= ruleStruct EOF ;
    public final EObject entryRuleStruct() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStruct = null;


        try {
            // InternalSM2DSL.g:779:47: (iv_ruleStruct= ruleStruct EOF )
            // InternalSM2DSL.g:780:2: iv_ruleStruct= ruleStruct EOF
            {
             newCompositeNode(grammarAccess.getStructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStruct=ruleStruct();

            state._fsp--;

             current =iv_ruleStruct; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStruct"


    // $ANTLR start "ruleStruct"
    // InternalSM2DSL.g:786:1: ruleStruct returns [EObject current=null] : (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) otherlv_2= '{\\n' ( (lv_properties_3_0= ruleProperty ) ) otherlv_4= '}\\n' ) ;
    public final EObject ruleStruct() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameStruct_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_properties_3_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:792:2: ( (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) otherlv_2= '{\\n' ( (lv_properties_3_0= ruleProperty ) ) otherlv_4= '}\\n' ) )
            // InternalSM2DSL.g:793:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) otherlv_2= '{\\n' ( (lv_properties_3_0= ruleProperty ) ) otherlv_4= '}\\n' )
            {
            // InternalSM2DSL.g:793:2: (otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) otherlv_2= '{\\n' ( (lv_properties_3_0= ruleProperty ) ) otherlv_4= '}\\n' )
            // InternalSM2DSL.g:794:3: otherlv_0= 'struct' ( (lv_nameStruct_1_0= RULE_ID ) ) otherlv_2= '{\\n' ( (lv_properties_3_0= ruleProperty ) ) otherlv_4= '}\\n'
            {
            otherlv_0=(Token)match(input,31,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getStructAccess().getStructKeyword_0());
            		
            // InternalSM2DSL.g:798:3: ( (lv_nameStruct_1_0= RULE_ID ) )
            // InternalSM2DSL.g:799:4: (lv_nameStruct_1_0= RULE_ID )
            {
            // InternalSM2DSL.g:799:4: (lv_nameStruct_1_0= RULE_ID )
            // InternalSM2DSL.g:800:5: lv_nameStruct_1_0= RULE_ID
            {
            lv_nameStruct_1_0=(Token)match(input,RULE_ID,FOLLOW_9); 

            					newLeafNode(lv_nameStruct_1_0, grammarAccess.getStructAccess().getNameStructIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getStructRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameStruct",
            						lv_nameStruct_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,16,FOLLOW_22); 

            			newLeafNode(otherlv_2, grammarAccess.getStructAccess().getLeftCurlyBracketControl000aKeyword_2());
            		
            // InternalSM2DSL.g:820:3: ( (lv_properties_3_0= ruleProperty ) )
            // InternalSM2DSL.g:821:4: (lv_properties_3_0= ruleProperty )
            {
            // InternalSM2DSL.g:821:4: (lv_properties_3_0= ruleProperty )
            // InternalSM2DSL.g:822:5: lv_properties_3_0= ruleProperty
            {

            					newCompositeNode(grammarAccess.getStructAccess().getPropertiesPropertyParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_21);
            lv_properties_3_0=ruleProperty();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStructRule());
            					}
            					add(
            						current,
            						"properties",
            						lv_properties_3_0,
            						"org.xtext.SM2DSL.Property");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,27,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getStructAccess().getRightCurlyBracketControl000aKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStruct"


    // $ANTLR start "entryRuleEnum"
    // InternalSM2DSL.g:847:1: entryRuleEnum returns [EObject current=null] : iv_ruleEnum= ruleEnum EOF ;
    public final EObject entryRuleEnum() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnum = null;


        try {
            // InternalSM2DSL.g:847:45: (iv_ruleEnum= ruleEnum EOF )
            // InternalSM2DSL.g:848:2: iv_ruleEnum= ruleEnum EOF
            {
             newCompositeNode(grammarAccess.getEnumRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnum=ruleEnum();

            state._fsp--;

             current =iv_ruleEnum; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnum"


    // $ANTLR start "ruleEnum"
    // InternalSM2DSL.g:854:1: ruleEnum returns [EObject current=null] : (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_expr_3_0= RULE_STRING ) ) (otherlv_4= ',' )? otherlv_5= '}' otherlv_6= ';\\n' ) ;
    public final EObject ruleEnum() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameEnum_1_0=null;
        Token otherlv_2=null;
        Token lv_expr_3_0=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:860:2: ( (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_expr_3_0= RULE_STRING ) ) (otherlv_4= ',' )? otherlv_5= '}' otherlv_6= ';\\n' ) )
            // InternalSM2DSL.g:861:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_expr_3_0= RULE_STRING ) ) (otherlv_4= ',' )? otherlv_5= '}' otherlv_6= ';\\n' )
            {
            // InternalSM2DSL.g:861:2: (otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_expr_3_0= RULE_STRING ) ) (otherlv_4= ',' )? otherlv_5= '}' otherlv_6= ';\\n' )
            // InternalSM2DSL.g:862:3: otherlv_0= 'enum' ( (lv_nameEnum_1_0= RULE_ID ) ) otherlv_2= '{' ( (lv_expr_3_0= RULE_STRING ) ) (otherlv_4= ',' )? otherlv_5= '}' otherlv_6= ';\\n'
            {
            otherlv_0=(Token)match(input,32,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getEnumAccess().getEnumKeyword_0());
            		
            // InternalSM2DSL.g:866:3: ( (lv_nameEnum_1_0= RULE_ID ) )
            // InternalSM2DSL.g:867:4: (lv_nameEnum_1_0= RULE_ID )
            {
            // InternalSM2DSL.g:867:4: (lv_nameEnum_1_0= RULE_ID )
            // InternalSM2DSL.g:868:5: lv_nameEnum_1_0= RULE_ID
            {
            lv_nameEnum_1_0=(Token)match(input,RULE_ID,FOLLOW_27); 

            					newLeafNode(lv_nameEnum_1_0, grammarAccess.getEnumAccess().getNameEnumIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameEnum",
            						lv_nameEnum_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,33,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getEnumAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalSM2DSL.g:888:3: ( (lv_expr_3_0= RULE_STRING ) )
            // InternalSM2DSL.g:889:4: (lv_expr_3_0= RULE_STRING )
            {
            // InternalSM2DSL.g:889:4: (lv_expr_3_0= RULE_STRING )
            // InternalSM2DSL.g:890:5: lv_expr_3_0= RULE_STRING
            {
            lv_expr_3_0=(Token)match(input,RULE_STRING,FOLLOW_28); 

            					newLeafNode(lv_expr_3_0, grammarAccess.getEnumAccess().getExprSTRINGTerminalRuleCall_3_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEnumRule());
            					}
            					addWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_3_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalSM2DSL.g:906:3: (otherlv_4= ',' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==34) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalSM2DSL.g:907:4: otherlv_4= ','
                    {
                    otherlv_4=(Token)match(input,34,FOLLOW_29); 

                    				newLeafNode(otherlv_4, grammarAccess.getEnumAccess().getCommaKeyword_4());
                    			

                    }
                    break;

            }

            otherlv_5=(Token)match(input,17,FOLLOW_5); 

            			newLeafNode(otherlv_5, grammarAccess.getEnumAccess().getRightCurlyBracketKeyword_5());
            		
            otherlv_6=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getEnumAccess().getSemicolonControl000aKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnum"


    // $ANTLR start "entryRuleProperty"
    // InternalSM2DSL.g:924:1: entryRuleProperty returns [EObject current=null] : iv_ruleProperty= ruleProperty EOF ;
    public final EObject entryRuleProperty() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleProperty = null;


        try {
            // InternalSM2DSL.g:924:49: (iv_ruleProperty= ruleProperty EOF )
            // InternalSM2DSL.g:925:2: iv_ruleProperty= ruleProperty EOF
            {
             newCompositeNode(grammarAccess.getPropertyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleProperty=ruleProperty();

            state._fsp--;

             current =iv_ruleProperty; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleProperty"


    // $ANTLR start "ruleProperty"
    // InternalSM2DSL.g:931:1: ruleProperty returns [EObject current=null] : ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? otherlv_6= ';\\n' ) ;
    public final EObject ruleProperty() throws RecognitionException {
        EObject current = null;

        Token lv_nameProperty_2_0=null;
        Token otherlv_3=null;
        Token lv_inicialization_4_0=null;
        Token this_INT_5=null;
        Token otherlv_6=null;
        Enumerator lv_type_0_0 = null;

        Enumerator lv_visibility_1_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:937:2: ( ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? otherlv_6= ';\\n' ) )
            // InternalSM2DSL.g:938:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? otherlv_6= ';\\n' )
            {
            // InternalSM2DSL.g:938:2: ( ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? otherlv_6= ';\\n' )
            // InternalSM2DSL.g:939:3: ( (lv_type_0_0= ruleSingularType ) ) ( (lv_visibility_1_0= ruleVisibility ) )? ( (lv_nameProperty_2_0= RULE_ID ) ) otherlv_3= '=' ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )? otherlv_6= ';\\n'
            {
            // InternalSM2DSL.g:939:3: ( (lv_type_0_0= ruleSingularType ) )
            // InternalSM2DSL.g:940:4: (lv_type_0_0= ruleSingularType )
            {
            // InternalSM2DSL.g:940:4: (lv_type_0_0= ruleSingularType )
            // InternalSM2DSL.g:941:5: lv_type_0_0= ruleSingularType
            {

            					newCompositeNode(grammarAccess.getPropertyAccess().getTypeSingularTypeEnumRuleCall_0_0());
            				
            pushFollow(FOLLOW_25);
            lv_type_0_0=ruleSingularType();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPropertyRule());
            					}
            					set(
            						current,
            						"type",
            						lv_type_0_0,
            						"org.xtext.SM2DSL.SingularType");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2DSL.g:958:3: ( (lv_visibility_1_0= ruleVisibility ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( ((LA15_0>=53 && LA15_0<=55)) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalSM2DSL.g:959:4: (lv_visibility_1_0= ruleVisibility )
                    {
                    // InternalSM2DSL.g:959:4: (lv_visibility_1_0= ruleVisibility )
                    // InternalSM2DSL.g:960:5: lv_visibility_1_0= ruleVisibility
                    {

                    					newCompositeNode(grammarAccess.getPropertyAccess().getVisibilityVisibilityEnumRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_7);
                    lv_visibility_1_0=ruleVisibility();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getPropertyRule());
                    					}
                    					set(
                    						current,
                    						"visibility",
                    						lv_visibility_1_0,
                    						"org.xtext.SM2DSL.Visibility");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2DSL.g:977:3: ( (lv_nameProperty_2_0= RULE_ID ) )
            // InternalSM2DSL.g:978:4: (lv_nameProperty_2_0= RULE_ID )
            {
            // InternalSM2DSL.g:978:4: (lv_nameProperty_2_0= RULE_ID )
            // InternalSM2DSL.g:979:5: lv_nameProperty_2_0= RULE_ID
            {
            lv_nameProperty_2_0=(Token)match(input,RULE_ID,FOLLOW_30); 

            					newLeafNode(lv_nameProperty_2_0, grammarAccess.getPropertyAccess().getNamePropertyIDTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPropertyRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameProperty",
            						lv_nameProperty_2_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_3=(Token)match(input,35,FOLLOW_31); 

            			newLeafNode(otherlv_3, grammarAccess.getPropertyAccess().getEqualsSignKeyword_3());
            		
            // InternalSM2DSL.g:999:3: ( ( (lv_inicialization_4_0= RULE_STRING ) ) | this_INT_5= RULE_INT )?
            int alt16=3;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==RULE_STRING) ) {
                alt16=1;
            }
            else if ( (LA16_0==RULE_INT) ) {
                alt16=2;
            }
            switch (alt16) {
                case 1 :
                    // InternalSM2DSL.g:1000:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    {
                    // InternalSM2DSL.g:1000:4: ( (lv_inicialization_4_0= RULE_STRING ) )
                    // InternalSM2DSL.g:1001:5: (lv_inicialization_4_0= RULE_STRING )
                    {
                    // InternalSM2DSL.g:1001:5: (lv_inicialization_4_0= RULE_STRING )
                    // InternalSM2DSL.g:1002:6: lv_inicialization_4_0= RULE_STRING
                    {
                    lv_inicialization_4_0=(Token)match(input,RULE_STRING,FOLLOW_5); 

                    						newLeafNode(lv_inicialization_4_0, grammarAccess.getPropertyAccess().getInicializationSTRINGTerminalRuleCall_4_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getPropertyRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"inicialization",
                    							lv_inicialization_4_0,
                    							"org.eclipse.xtext.common.Terminals.STRING");
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1019:4: this_INT_5= RULE_INT
                    {
                    this_INT_5=(Token)match(input,RULE_INT,FOLLOW_5); 

                    				newLeafNode(this_INT_5, grammarAccess.getPropertyAccess().getINTTerminalRuleCall_4_1());
                    			

                    }
                    break;

            }

            otherlv_6=(Token)match(input,13,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getPropertyAccess().getSemicolonControl000aKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleProperty"


    // $ANTLR start "entryRuleRestriction"
    // InternalSM2DSL.g:1032:1: entryRuleRestriction returns [EObject current=null] : iv_ruleRestriction= ruleRestriction EOF ;
    public final EObject entryRuleRestriction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestriction = null;


        try {
            // InternalSM2DSL.g:1032:52: (iv_ruleRestriction= ruleRestriction EOF )
            // InternalSM2DSL.g:1033:2: iv_ruleRestriction= ruleRestriction EOF
            {
             newCompositeNode(grammarAccess.getRestrictionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestriction=ruleRestriction();

            state._fsp--;

             current =iv_ruleRestriction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestriction"


    // $ANTLR start "ruleRestriction"
    // InternalSM2DSL.g:1039:1: ruleRestriction returns [EObject current=null] : (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) otherlv_5= ');\\n' ) ;
    public final EObject ruleRestriction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_5=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        EObject lv_expr_4_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1045:2: ( (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) otherlv_5= ');\\n' ) )
            // InternalSM2DSL.g:1046:2: (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) otherlv_5= ');\\n' )
            {
            // InternalSM2DSL.g:1046:2: (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) otherlv_5= ');\\n' )
            // InternalSM2DSL.g:1047:3: otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_expr_4_0= ruleSyntaxExpression ) ) otherlv_5= ');\\n'
            {
            otherlv_0=(Token)match(input,36,FOLLOW_18); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionAccess().getRequireKeyword_0());
            		
            otherlv_1=(Token)match(input,24,FOLLOW_32); 

            			newLeafNode(otherlv_1, grammarAccess.getRestrictionAccess().getLeftParenthesisKeyword_1());
            		
            // InternalSM2DSL.g:1055:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2DSL.g:1056:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2DSL.g:1056:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2DSL.g:1057:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_33);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2DSL.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2DSL.g:1074:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2DSL.g:1075:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2DSL.g:1075:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2DSL.g:1076:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_32);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2DSL.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2DSL.g:1093:3: ( (lv_expr_4_0= ruleSyntaxExpression ) )
            // InternalSM2DSL.g:1094:4: (lv_expr_4_0= ruleSyntaxExpression )
            {
            // InternalSM2DSL.g:1094:4: (lv_expr_4_0= ruleSyntaxExpression )
            // InternalSM2DSL.g:1095:5: lv_expr_4_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionAccess().getExprSyntaxExpressionParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_34);
            lv_expr_4_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_4_0,
            						"org.xtext.SM2DSL.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,37,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getRestrictionAccess().getRightParenthesisSemicolonControl000aKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestriction"


    // $ANTLR start "entryRuleRestrictionGas"
    // InternalSM2DSL.g:1120:1: entryRuleRestrictionGas returns [EObject current=null] : iv_ruleRestrictionGas= ruleRestrictionGas EOF ;
    public final EObject entryRuleRestrictionGas() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRestrictionGas = null;


        try {
            // InternalSM2DSL.g:1120:55: (iv_ruleRestrictionGas= ruleRestrictionGas EOF )
            // InternalSM2DSL.g:1121:2: iv_ruleRestrictionGas= ruleRestrictionGas EOF
            {
             newCompositeNode(grammarAccess.getRestrictionGasRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRestrictionGas=ruleRestrictionGas();

            state._fsp--;

             current =iv_ruleRestrictionGas; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRestrictionGas"


    // $ANTLR start "ruleRestrictionGas"
    // InternalSM2DSL.g:1127:1: ruleRestrictionGas returns [EObject current=null] : (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) otherlv_6= ');\\n' ) ;
    public final EObject ruleRestrictionGas() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token lv_amount_4_0=null;
        Token otherlv_6=null;
        EObject lv_expr_2_0 = null;

        Enumerator lv_operator_3_0 = null;

        Enumerator lv_typeCoin_5_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1133:2: ( (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) otherlv_6= ');\\n' ) )
            // InternalSM2DSL.g:1134:2: (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) otherlv_6= ');\\n' )
            {
            // InternalSM2DSL.g:1134:2: (otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) otherlv_6= ');\\n' )
            // InternalSM2DSL.g:1135:3: otherlv_0= 'require' otherlv_1= '(' ( (lv_expr_2_0= ruleSyntaxExpression ) ) ( (lv_operator_3_0= ruleComparationOperator ) ) ( (lv_amount_4_0= RULE_INT ) ) ( (lv_typeCoin_5_0= ruleCoin ) ) otherlv_6= ');\\n'
            {
            otherlv_0=(Token)match(input,36,FOLLOW_18); 

            			newLeafNode(otherlv_0, grammarAccess.getRestrictionGasAccess().getRequireKeyword_0());
            		
            otherlv_1=(Token)match(input,24,FOLLOW_32); 

            			newLeafNode(otherlv_1, grammarAccess.getRestrictionGasAccess().getLeftParenthesisKeyword_1());
            		
            // InternalSM2DSL.g:1143:3: ( (lv_expr_2_0= ruleSyntaxExpression ) )
            // InternalSM2DSL.g:1144:4: (lv_expr_2_0= ruleSyntaxExpression )
            {
            // InternalSM2DSL.g:1144:4: (lv_expr_2_0= ruleSyntaxExpression )
            // InternalSM2DSL.g:1145:5: lv_expr_2_0= ruleSyntaxExpression
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getExprSyntaxExpressionParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_33);
            lv_expr_2_0=ruleSyntaxExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"expr",
            						lv_expr_2_0,
            						"org.xtext.SM2DSL.SyntaxExpression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2DSL.g:1162:3: ( (lv_operator_3_0= ruleComparationOperator ) )
            // InternalSM2DSL.g:1163:4: (lv_operator_3_0= ruleComparationOperator )
            {
            // InternalSM2DSL.g:1163:4: (lv_operator_3_0= ruleComparationOperator )
            // InternalSM2DSL.g:1164:5: lv_operator_3_0= ruleComparationOperator
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getOperatorComparationOperatorEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_14);
            lv_operator_3_0=ruleComparationOperator();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"operator",
            						lv_operator_3_0,
            						"org.xtext.SM2DSL.ComparationOperator");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalSM2DSL.g:1181:3: ( (lv_amount_4_0= RULE_INT ) )
            // InternalSM2DSL.g:1182:4: (lv_amount_4_0= RULE_INT )
            {
            // InternalSM2DSL.g:1182:4: (lv_amount_4_0= RULE_INT )
            // InternalSM2DSL.g:1183:5: lv_amount_4_0= RULE_INT
            {
            lv_amount_4_0=(Token)match(input,RULE_INT,FOLLOW_35); 

            					newLeafNode(lv_amount_4_0, grammarAccess.getRestrictionGasAccess().getAmountINTTerminalRuleCall_4_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getRestrictionGasRule());
            					}
            					setWithLastConsumed(
            						current,
            						"amount",
            						lv_amount_4_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalSM2DSL.g:1199:3: ( (lv_typeCoin_5_0= ruleCoin ) )
            // InternalSM2DSL.g:1200:4: (lv_typeCoin_5_0= ruleCoin )
            {
            // InternalSM2DSL.g:1200:4: (lv_typeCoin_5_0= ruleCoin )
            // InternalSM2DSL.g:1201:5: lv_typeCoin_5_0= ruleCoin
            {

            					newCompositeNode(grammarAccess.getRestrictionGasAccess().getTypeCoinCoinEnumRuleCall_5_0());
            				
            pushFollow(FOLLOW_34);
            lv_typeCoin_5_0=ruleCoin();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getRestrictionGasRule());
            					}
            					set(
            						current,
            						"typeCoin",
            						lv_typeCoin_5_0,
            						"org.xtext.SM2DSL.Coin");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,37,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getRestrictionGasAccess().getRightParenthesisSemicolonControl000aKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRestrictionGas"


    // $ANTLR start "entryRuleClause"
    // InternalSM2DSL.g:1226:1: entryRuleClause returns [EObject current=null] : iv_ruleClause= ruleClause EOF ;
    public final EObject entryRuleClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleClause = null;


        try {
            // InternalSM2DSL.g:1226:47: (iv_ruleClause= ruleClause EOF )
            // InternalSM2DSL.g:1227:2: iv_ruleClause= ruleClause EOF
            {
             newCompositeNode(grammarAccess.getClauseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleClause=ruleClause();

            state._fsp--;

             current =iv_ruleClause; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleClause"


    // $ANTLR start "ruleClause"
    // InternalSM2DSL.g:1233:1: ruleClause returns [EObject current=null] : (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) otherlv_5= ')' otherlv_6= '{\\n' ( (lv_restriction_7_0= ruleRestriction ) )? ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )? ( (lv_expression_9_0= ruleExpression ) )? (otherlv_10= '\\n' )? otherlv_11= '}\\n' ) ;
    public final EObject ruleClause() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_nameFunction_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Enumerator lv_visibilityAccess_4_0 = null;

        EObject lv_restriction_7_0 = null;

        EObject lv_restrictionGas_8_0 = null;

        EObject lv_expression_9_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1239:2: ( (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) otherlv_5= ')' otherlv_6= '{\\n' ( (lv_restriction_7_0= ruleRestriction ) )? ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )? ( (lv_expression_9_0= ruleExpression ) )? (otherlv_10= '\\n' )? otherlv_11= '}\\n' ) )
            // InternalSM2DSL.g:1240:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) otherlv_5= ')' otherlv_6= '{\\n' ( (lv_restriction_7_0= ruleRestriction ) )? ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )? ( (lv_expression_9_0= ruleExpression ) )? (otherlv_10= '\\n' )? otherlv_11= '}\\n' )
            {
            // InternalSM2DSL.g:1240:2: (otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) otherlv_5= ')' otherlv_6= '{\\n' ( (lv_restriction_7_0= ruleRestriction ) )? ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )? ( (lv_expression_9_0= ruleExpression ) )? (otherlv_10= '\\n' )? otherlv_11= '}\\n' )
            // InternalSM2DSL.g:1241:3: otherlv_0= 'function' ( (lv_nameFunction_1_0= RULE_ID ) ) otherlv_2= '(' ( (otherlv_3= RULE_ID ) ) ( (lv_visibilityAccess_4_0= ruleVisibility ) ) otherlv_5= ')' otherlv_6= '{\\n' ( (lv_restriction_7_0= ruleRestriction ) )? ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )? ( (lv_expression_9_0= ruleExpression ) )? (otherlv_10= '\\n' )? otherlv_11= '}\\n'
            {
            otherlv_0=(Token)match(input,38,FOLLOW_7); 

            			newLeafNode(otherlv_0, grammarAccess.getClauseAccess().getFunctionKeyword_0());
            		
            // InternalSM2DSL.g:1245:3: ( (lv_nameFunction_1_0= RULE_ID ) )
            // InternalSM2DSL.g:1246:4: (lv_nameFunction_1_0= RULE_ID )
            {
            // InternalSM2DSL.g:1246:4: (lv_nameFunction_1_0= RULE_ID )
            // InternalSM2DSL.g:1247:5: lv_nameFunction_1_0= RULE_ID
            {
            lv_nameFunction_1_0=(Token)match(input,RULE_ID,FOLLOW_18); 

            					newLeafNode(lv_nameFunction_1_0, grammarAccess.getClauseAccess().getNameFunctionIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            					setWithLastConsumed(
            						current,
            						"nameFunction",
            						lv_nameFunction_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,24,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getClauseAccess().getLeftParenthesisKeyword_2());
            		
            // InternalSM2DSL.g:1267:3: ( (otherlv_3= RULE_ID ) )
            // InternalSM2DSL.g:1268:4: (otherlv_3= RULE_ID )
            {
            // InternalSM2DSL.g:1268:4: (otherlv_3= RULE_ID )
            // InternalSM2DSL.g:1269:5: otherlv_3= RULE_ID
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getClauseRule());
            					}
            				
            otherlv_3=(Token)match(input,RULE_ID,FOLLOW_36); 

            					newLeafNode(otherlv_3, grammarAccess.getClauseAccess().getInputParamsInputParamCrossReference_3_0());
            				

            }


            }

            // InternalSM2DSL.g:1280:3: ( (lv_visibilityAccess_4_0= ruleVisibility ) )
            // InternalSM2DSL.g:1281:4: (lv_visibilityAccess_4_0= ruleVisibility )
            {
            // InternalSM2DSL.g:1281:4: (lv_visibilityAccess_4_0= ruleVisibility )
            // InternalSM2DSL.g:1282:5: lv_visibilityAccess_4_0= ruleVisibility
            {

            					newCompositeNode(grammarAccess.getClauseAccess().getVisibilityAccessVisibilityEnumRuleCall_4_0());
            				
            pushFollow(FOLLOW_24);
            lv_visibilityAccess_4_0=ruleVisibility();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getClauseRule());
            					}
            					set(
            						current,
            						"visibilityAccess",
            						lv_visibilityAccess_4_0,
            						"org.xtext.SM2DSL.Visibility");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,25,FOLLOW_9); 

            			newLeafNode(otherlv_5, grammarAccess.getClauseAccess().getRightParenthesisKeyword_5());
            		
            otherlv_6=(Token)match(input,16,FOLLOW_37); 

            			newLeafNode(otherlv_6, grammarAccess.getClauseAccess().getLeftCurlyBracketControl000aKeyword_6());
            		
            // InternalSM2DSL.g:1307:3: ( (lv_restriction_7_0= ruleRestriction ) )?
            int alt17=2;
            alt17 = dfa17.predict(input);
            switch (alt17) {
                case 1 :
                    // InternalSM2DSL.g:1308:4: (lv_restriction_7_0= ruleRestriction )
                    {
                    // InternalSM2DSL.g:1308:4: (lv_restriction_7_0= ruleRestriction )
                    // InternalSM2DSL.g:1309:5: lv_restriction_7_0= ruleRestriction
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionRestrictionParserRuleCall_7_0());
                    				
                    pushFollow(FOLLOW_37);
                    lv_restriction_7_0=ruleRestriction();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restriction",
                    						lv_restriction_7_0,
                    						"org.xtext.SM2DSL.Restriction");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2DSL.g:1326:3: ( (lv_restrictionGas_8_0= ruleRestrictionGas ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==36) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalSM2DSL.g:1327:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
                    {
                    // InternalSM2DSL.g:1327:4: (lv_restrictionGas_8_0= ruleRestrictionGas )
                    // InternalSM2DSL.g:1328:5: lv_restrictionGas_8_0= ruleRestrictionGas
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getRestrictionGasRestrictionGasParserRuleCall_8_0());
                    				
                    pushFollow(FOLLOW_38);
                    lv_restrictionGas_8_0=ruleRestrictionGas();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"restrictionGas",
                    						lv_restrictionGas_8_0,
                    						"org.xtext.SM2DSL.RestrictionGas");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2DSL.g:1345:3: ( (lv_expression_9_0= ruleExpression ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( ((LA19_0>=RULE_INT && LA19_0<=RULE_STRING)||LA19_0==24) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalSM2DSL.g:1346:4: (lv_expression_9_0= ruleExpression )
                    {
                    // InternalSM2DSL.g:1346:4: (lv_expression_9_0= ruleExpression )
                    // InternalSM2DSL.g:1347:5: lv_expression_9_0= ruleExpression
                    {

                    					newCompositeNode(grammarAccess.getClauseAccess().getExpressionExpressionParserRuleCall_9_0());
                    				
                    pushFollow(FOLLOW_39);
                    lv_expression_9_0=ruleExpression();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getClauseRule());
                    					}
                    					add(
                    						current,
                    						"expression",
                    						lv_expression_9_0,
                    						"org.xtext.SM2DSL.Expression");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalSM2DSL.g:1364:3: (otherlv_10= '\\n' )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==39) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalSM2DSL.g:1365:4: otherlv_10= '\\n'
                    {
                    otherlv_10=(Token)match(input,39,FOLLOW_21); 

                    				newLeafNode(otherlv_10, grammarAccess.getClauseAccess().getLineFeedKeyword_10());
                    			

                    }
                    break;

            }

            otherlv_11=(Token)match(input,27,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getClauseAccess().getRightCurlyBracketControl000aKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleClause"


    // $ANTLR start "entryRuleSelfdestruct"
    // InternalSM2DSL.g:1378:1: entryRuleSelfdestruct returns [String current=null] : iv_ruleSelfdestruct= ruleSelfdestruct EOF ;
    public final String entryRuleSelfdestruct() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleSelfdestruct = null;


        try {
            // InternalSM2DSL.g:1378:52: (iv_ruleSelfdestruct= ruleSelfdestruct EOF )
            // InternalSM2DSL.g:1379:2: iv_ruleSelfdestruct= ruleSelfdestruct EOF
            {
             newCompositeNode(grammarAccess.getSelfdestructRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSelfdestruct=ruleSelfdestruct();

            state._fsp--;

             current =iv_ruleSelfdestruct.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSelfdestruct"


    // $ANTLR start "ruleSelfdestruct"
    // InternalSM2DSL.g:1385:1: ruleSelfdestruct returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'selfdesctruct' kw= '(' kw= ');\\n' ) ;
    public final AntlrDatatypeRuleToken ruleSelfdestruct() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1391:2: ( (kw= 'selfdesctruct' kw= '(' kw= ');\\n' ) )
            // InternalSM2DSL.g:1392:2: (kw= 'selfdesctruct' kw= '(' kw= ');\\n' )
            {
            // InternalSM2DSL.g:1392:2: (kw= 'selfdesctruct' kw= '(' kw= ');\\n' )
            // InternalSM2DSL.g:1393:3: kw= 'selfdesctruct' kw= '(' kw= ');\\n'
            {
            kw=(Token)match(input,40,FOLLOW_18); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getSelfdestructAccess().getSelfdesctructKeyword_0());
            		
            kw=(Token)match(input,24,FOLLOW_34); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getSelfdestructAccess().getLeftParenthesisKeyword_1());
            		
            kw=(Token)match(input,37,FOLLOW_2); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getSelfdestructAccess().getRightParenthesisSemicolonControl000aKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSelfdestruct"


    // $ANTLR start "entryRuleExpression"
    // InternalSM2DSL.g:1412:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalSM2DSL.g:1412:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalSM2DSL.g:1413:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalSM2DSL.g:1419:1: ruleExpression returns [EObject current=null] : (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_ArithmethicalExpression_0 = null;

        EObject this_SyntaxExpression_1 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1425:2: ( (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression ) )
            // InternalSM2DSL.g:1426:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            {
            // InternalSM2DSL.g:1426:2: (this_ArithmethicalExpression_0= ruleArithmethicalExpression | this_SyntaxExpression_1= ruleSyntaxExpression )
            int alt21=2;
            switch ( input.LA(1) ) {
            case 24:
                {
                alt21=1;
                }
                break;
            case RULE_INT:
                {
                int LA21_2 = input.LA(2);

                if ( (LA21_2==EOF||LA21_2==13||LA21_2==27||LA21_2==39) ) {
                    alt21=2;
                }
                else if ( ((LA21_2>=68 && LA21_2<=71)) ) {
                    alt21=1;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 21, 2, input);

                    throw nvae;
                }
                }
                break;
            case RULE_STRING:
                {
                alt21=2;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // InternalSM2DSL.g:1427:3: this_ArithmethicalExpression_0= ruleArithmethicalExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getArithmethicalExpressionParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ArithmethicalExpression_0=ruleArithmethicalExpression();

                    state._fsp--;


                    			current = this_ArithmethicalExpression_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1436:3: this_SyntaxExpression_1= ruleSyntaxExpression
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getSyntaxExpressionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_SyntaxExpression_1=ruleSyntaxExpression();

                    state._fsp--;


                    			current = this_SyntaxExpression_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleArithmethicalExpression"
    // InternalSM2DSL.g:1448:1: entryRuleArithmethicalExpression returns [EObject current=null] : iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF ;
    public final EObject entryRuleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleArithmethicalExpression = null;


        try {
            // InternalSM2DSL.g:1448:64: (iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF )
            // InternalSM2DSL.g:1449:2: iv_ruleArithmethicalExpression= ruleArithmethicalExpression EOF
            {
             newCompositeNode(grammarAccess.getArithmethicalExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleArithmethicalExpression=ruleArithmethicalExpression();

            state._fsp--;

             current =iv_ruleArithmethicalExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleArithmethicalExpression"


    // $ANTLR start "ruleArithmethicalExpression"
    // InternalSM2DSL.g:1455:1: ruleArithmethicalExpression returns [EObject current=null] : ( (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? ) ) ;
    public final EObject ruleArithmethicalExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_op1_1_0=null;
        Token lv_op2_3_0=null;
        Token otherlv_4=null;
        Token lv_op1_5_0=null;
        Token lv_op2_7_0=null;
        Token otherlv_8=null;
        Enumerator lv_operator_2_0 = null;

        Enumerator lv_operator_6_0 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1461:2: ( ( (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? ) ) )
            // InternalSM2DSL.g:1462:2: ( (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? ) )
            {
            // InternalSM2DSL.g:1462:2: ( (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' ) | ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? ) )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==24) ) {
                alt23=1;
            }
            else if ( (LA23_0==RULE_INT) ) {
                alt23=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // InternalSM2DSL.g:1463:3: (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' )
                    {
                    // InternalSM2DSL.g:1463:3: (otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')' )
                    // InternalSM2DSL.g:1464:4: otherlv_0= '(' ( (lv_op1_1_0= RULE_INT ) ) ( (lv_operator_2_0= ruleArithmeticalOperator ) ) ( (lv_op2_3_0= RULE_INT ) ) otherlv_4= ')'
                    {
                    otherlv_0=(Token)match(input,24,FOLLOW_14); 

                    				newLeafNode(otherlv_0, grammarAccess.getArithmethicalExpressionAccess().getLeftParenthesisKeyword_0_0());
                    			
                    // InternalSM2DSL.g:1468:4: ( (lv_op1_1_0= RULE_INT ) )
                    // InternalSM2DSL.g:1469:5: (lv_op1_1_0= RULE_INT )
                    {
                    // InternalSM2DSL.g:1469:5: (lv_op1_1_0= RULE_INT )
                    // InternalSM2DSL.g:1470:6: lv_op1_1_0= RULE_INT
                    {
                    lv_op1_1_0=(Token)match(input,RULE_INT,FOLLOW_40); 

                    						newLeafNode(lv_op1_1_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_0_1_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op1",
                    							lv_op1_1_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2DSL.g:1486:4: ( (lv_operator_2_0= ruleArithmeticalOperator ) )
                    // InternalSM2DSL.g:1487:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2DSL.g:1487:5: (lv_operator_2_0= ruleArithmeticalOperator )
                    // InternalSM2DSL.g:1488:6: lv_operator_2_0= ruleArithmeticalOperator
                    {

                    						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_0_2_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_operator_2_0=ruleArithmeticalOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						set(
                    							current,
                    							"operator",
                    							lv_operator_2_0,
                    							"org.xtext.SM2DSL.ArithmeticalOperator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalSM2DSL.g:1505:4: ( (lv_op2_3_0= RULE_INT ) )
                    // InternalSM2DSL.g:1506:5: (lv_op2_3_0= RULE_INT )
                    {
                    // InternalSM2DSL.g:1506:5: (lv_op2_3_0= RULE_INT )
                    // InternalSM2DSL.g:1507:6: lv_op2_3_0= RULE_INT
                    {
                    lv_op2_3_0=(Token)match(input,RULE_INT,FOLLOW_24); 

                    						newLeafNode(lv_op2_3_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_0_3_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op2",
                    							lv_op2_3_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    otherlv_4=(Token)match(input,25,FOLLOW_2); 

                    				newLeafNode(otherlv_4, grammarAccess.getArithmethicalExpressionAccess().getRightParenthesisKeyword_0_4());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1529:3: ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? )
                    {
                    // InternalSM2DSL.g:1529:3: ( ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )? )
                    // InternalSM2DSL.g:1530:4: ( (lv_op1_5_0= RULE_INT ) ) ( (lv_operator_6_0= ruleArithmeticalOperator ) ) ( (lv_op2_7_0= RULE_INT ) ) (otherlv_8= ';\\n' )?
                    {
                    // InternalSM2DSL.g:1530:4: ( (lv_op1_5_0= RULE_INT ) )
                    // InternalSM2DSL.g:1531:5: (lv_op1_5_0= RULE_INT )
                    {
                    // InternalSM2DSL.g:1531:5: (lv_op1_5_0= RULE_INT )
                    // InternalSM2DSL.g:1532:6: lv_op1_5_0= RULE_INT
                    {
                    lv_op1_5_0=(Token)match(input,RULE_INT,FOLLOW_40); 

                    						newLeafNode(lv_op1_5_0, grammarAccess.getArithmethicalExpressionAccess().getOp1INTTerminalRuleCall_1_0_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op1",
                    							lv_op1_5_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2DSL.g:1548:4: ( (lv_operator_6_0= ruleArithmeticalOperator ) )
                    // InternalSM2DSL.g:1549:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    {
                    // InternalSM2DSL.g:1549:5: (lv_operator_6_0= ruleArithmeticalOperator )
                    // InternalSM2DSL.g:1550:6: lv_operator_6_0= ruleArithmeticalOperator
                    {

                    						newCompositeNode(grammarAccess.getArithmethicalExpressionAccess().getOperatorArithmeticalOperatorEnumRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_14);
                    lv_operator_6_0=ruleArithmeticalOperator();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						set(
                    							current,
                    							"operator",
                    							lv_operator_6_0,
                    							"org.xtext.SM2DSL.ArithmeticalOperator");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalSM2DSL.g:1567:4: ( (lv_op2_7_0= RULE_INT ) )
                    // InternalSM2DSL.g:1568:5: (lv_op2_7_0= RULE_INT )
                    {
                    // InternalSM2DSL.g:1568:5: (lv_op2_7_0= RULE_INT )
                    // InternalSM2DSL.g:1569:6: lv_op2_7_0= RULE_INT
                    {
                    lv_op2_7_0=(Token)match(input,RULE_INT,FOLLOW_41); 

                    						newLeafNode(lv_op2_7_0, grammarAccess.getArithmethicalExpressionAccess().getOp2INTTerminalRuleCall_1_2_0());
                    					

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getArithmethicalExpressionRule());
                    						}
                    						setWithLastConsumed(
                    							current,
                    							"op2",
                    							lv_op2_7_0,
                    							"org.eclipse.xtext.common.Terminals.INT");
                    					

                    }


                    }

                    // InternalSM2DSL.g:1585:4: (otherlv_8= ';\\n' )?
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==13) ) {
                        alt22=1;
                    }
                    switch (alt22) {
                        case 1 :
                            // InternalSM2DSL.g:1586:5: otherlv_8= ';\\n'
                            {
                            otherlv_8=(Token)match(input,13,FOLLOW_2); 

                            					newLeafNode(otherlv_8, grammarAccess.getArithmethicalExpressionAccess().getSemicolonControl000aKeyword_1_3());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmethicalExpression"


    // $ANTLR start "entryRuleSyntaxExpression"
    // InternalSM2DSL.g:1596:1: entryRuleSyntaxExpression returns [EObject current=null] : iv_ruleSyntaxExpression= ruleSyntaxExpression EOF ;
    public final EObject entryRuleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSyntaxExpression = null;


        try {
            // InternalSM2DSL.g:1596:57: (iv_ruleSyntaxExpression= ruleSyntaxExpression EOF )
            // InternalSM2DSL.g:1597:2: iv_ruleSyntaxExpression= ruleSyntaxExpression EOF
            {
             newCompositeNode(grammarAccess.getSyntaxExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSyntaxExpression=ruleSyntaxExpression();

            state._fsp--;

             current =iv_ruleSyntaxExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSyntaxExpression"


    // $ANTLR start "ruleSyntaxExpression"
    // InternalSM2DSL.g:1603:1: ruleSyntaxExpression returns [EObject current=null] : ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? ) ) ;
    public final EObject ruleSyntaxExpression() throws RecognitionException {
        EObject current = null;

        Token lv_text_0_0=null;
        Token this_INT_1=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1609:2: ( ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? ) ) )
            // InternalSM2DSL.g:1610:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? ) )
            {
            // InternalSM2DSL.g:1610:2: ( ( (lv_text_0_0= RULE_STRING ) ) | (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? ) )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==RULE_STRING) ) {
                alt25=1;
            }
            else if ( (LA25_0==RULE_INT) ) {
                alt25=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // InternalSM2DSL.g:1611:3: ( (lv_text_0_0= RULE_STRING ) )
                    {
                    // InternalSM2DSL.g:1611:3: ( (lv_text_0_0= RULE_STRING ) )
                    // InternalSM2DSL.g:1612:4: (lv_text_0_0= RULE_STRING )
                    {
                    // InternalSM2DSL.g:1612:4: (lv_text_0_0= RULE_STRING )
                    // InternalSM2DSL.g:1613:5: lv_text_0_0= RULE_STRING
                    {
                    lv_text_0_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    					newLeafNode(lv_text_0_0, grammarAccess.getSyntaxExpressionAccess().getTextSTRINGTerminalRuleCall_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getSyntaxExpressionRule());
                    					}
                    					setWithLastConsumed(
                    						current,
                    						"text",
                    						lv_text_0_0,
                    						"org.eclipse.xtext.common.Terminals.STRING");
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1630:3: (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? )
                    {
                    // InternalSM2DSL.g:1630:3: (this_INT_1= RULE_INT (otherlv_2= ';\\n' )? )
                    // InternalSM2DSL.g:1631:4: this_INT_1= RULE_INT (otherlv_2= ';\\n' )?
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_41); 

                    				newLeafNode(this_INT_1, grammarAccess.getSyntaxExpressionAccess().getINTTerminalRuleCall_1_0());
                    			
                    // InternalSM2DSL.g:1635:4: (otherlv_2= ';\\n' )?
                    int alt24=2;
                    int LA24_0 = input.LA(1);

                    if ( (LA24_0==13) ) {
                        alt24=1;
                    }
                    switch (alt24) {
                        case 1 :
                            // InternalSM2DSL.g:1636:5: otherlv_2= ';\\n'
                            {
                            otherlv_2=(Token)match(input,13,FOLLOW_2); 

                            					newLeafNode(otherlv_2, grammarAccess.getSyntaxExpressionAccess().getSemicolonControl000aKeyword_1_1());
                            				

                            }
                            break;

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSyntaxExpression"


    // $ANTLR start "entryRuleComment"
    // InternalSM2DSL.g:1646:1: entryRuleComment returns [EObject current=null] : iv_ruleComment= ruleComment EOF ;
    public final EObject entryRuleComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleComment = null;


        try {
            // InternalSM2DSL.g:1646:48: (iv_ruleComment= ruleComment EOF )
            // InternalSM2DSL.g:1647:2: iv_ruleComment= ruleComment EOF
            {
             newCompositeNode(grammarAccess.getCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComment=ruleComment();

            state._fsp--;

             current =iv_ruleComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComment"


    // $ANTLR start "ruleComment"
    // InternalSM2DSL.g:1653:1: ruleComment returns [EObject current=null] : (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) ;
    public final EObject ruleComment() throws RecognitionException {
        EObject current = null;

        EObject this_ShortComment_0 = null;

        EObject this_LongComment_1 = null;



        	enterRule();

        try {
            // InternalSM2DSL.g:1659:2: ( (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment ) )
            // InternalSM2DSL.g:1660:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            {
            // InternalSM2DSL.g:1660:2: (this_ShortComment_0= ruleShortComment | this_LongComment_1= ruleLongComment )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==41) ) {
                alt26=1;
            }
            else if ( (LA26_0==43) ) {
                alt26=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // InternalSM2DSL.g:1661:3: this_ShortComment_0= ruleShortComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getShortCommentParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_ShortComment_0=ruleShortComment();

                    state._fsp--;


                    			current = this_ShortComment_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1670:3: this_LongComment_1= ruleLongComment
                    {

                    			newCompositeNode(grammarAccess.getCommentAccess().getLongCommentParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_LongComment_1=ruleLongComment();

                    state._fsp--;


                    			current = this_LongComment_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComment"


    // $ANTLR start "entryRuleShortComment"
    // InternalSM2DSL.g:1682:1: entryRuleShortComment returns [EObject current=null] : iv_ruleShortComment= ruleShortComment EOF ;
    public final EObject entryRuleShortComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShortComment = null;


        try {
            // InternalSM2DSL.g:1682:53: (iv_ruleShortComment= ruleShortComment EOF )
            // InternalSM2DSL.g:1683:2: iv_ruleShortComment= ruleShortComment EOF
            {
             newCompositeNode(grammarAccess.getShortCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShortComment=ruleShortComment();

            state._fsp--;

             current =iv_ruleShortComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShortComment"


    // $ANTLR start "ruleShortComment"
    // InternalSM2DSL.g:1689:1: ruleShortComment returns [EObject current=null] : (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '/n' ) ;
    public final EObject ruleShortComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1695:2: ( (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '/n' ) )
            // InternalSM2DSL.g:1696:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '/n' )
            {
            // InternalSM2DSL.g:1696:2: (otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '/n' )
            // InternalSM2DSL.g:1697:3: otherlv_0= '//' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '/n'
            {
            otherlv_0=(Token)match(input,41,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getShortCommentAccess().getSolidusSolidusKeyword_0());
            		
            // InternalSM2DSL.g:1701:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2DSL.g:1702:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2DSL.g:1702:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2DSL.g:1703:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_42); 

            					newLeafNode(lv_expr_1_0, grammarAccess.getShortCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getShortCommentRule());
            					}
            					setWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,42,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getShortCommentAccess().getNKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShortComment"


    // $ANTLR start "entryRuleLongComment"
    // InternalSM2DSL.g:1727:1: entryRuleLongComment returns [EObject current=null] : iv_ruleLongComment= ruleLongComment EOF ;
    public final EObject entryRuleLongComment() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLongComment = null;


        try {
            // InternalSM2DSL.g:1727:52: (iv_ruleLongComment= ruleLongComment EOF )
            // InternalSM2DSL.g:1728:2: iv_ruleLongComment= ruleLongComment EOF
            {
             newCompositeNode(grammarAccess.getLongCommentRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLongComment=ruleLongComment();

            state._fsp--;

             current =iv_ruleLongComment; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLongComment"


    // $ANTLR start "ruleLongComment"
    // InternalSM2DSL.g:1734:1: ruleLongComment returns [EObject current=null] : (otherlv_0= '/*' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '*/' ) ;
    public final EObject ruleLongComment() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_expr_1_0=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1740:2: ( (otherlv_0= '/*' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '*/' ) )
            // InternalSM2DSL.g:1741:2: (otherlv_0= '/*' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '*/' )
            {
            // InternalSM2DSL.g:1741:2: (otherlv_0= '/*' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '*/' )
            // InternalSM2DSL.g:1742:3: otherlv_0= '/*' ( (lv_expr_1_0= RULE_STRING ) ) otherlv_2= '*/'
            {
            otherlv_0=(Token)match(input,43,FOLLOW_17); 

            			newLeafNode(otherlv_0, grammarAccess.getLongCommentAccess().getSolidusAsteriskKeyword_0());
            		
            // InternalSM2DSL.g:1746:3: ( (lv_expr_1_0= RULE_STRING ) )
            // InternalSM2DSL.g:1747:4: (lv_expr_1_0= RULE_STRING )
            {
            // InternalSM2DSL.g:1747:4: (lv_expr_1_0= RULE_STRING )
            // InternalSM2DSL.g:1748:5: lv_expr_1_0= RULE_STRING
            {
            lv_expr_1_0=(Token)match(input,RULE_STRING,FOLLOW_43); 

            					newLeafNode(lv_expr_1_0, grammarAccess.getLongCommentAccess().getExprSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getLongCommentRule());
            					}
            					addWithLastConsumed(
            						current,
            						"expr",
            						lv_expr_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            otherlv_2=(Token)match(input,44,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getLongCommentAccess().getAsteriskSolidusKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLongComment"


    // $ANTLR start "ruleSingularType"
    // InternalSM2DSL.g:1772:1: ruleSingularType returns [Enumerator current=null] : ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'string' ) | (enumLiteral_4= 'address' ) | (enumLiteral_5= 'address payable' ) | (enumLiteral_6= 'double' ) | (enumLiteral_7= 'bool' ) ) ;
    public final Enumerator ruleSingularType() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1778:2: ( ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'string' ) | (enumLiteral_4= 'address' ) | (enumLiteral_5= 'address payable' ) | (enumLiteral_6= 'double' ) | (enumLiteral_7= 'bool' ) ) )
            // InternalSM2DSL.g:1779:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'string' ) | (enumLiteral_4= 'address' ) | (enumLiteral_5= 'address payable' ) | (enumLiteral_6= 'double' ) | (enumLiteral_7= 'bool' ) )
            {
            // InternalSM2DSL.g:1779:2: ( (enumLiteral_0= 'int' ) | (enumLiteral_1= 'uint' ) | (enumLiteral_2= 'uint8' ) | (enumLiteral_3= 'string' ) | (enumLiteral_4= 'address' ) | (enumLiteral_5= 'address payable' ) | (enumLiteral_6= 'double' ) | (enumLiteral_7= 'bool' ) )
            int alt27=8;
            switch ( input.LA(1) ) {
            case 45:
                {
                alt27=1;
                }
                break;
            case 46:
                {
                alt27=2;
                }
                break;
            case 47:
                {
                alt27=3;
                }
                break;
            case 48:
                {
                alt27=4;
                }
                break;
            case 49:
                {
                alt27=5;
                }
                break;
            case 50:
                {
                alt27=6;
                }
                break;
            case 51:
                {
                alt27=7;
                }
                break;
            case 52:
                {
                alt27=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 27, 0, input);

                throw nvae;
            }

            switch (alt27) {
                case 1 :
                    // InternalSM2DSL.g:1780:3: (enumLiteral_0= 'int' )
                    {
                    // InternalSM2DSL.g:1780:3: (enumLiteral_0= 'int' )
                    // InternalSM2DSL.g:1781:4: enumLiteral_0= 'int'
                    {
                    enumLiteral_0=(Token)match(input,45,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getSingularTypeAccess().getINTEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1788:3: (enumLiteral_1= 'uint' )
                    {
                    // InternalSM2DSL.g:1788:3: (enumLiteral_1= 'uint' )
                    // InternalSM2DSL.g:1789:4: enumLiteral_1= 'uint'
                    {
                    enumLiteral_1=(Token)match(input,46,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getSingularTypeAccess().getUINTEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:1796:3: (enumLiteral_2= 'uint8' )
                    {
                    // InternalSM2DSL.g:1796:3: (enumLiteral_2= 'uint8' )
                    // InternalSM2DSL.g:1797:4: enumLiteral_2= 'uint8'
                    {
                    enumLiteral_2=(Token)match(input,47,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getSingularTypeAccess().getUINT8EnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2DSL.g:1804:3: (enumLiteral_3= 'string' )
                    {
                    // InternalSM2DSL.g:1804:3: (enumLiteral_3= 'string' )
                    // InternalSM2DSL.g:1805:4: enumLiteral_3= 'string'
                    {
                    enumLiteral_3=(Token)match(input,48,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getSingularTypeAccess().getSTRINGEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2DSL.g:1812:3: (enumLiteral_4= 'address' )
                    {
                    // InternalSM2DSL.g:1812:3: (enumLiteral_4= 'address' )
                    // InternalSM2DSL.g:1813:4: enumLiteral_4= 'address'
                    {
                    enumLiteral_4=(Token)match(input,49,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getSingularTypeAccess().getADDRESSEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2DSL.g:1820:3: (enumLiteral_5= 'address payable' )
                    {
                    // InternalSM2DSL.g:1820:3: (enumLiteral_5= 'address payable' )
                    // InternalSM2DSL.g:1821:4: enumLiteral_5= 'address payable'
                    {
                    enumLiteral_5=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getSingularTypeAccess().getADDRESSPAYABLEEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalSM2DSL.g:1828:3: (enumLiteral_6= 'double' )
                    {
                    // InternalSM2DSL.g:1828:3: (enumLiteral_6= 'double' )
                    // InternalSM2DSL.g:1829:4: enumLiteral_6= 'double'
                    {
                    enumLiteral_6=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getSingularTypeAccess().getDOUBLEEnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalSM2DSL.g:1836:3: (enumLiteral_7= 'bool' )
                    {
                    // InternalSM2DSL.g:1836:3: (enumLiteral_7= 'bool' )
                    // InternalSM2DSL.g:1837:4: enumLiteral_7= 'bool'
                    {
                    enumLiteral_7=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getSingularTypeAccess().getBOOLEANEnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSingularType"


    // $ANTLR start "ruleVisibility"
    // InternalSM2DSL.g:1847:1: ruleVisibility returns [Enumerator current=null] : ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) ;
    public final Enumerator ruleVisibility() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1853:2: ( ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) ) )
            // InternalSM2DSL.g:1854:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            {
            // InternalSM2DSL.g:1854:2: ( (enumLiteral_0= 'public' ) | (enumLiteral_1= 'private' ) | (enumLiteral_2= 'internal' ) )
            int alt28=3;
            switch ( input.LA(1) ) {
            case 53:
                {
                alt28=1;
                }
                break;
            case 54:
                {
                alt28=2;
                }
                break;
            case 55:
                {
                alt28=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // InternalSM2DSL.g:1855:3: (enumLiteral_0= 'public' )
                    {
                    // InternalSM2DSL.g:1855:3: (enumLiteral_0= 'public' )
                    // InternalSM2DSL.g:1856:4: enumLiteral_0= 'public'
                    {
                    enumLiteral_0=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getVisibilityAccess().getPUBLICEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1863:3: (enumLiteral_1= 'private' )
                    {
                    // InternalSM2DSL.g:1863:3: (enumLiteral_1= 'private' )
                    // InternalSM2DSL.g:1864:4: enumLiteral_1= 'private'
                    {
                    enumLiteral_1=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getVisibilityAccess().getPRIVATEEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:1871:3: (enumLiteral_2= 'internal' )
                    {
                    // InternalSM2DSL.g:1871:3: (enumLiteral_2= 'internal' )
                    // InternalSM2DSL.g:1872:4: enumLiteral_2= 'internal'
                    {
                    enumLiteral_2=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getVisibilityAccess().getINTERNALEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVisibility"


    // $ANTLR start "ruleCoin"
    // InternalSM2DSL.g:1882:1: ruleCoin returns [Enumerator current=null] : ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) ;
    public final Enumerator ruleCoin() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1888:2: ( ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) ) )
            // InternalSM2DSL.g:1889:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            {
            // InternalSM2DSL.g:1889:2: ( (enumLiteral_0= 'ether' ) | (enumLiteral_1= 'wei' ) | (enumLiteral_2= 'gwei' ) | (enumLiteral_3= 'pwei' ) | (enumLiteral_4= 'finney' ) | (enumLiteral_5= 'szabo' ) )
            int alt29=6;
            switch ( input.LA(1) ) {
            case 56:
                {
                alt29=1;
                }
                break;
            case 57:
                {
                alt29=2;
                }
                break;
            case 58:
                {
                alt29=3;
                }
                break;
            case 59:
                {
                alt29=4;
                }
                break;
            case 60:
                {
                alt29=5;
                }
                break;
            case 61:
                {
                alt29=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 29, 0, input);

                throw nvae;
            }

            switch (alt29) {
                case 1 :
                    // InternalSM2DSL.g:1890:3: (enumLiteral_0= 'ether' )
                    {
                    // InternalSM2DSL.g:1890:3: (enumLiteral_0= 'ether' )
                    // InternalSM2DSL.g:1891:4: enumLiteral_0= 'ether'
                    {
                    enumLiteral_0=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getCoinAccess().getETHEREnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1898:3: (enumLiteral_1= 'wei' )
                    {
                    // InternalSM2DSL.g:1898:3: (enumLiteral_1= 'wei' )
                    // InternalSM2DSL.g:1899:4: enumLiteral_1= 'wei'
                    {
                    enumLiteral_1=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getCoinAccess().getWEIEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:1906:3: (enumLiteral_2= 'gwei' )
                    {
                    // InternalSM2DSL.g:1906:3: (enumLiteral_2= 'gwei' )
                    // InternalSM2DSL.g:1907:4: enumLiteral_2= 'gwei'
                    {
                    enumLiteral_2=(Token)match(input,58,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getCoinAccess().getGWEIEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2DSL.g:1914:3: (enumLiteral_3= 'pwei' )
                    {
                    // InternalSM2DSL.g:1914:3: (enumLiteral_3= 'pwei' )
                    // InternalSM2DSL.g:1915:4: enumLiteral_3= 'pwei'
                    {
                    enumLiteral_3=(Token)match(input,59,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getCoinAccess().getPWEIEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2DSL.g:1922:3: (enumLiteral_4= 'finney' )
                    {
                    // InternalSM2DSL.g:1922:3: (enumLiteral_4= 'finney' )
                    // InternalSM2DSL.g:1923:4: enumLiteral_4= 'finney'
                    {
                    enumLiteral_4=(Token)match(input,60,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getCoinAccess().getFINNEYEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2DSL.g:1930:3: (enumLiteral_5= 'szabo' )
                    {
                    // InternalSM2DSL.g:1930:3: (enumLiteral_5= 'szabo' )
                    // InternalSM2DSL.g:1931:4: enumLiteral_5= 'szabo'
                    {
                    enumLiteral_5=(Token)match(input,61,FOLLOW_2); 

                    				current = grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getCoinAccess().getSZABOEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCoin"


    // $ANTLR start "ruleComparationOperator"
    // InternalSM2DSL.g:1941:1: ruleComparationOperator returns [Enumerator current=null] : ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) ;
    public final Enumerator ruleComparationOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:1947:2: ( ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) ) )
            // InternalSM2DSL.g:1948:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            {
            // InternalSM2DSL.g:1948:2: ( (enumLiteral_0= '>' ) | (enumLiteral_1= '<' ) | (enumLiteral_2= '>=' ) | (enumLiteral_3= '<=' ) | (enumLiteral_4= '==' ) | (enumLiteral_5= '!=' ) )
            int alt30=6;
            switch ( input.LA(1) ) {
            case 19:
                {
                alt30=1;
                }
                break;
            case 62:
                {
                alt30=2;
                }
                break;
            case 20:
                {
                alt30=3;
                }
                break;
            case 63:
                {
                alt30=4;
                }
                break;
            case 64:
                {
                alt30=5;
                }
                break;
            case 65:
                {
                alt30=6;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 30, 0, input);

                throw nvae;
            }

            switch (alt30) {
                case 1 :
                    // InternalSM2DSL.g:1949:3: (enumLiteral_0= '>' )
                    {
                    // InternalSM2DSL.g:1949:3: (enumLiteral_0= '>' )
                    // InternalSM2DSL.g:1950:4: enumLiteral_0= '>'
                    {
                    enumLiteral_0=(Token)match(input,19,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getComparationOperatorAccess().getGreatherThanEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:1957:3: (enumLiteral_1= '<' )
                    {
                    // InternalSM2DSL.g:1957:3: (enumLiteral_1= '<' )
                    // InternalSM2DSL.g:1958:4: enumLiteral_1= '<'
                    {
                    enumLiteral_1=(Token)match(input,62,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getComparationOperatorAccess().getLessThanEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:1965:3: (enumLiteral_2= '>=' )
                    {
                    // InternalSM2DSL.g:1965:3: (enumLiteral_2= '>=' )
                    // InternalSM2DSL.g:1966:4: enumLiteral_2= '>='
                    {
                    enumLiteral_2=(Token)match(input,20,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getComparationOperatorAccess().getGreatherOrEqualThanEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2DSL.g:1973:3: (enumLiteral_3= '<=' )
                    {
                    // InternalSM2DSL.g:1973:3: (enumLiteral_3= '<=' )
                    // InternalSM2DSL.g:1974:4: enumLiteral_3= '<='
                    {
                    enumLiteral_3=(Token)match(input,63,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getComparationOperatorAccess().getLessOrEqualThanEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalSM2DSL.g:1981:3: (enumLiteral_4= '==' )
                    {
                    // InternalSM2DSL.g:1981:3: (enumLiteral_4= '==' )
                    // InternalSM2DSL.g:1982:4: enumLiteral_4= '=='
                    {
                    enumLiteral_4=(Token)match(input,64,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getComparationOperatorAccess().getEqualToEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalSM2DSL.g:1989:3: (enumLiteral_5= '!=' )
                    {
                    // InternalSM2DSL.g:1989:3: (enumLiteral_5= '!=' )
                    // InternalSM2DSL.g:1990:4: enumLiteral_5= '!='
                    {
                    enumLiteral_5=(Token)match(input,65,FOLLOW_2); 

                    				current = grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getComparationOperatorAccess().getNotEqualToEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComparationOperator"


    // $ANTLR start "ruleLogicalPairOperator"
    // InternalSM2DSL.g:2000:1: ruleLogicalPairOperator returns [Enumerator current=null] : ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) ;
    public final Enumerator ruleLogicalPairOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:2006:2: ( ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) ) )
            // InternalSM2DSL.g:2007:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            {
            // InternalSM2DSL.g:2007:2: ( (enumLiteral_0= '&&' ) | (enumLiteral_1= '||' ) )
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==66) ) {
                alt31=1;
            }
            else if ( (LA31_0==67) ) {
                alt31=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 31, 0, input);

                throw nvae;
            }
            switch (alt31) {
                case 1 :
                    // InternalSM2DSL.g:2008:3: (enumLiteral_0= '&&' )
                    {
                    // InternalSM2DSL.g:2008:3: (enumLiteral_0= '&&' )
                    // InternalSM2DSL.g:2009:4: enumLiteral_0= '&&'
                    {
                    enumLiteral_0=(Token)match(input,66,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getLogicalPairOperatorAccess().getANDEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:2016:3: (enumLiteral_1= '||' )
                    {
                    // InternalSM2DSL.g:2016:3: (enumLiteral_1= '||' )
                    // InternalSM2DSL.g:2017:4: enumLiteral_1= '||'
                    {
                    enumLiteral_1=(Token)match(input,67,FOLLOW_2); 

                    				current = grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getLogicalPairOperatorAccess().getOREnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLogicalPairOperator"


    // $ANTLR start "ruleArithmeticalOperator"
    // InternalSM2DSL.g:2027:1: ruleArithmeticalOperator returns [Enumerator current=null] : ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) ;
    public final Enumerator ruleArithmeticalOperator() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalSM2DSL.g:2033:2: ( ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) ) )
            // InternalSM2DSL.g:2034:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            {
            // InternalSM2DSL.g:2034:2: ( (enumLiteral_0= '+' ) | (enumLiteral_1= '-' ) | (enumLiteral_2= '*' ) | (enumLiteral_3= '/' ) )
            int alt32=4;
            switch ( input.LA(1) ) {
            case 68:
                {
                alt32=1;
                }
                break;
            case 69:
                {
                alt32=2;
                }
                break;
            case 70:
                {
                alt32=3;
                }
                break;
            case 71:
                {
                alt32=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 32, 0, input);

                throw nvae;
            }

            switch (alt32) {
                case 1 :
                    // InternalSM2DSL.g:2035:3: (enumLiteral_0= '+' )
                    {
                    // InternalSM2DSL.g:2035:3: (enumLiteral_0= '+' )
                    // InternalSM2DSL.g:2036:4: enumLiteral_0= '+'
                    {
                    enumLiteral_0=(Token)match(input,68,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getArithmeticalOperatorAccess().getAddEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalSM2DSL.g:2043:3: (enumLiteral_1= '-' )
                    {
                    // InternalSM2DSL.g:2043:3: (enumLiteral_1= '-' )
                    // InternalSM2DSL.g:2044:4: enumLiteral_1= '-'
                    {
                    enumLiteral_1=(Token)match(input,69,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getArithmeticalOperatorAccess().getSubtractEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalSM2DSL.g:2051:3: (enumLiteral_2= '*' )
                    {
                    // InternalSM2DSL.g:2051:3: (enumLiteral_2= '*' )
                    // InternalSM2DSL.g:2052:4: enumLiteral_2= '*'
                    {
                    enumLiteral_2=(Token)match(input,70,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getArithmeticalOperatorAccess().getMultiplyEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalSM2DSL.g:2059:3: (enumLiteral_3= '/' )
                    {
                    // InternalSM2DSL.g:2059:3: (enumLiteral_3= '/' )
                    // InternalSM2DSL.g:2060:4: enumLiteral_3= '/'
                    {
                    enumLiteral_3=(Token)match(input,71,FOLLOW_2); 

                    				current = grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getArithmeticalOperatorAccess().getDivideEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleArithmeticalOperator"

    // Delegated rules


    protected DFA17 dfa17 = new DFA17(this);
    static final String dfa_1s = "\17\uffff";
    static final String dfa_2s = "\1\5\1\30\1\uffff\1\5\1\23\1\15\6\5\1\23\1\15\1\uffff";
    static final String dfa_3s = "\1\47\1\30\1\uffff\1\6\2\101\6\6\1\101\1\75\1\uffff";
    static final String dfa_4s = "\2\uffff\1\2\13\uffff\1\1";
    static final String dfa_5s = "\17\uffff}>";
    static final String[] dfa_6s = {
            "\2\2\21\uffff\1\2\2\uffff\1\2\10\uffff\1\1\2\uffff\1\2",
            "\1\3",
            "",
            "\1\5\1\4",
            "\1\6\1\10\51\uffff\1\7\1\11\1\12\1\13",
            "\1\14\5\uffff\1\6\1\10\51\uffff\1\7\1\11\1\12\1\13",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\15\1\16",
            "\1\6\1\10\51\uffff\1\7\1\11\1\12\1\13",
            "\1\16\27\uffff\1\16\22\uffff\6\2",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA17 extends DFA {

        public DFA17(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 17;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "1307:3: ( (lv_restriction_7_0= ruleRestriction ) )?";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x00000000001C0000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000404000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000018000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x001FEA4190820010L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x00000A4000820000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000A4000020000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x00000A0000020000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000002000010L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x001FE00000000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x00E0000000000010L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000400020000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000002060L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0xC000000000180000L,0x0000000000000003L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x3F00000000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x00E0000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000009009000060L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000008009000060L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000008008000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0000000000000000L,0x00000000000000F0L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000100000000000L});

}